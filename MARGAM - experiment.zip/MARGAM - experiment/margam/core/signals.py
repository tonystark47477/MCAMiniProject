from django.db.models.signals import post_save
from django.dispatch import receiver
from datetime import timedelta


@receiver(post_save, sender='mother.BabyProfile')
def generate_vaccination_records(sender, instance, created, **kwargs):
    if created:
        from core.models import VaccinationScheduleTemplate
        from mother.models import VaccinationRecord
        templates = VaccinationScheduleTemplate.objects.filter(
            is_active=True)
        records = []
        for template in templates:
            due_date = (instance.date_of_birth +
                timedelta(weeks=template.age_in_weeks))
            records.append(VaccinationRecord(
                baby=instance,
                schedule=template,
                due_date=due_date,
                status='pending'
            ))
        VaccinationRecord.objects.bulk_create(records)
