from django.db import models
from django.conf import settings
from django.utils import timezone


class TimeStampedModel(models.Model):
    """Abstract base — every model in margam gets timestamps."""
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


# ─────────────────────────────────────────────
# Administrative
# ─────────────────────────────────────────────

class Panchayat(TimeStampedModel):
    name     = models.CharField(max_length=100, unique=True)
    district = models.CharField(max_length=100)
    block    = models.CharField(max_length=100, blank=True)

    class Meta:
        ordering            = ['district', 'name']
        verbose_name_plural = 'Panchayats'

    def __str__(self):
        return f'{self.name}, {self.district}'


# ─────────────────────────────────────────────
# Health Content
# ─────────────────────────────────────────────

class Disease(TimeStampedModel):
    name        = models.CharField(max_length=150, unique=True)
    description = models.TextField()
    symptoms    = models.TextField(blank=True)
    prevention  = models.TextField(blank=True)
    added_by    = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, related_name='diseases_added'
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


class HealthTip(TimeStampedModel):
    class Category(models.TextChoices):
        NUTRITION   = 'nutrition',   'Nutrition'
        HYGIENE     = 'hygiene',     'Hygiene'
        PRENATAL    = 'prenatal',    'Prenatal'
        POSTNATAL   = 'postnatal',   'Postnatal'
        INFANT_CARE = 'infant_care', 'Infant Care'
        VACCINATION = 'vaccination', 'Vaccination'
        GENERAL     = 'general',     'General'

    title     = models.CharField(max_length=200)
    content   = models.TextField()
    category  = models.CharField(max_length=20, choices=Category.choices, default=Category.GENERAL, db_index=True)
    added_by  = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, related_name='tips_added'
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title


class Food(TimeStampedModel):
    class TargetGroup(models.TextChoices):
        PREGNANT  = 'pregnant',  'Pregnant Mother'
        LACTATING = 'lactating', 'Lactating Mother'
        INFANT    = 'infant',    'Infant (0–6 months)'
        TODDLER   = 'toddler',   'Toddler (6–24 months)'
        GENERAL   = 'general',   'General'

    name         = models.CharField(max_length=150)
    description  = models.TextField()
    nutrients    = models.TextField(blank=True)
    benefits     = models.TextField(blank=True)
    target_group = models.CharField(max_length=20, choices=TargetGroup.choices, default=TargetGroup.GENERAL, db_index=True)
    added_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, related_name='foods_added'
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['target_group', 'name']

    def __str__(self):
        return f'{self.name} ({self.get_target_group_display()})'


class VaccinationScheduleTemplate(TimeStampedModel):
    """
    Government-defined standard schedule.
    Each row = one dose at a specific age.
    Mother's actual records reference this.
    """
    vaccine_name  = models.CharField(max_length=150)
    age_in_weeks  = models.PositiveIntegerField(help_text='Age at which this dose is due')
    dose_number   = models.PositiveSmallIntegerField(default=1)
    description   = models.TextField(blank=True)
    is_mandatory  = models.BooleanField(default=True)
    added_by      = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, related_name='schedules_added'
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering        = ['age_in_weeks', 'dose_number']
        unique_together = ['vaccine_name', 'age_in_weeks', 'dose_number']
        verbose_name    = 'Vaccination Schedule'

    def __str__(self):
        return f'{self.vaccine_name} – Dose {self.dose_number} (Week {self.age_in_weeks})'


# ─────────────────────────────────────────────
# Communication
# ─────────────────────────────────────────────

class Notification(TimeStampedModel):
    class NotifType(models.TextChoices):
        GOVERNMENT  = 'government',  'Government Broadcast'
        VACCINATION = 'vaccination', 'Vaccination Alert'
        APPOINTMENT = 'appointment', 'Appointment Update'
        GENERAL     = 'general',     'General'

    sender     = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, related_name='sent_notifications'
    )
    recipient  = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='received_notifications'
    )
    title      = models.CharField(max_length=200)
    message    = models.TextField()
    notif_type = models.CharField(max_length=20, choices=NotifType.choices, default=NotifType.GENERAL, db_index=True)
    is_read    = models.BooleanField(default=False, db_index=True)
    read_at    = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']

    def mark_read(self):
        if not self.is_read:
            self.is_read = True
            self.read_at = timezone.now()
            self.save(update_fields=['is_read', 'read_at'])

    def __str__(self):
        return f'[{self.get_notif_type_display()}] {self.title}'


class Message(TimeStampedModel):
    """In-app chat — Asha Worker ↔ Mother only."""
    sender    = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sent_messages'
    )
    recipient = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='received_messages'
    )
    content   = models.TextField()
    is_read   = models.BooleanField(default=False)

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f'{self.sender.username} → {self.recipient.username}: {self.content[:50]}'