from functools import wraps
from django.shortcuts import redirect
from django.contrib import messages


def role_required(*roles):
    """
    Usage:
        @role_required('government')
        @role_required('doctor', 'government')
    """
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect('accounts:login')
            if request.user.role not in roles:
                messages.error(request, 'You are not authorised to access this page.')
                return redirect(request.user.get_dashboard_url())
            return view_func(request, *args, **kwargs)
        return wrapper
    return decorator

# Convenience aliases
government_required = role_required('government')
mother_required     = role_required('mother')


def asha_required(view_func):
    """
    Ensures user is an authenticated ASHA worker AND has been approved by Government.
    Unapproved ASHA workers are redirected to the verification status page.
    """
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('accounts:login')
        if not request.user.is_asha_worker:
            messages.error(request, 'You are not authorised to access this page.')
            return redirect(request.user.get_dashboard_url())
        profile = getattr(request.user, 'asha_profile', None)
        if profile and not profile.is_approved:
            return redirect('asha:verification_status')
        return view_func(request, *args, **kwargs)
    return wrapper


def doctor_required(view_func):
    """
    Ensures user is an authenticated doctor AND has been approved by Government.
    Unapproved doctors are redirected to the verification status page.
    """
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('accounts:login')
        if not request.user.is_doctor:
            messages.error(request, 'You are not authorised to access this page.')
            return redirect(request.user.get_dashboard_url())
        profile = getattr(request.user, 'doctor_profile', None)
        if profile and not profile.is_approved:
            return redirect('doctor:verification_status')
        return view_func(request, *args, **kwargs)
    return wrapper