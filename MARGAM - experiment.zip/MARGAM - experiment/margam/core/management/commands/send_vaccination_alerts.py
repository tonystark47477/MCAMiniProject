from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta
from mother.models import VaccinationRecord
from core.models import Notification


class Command(BaseCommand):
    help = 'Send vaccination alerts 3 days before due date'

    def handle(self, *args, **kwargs):
        today = timezone.now().date()
        target_date = today + timedelta(days=3)
        
        records = VaccinationRecord.objects.filter(
            status='pending',
            due_date=target_date,
            alert_sent=False
        ).select_related(
            'baby__mother__user',
            'schedule'
        )
        
        count = 0
        for record in records:
            Notification.objects.create(
                sender=None,
                recipient=record.baby.mother.user,
                title=f'Vaccination Due in 3 Days',
                message=(
                    f"{record.baby.name}'s "
                    f"{record.schedule.vaccine_name} "
                    f"(Dose {record.schedule.dose_number}) "
                    f"is due on {record.due_date}. "
                    f"Please visit your nearest PHC."
                ),
                notif_type='vaccination'
            )
            record.alert_sent = True
            record.save(update_fields=['alert_sent'])
            count += 1
        
        self.stdout.write(
            self.style.SUCCESS(
                f'Sent {count} vaccination alerts.'
            )
        )
