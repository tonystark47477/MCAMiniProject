def unread_notifications(request):
    """Injects unread notification count into every template."""
    if request.user.is_authenticated:
        count = request.user.received_notifications.filter(is_read=False).count()
        return {'unread_notif_count': count}
    return {'unread_notif_count': 0}