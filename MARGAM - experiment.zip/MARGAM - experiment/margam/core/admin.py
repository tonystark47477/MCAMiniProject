from django.contrib import admin
from .models import Panchayat, Disease, HealthTip, Food, VaccinationScheduleTemplate, Notification, Message

@admin.register(Panchayat)
class PanchayatAdmin(admin.ModelAdmin):
    list_display = ('name', 'district', 'block')
    search_fields = ('name', 'district')

@admin.register(Disease)
class DiseaseAdmin(admin.ModelAdmin):
    list_display = ('name', 'is_active', 'added_by', 'created_at')
    list_filter = ('is_active',)
    search_fields = ('name',)

@admin.register(HealthTip)
class HealthTipAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'is_active', 'added_by')
    list_filter = ('category', 'is_active')

@admin.register(Food)
class FoodAdmin(admin.ModelAdmin):
    list_display = ('name', 'target_group', 'is_active', 'added_by')
    list_filter = ('target_group', 'is_active')

@admin.register(VaccinationScheduleTemplate)
class VaccinationScheduleTemplateAdmin(admin.ModelAdmin):
    list_display = ('vaccine_name', 'age_in_weeks', 'dose_number', 'is_mandatory', 'is_active')
    list_filter = ('is_mandatory', 'is_active')
    ordering = ('age_in_weeks', 'dose_number')

@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('title', 'notif_type', 'recipient', 'is_read', 'created_at')
    list_filter = ('notif_type', 'is_read')

@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ('sender', 'recipient', 'is_read', 'created_at')
