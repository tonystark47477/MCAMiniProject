from django.urls import path
from django.shortcuts import redirect, render

app_name = 'core'


def home(request):
    if request.user.is_authenticated:
        return redirect(request.user.get_dashboard_url())
    return render(request, 'core/landing.html')


urlpatterns = [
    path('', home, name='home'),
]