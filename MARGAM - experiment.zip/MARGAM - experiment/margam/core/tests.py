from datetime import date, timedelta
from django.test import TestCase, Client
from django.urls import reverse
from accounts.models import CustomUser
from core.models import Panchayat, VaccinationScheduleTemplate, Notification
from asha.models import AshaWorkerProfile
from doctor.models import DoctorProfile, DoctorAvailability
from mother.models import MotherProfile, BabyProfile, VaccinationRecord, Booking


class CompleteWorkflowTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.panchayat = Panchayat.objects.create(name='Core Panchayat', district='District C')

        # Government User
        self.govt_user = CustomUser.objects.create_user(
            username='core_govt', password='password123', role=CustomUser.Role.GOVERNMENT
        )

        # ASHA User
        self.asha_user = CustomUser.objects.create_user(
            username='core_asha', password='password123', role=CustomUser.Role.ASHA_WORKER
        )
        self.asha_profile = AshaWorkerProfile.objects.create(
            user=self.asha_user, panchayat=self.panchayat, worker_id='ASHC001'
        )

        # Doctor User
        self.doc_user = CustomUser.objects.create_user(
            username='core_doctor', password='password123', role=CustomUser.Role.DOCTOR
        )
        self.doc_profile = DoctorProfile.objects.create(user=self.doc_user)

        # Mother User 1
        self.mother1_user = CustomUser.objects.create_user(
            username='core_mother1', password='password123', role=CustomUser.Role.MOTHER
        )
        self.mother1_profile = MotherProfile.objects.create(
            user=self.mother1_user, asha_worker=self.asha_profile
        )

        # Mother User 2
        self.mother2_user = CustomUser.objects.create_user(
            username='core_mother2', password='password123', role=CustomUser.Role.MOTHER
        )
        self.mother2_profile = MotherProfile.objects.create(user=self.mother2_user)

    def test_complete_vaccination_workflow(self):
        """Phase 2.F - Complete Vaccination Flow"""
        # 1. Government defines vaccination schedule template
        template = VaccinationScheduleTemplate.objects.create(
            vaccine_name='HepB 1', age_in_weeks=0, dose_number=1
        )

        # 2. Mother registers baby -> Signal creates VaccinationRecord
        baby = BabyProfile.objects.create(
            mother=self.mother1_profile,
            name='Baby Workflow',
            date_of_birth=date.today(),
            gender='M'
        )
        vax_record = VaccinationRecord.objects.filter(baby=baby, schedule=template).first()
        self.assertIsNotNone(vax_record)
        self.assertEqual(vax_record.status, VaccinationRecord.Status.PENDING)

        # 3. ASHA views schedule & marks vaccination as Given
        self.client.login(username='core_asha', password='password123')
        resp_update = self.client.post(
            reverse('asha:vaccination_update', kwargs={'pk': vax_record.pk}),
            {'status': 'given', 'given_date': str(date.today()), 'notes': 'Given by ASHA'}
        )
        self.assertEqual(resp_update.status_code, 302)
        vax_record.refresh_from_db()
        self.assertEqual(vax_record.status, VaccinationRecord.Status.GIVEN)

    def test_complete_appointment_workflow(self):
        """Phase 2.G - Complete Appointment Flow & Capacity/Date Checks"""
        today = date.today()
        today_weekday = today.weekday()
        tomorrow = today + timedelta(days=1)
        tomorrow_weekday = tomorrow.weekday()

        # 1. Doctor sets availability ONLY for today, max 1 booking
        DoctorAvailability.objects.create(
            doctor=self.doc_profile,
            day_of_week=today_weekday,
            start_time='09:00',
            end_time='17:00',
            max_bookings=1,
            is_available=True
        )

        self.client.login(username='core_mother1', password='password123')

        # 2. Mother attempts booking on unavailable day (tomorrow) -> Blocked
        resp_unavail = self.client.post(reverse('mother:book_confirm'), {
            'doctor_pk': self.doc_profile.pk,
            'appointment_date': str(tomorrow),
            'reason': 'Checkup'
        })
        self.assertRedirects(resp_unavail, reverse('mother:book_doctor'))
        self.assertEqual(Booking.objects.filter(mother=self.mother1_profile).count(), 0)

        # 3. Mother 1 books on available day (today) -> Success (Pending)
        resp_book1 = self.client.post(reverse('mother:book_confirm'), {
            'doctor_pk': self.doc_profile.pk,
            'appointment_date': str(today),
            'reason': 'Routine check'
        })
        self.assertRedirects(resp_book1, reverse('mother:bookings'))
        booking1 = Booking.objects.get(mother=self.mother1_profile)
        self.assertEqual(booking1.status, Booking.Status.PENDING)

        # 4. Mother 2 attempts booking on today (max_bookings = 1 reached) -> Blocked
        self.client.login(username='core_mother2', password='password123')
        resp_overcap = self.client.post(reverse('mother:book_confirm'), {
            'doctor_pk': self.doc_profile.pk,
            'appointment_date': str(today),
            'reason': 'Consultation'
        })
        self.assertRedirects(resp_overcap, reverse('mother:book_doctor'))
        self.assertEqual(Booking.objects.filter(mother=self.mother2_profile).count(), 0)

        # 5. Doctor confirms Mother 1 booking -> Notification created
        self.client.login(username='core_doctor', password='password123')
        resp_conf = self.client.get(reverse('doctor:booking_confirm', kwargs={'pk': booking1.pk}))
        self.assertEqual(resp_conf.status_code, 405)
        resp_conf = self.client.post(reverse('doctor:booking_confirm', kwargs={'pk': booking1.pk}))
        self.assertEqual(resp_conf.status_code, 302)
        booking1.refresh_from_db()
        self.assertEqual(booking1.status, Booking.Status.CONFIRMED)
        
        notif = Notification.objects.filter(recipient=self.mother1_user, notif_type=Notification.NotifType.APPOINTMENT).first()
        self.assertIsNotNone(notif)

        # 6. Doctor completes appointment
        resp_comp = self.client.post(reverse('doctor:booking_complete', kwargs={'pk': booking1.pk}), {
            'doctor_notes': 'All good.'
        })
        self.assertEqual(resp_comp.status_code, 302)
        booking1.refresh_from_db()
        self.assertEqual(booking1.status, Booking.Status.COMPLETED)

    def test_notification_workflow_and_privacy(self):
        """Phase 2.H - Notification Workflow & Recipient Privacy Isolation"""
        # Create notification for Mother 1
        notif1 = Notification.objects.create(
            sender=self.govt_user,
            recipient=self.mother1_user,
            title='Mother 1 Alert',
            message='Private alert for Mother 1',
            notif_type=Notification.NotifType.GENERAL,
            is_read=False
        )

        # Create notification for Mother 2
        notif2 = Notification.objects.create(
            sender=self.govt_user,
            recipient=self.mother2_user,
            title='Mother 2 Alert',
            message='Private alert for Mother 2',
            notif_type=Notification.NotifType.GENERAL,
            is_read=False
        )

        # Mother 1 checks notifications page
        self.client.login(username='core_mother1', password='password123')
        resp = self.client.get(reverse('accounts:notifications'))
        self.assertEqual(resp.status_code, 200)
        notifs_in_context = resp.context['notifications']
        self.assertIn(notif1, notifs_in_context)
        self.assertNotIn(notif2, notifs_in_context)

        # Verify notif1 marked read upon viewing
        notif1.refresh_from_db()
        self.assertTrue(notif1.is_read)
        # Verify notif2 remains unread for Mother 2
        notif2.refresh_from_db()
        self.assertFalse(notif2.is_read)
