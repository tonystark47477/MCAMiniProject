from django.urls import path
from . import views

app_name = 'asha'

urlpatterns = [
    path('',                                    views.dashboard,          name='dashboard'),
    path('mothers/',                            views.mothers,            name='mothers'),
    path('mothers/add/',                        views.mother_add,         name='mother_add'),
    path('mothers/<int:pk>/',                   views.mother_detail,      name='mother_detail'),
    path('mothers/<int:mother_pk>/baby/add/',   views.baby_add,           name='baby_add'),
    path('baby/<int:pk>/',                      views.baby_detail,        name='baby_detail'),
    path('baby/<int:baby_pk>/growth/add/',      views.growth_add,         name='growth_add'),
    path('vaccinations/',                       views.vaccinations,       name='vaccinations'),
    path('vaccinations/<int:pk>/update/',       views.vaccination_update, name='vaccination_update'),
    path('tips/',                               views.health_tips,        name='health_tips'),
    path('tips/add/',                           views.tip_add,            name='tip_add'),
    path('diseases/',                           views.diseases,           name='diseases'),
    path('food/',                               views.food,               name='food'),
    path('food/add/',                           views.food_add,           name='food_add'),
    path('notifications/',                      views.notifications,      name='notifications'),
    path('chat/',                               views.chat,               name='chat'),
    path('chat/<int:mother_pk>/',               views.chat_thread,        name='chat_thread'),
    path('chat/<int:mother_pk>/messages/',      views.chat_messages_api,  name='chat_messages_api'),
    path('verification-status/',                views.verification_status, name='verification_status'),
]