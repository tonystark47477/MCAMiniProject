from django.db import models
from django.conf import settings
from core.models import TimeStampedModel, Panchayat


class AshaWorkerProfile(TimeStampedModel):
    class VerificationStatus(models.TextChoices):
        PENDING  = 'pending',  'Pending Verification'
        APPROVED = 'approved', 'Approved'
        REJECTED = 'rejected', 'Rejected'

    user      = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='asha_profile'
    )
    panchayat = models.ForeignKey(
        Panchayat, on_delete=models.SET_NULL, null=True, related_name='asha_workers'
    )
    worker_id = models.CharField(max_length=50, unique=True, blank=True)
    address   = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    # Document-based verification fields
    verification_document = models.FileField(
        upload_to='asha_proofs/', blank=True, null=True,
        help_text='Supporting identification or appointment proof document.'
    )
    verification_status = models.CharField(
        max_length=20,
        choices=VerificationStatus.choices,
        default=VerificationStatus.APPROVED,
        db_index=True
    )
    rejection_reason = models.TextField(blank=True)

    @property
    def is_approved(self):
        return self.verification_status == self.VerificationStatus.APPROVED

    @property
    def is_pending(self):
        return self.verification_status == self.VerificationStatus.PENDING

    @property
    def is_rejected(self):
        return self.verification_status == self.VerificationStatus.REJECTED

    class Meta:
        verbose_name = 'Asha Worker Profile'

    def __str__(self):
        return f'{self.user.get_full_name()} — {self.panchayat}'

    def get_urgent_cases_count(self):
        """Mothers with overdue vaccinations in this worker's area."""
        from mother.models import VaccinationRecord
        from django.utils import timezone
        return VaccinationRecord.objects.filter(
            baby__mother__asha_worker=self,
            status='pending',
            due_date__lt=timezone.now().date()
        ).count()