from datetime import date
from django.test import TestCase, Client
from django.urls import reverse
from django.core.files.uploadedfile import SimpleUploadedFile
from accounts.models import CustomUser
from asha.models import AshaWorkerProfile
from mother.models import MotherProfile, BabyProfile, VaccinationRecord, BabyGrowthRecord
from core.models import Panchayat, VaccinationScheduleTemplate, Message, Notification


class AshaWorkflowTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.panchayat = Panchayat.objects.create(name='Panchayat A', district='District A')

        self.govt_user = CustomUser.objects.create_user(
            username='testgovt_asha', password='password123', role=CustomUser.Role.GOVERNMENT
        )

        self.asha1_user = CustomUser.objects.create_user(
            username='asha_one', password='password123', role=CustomUser.Role.ASHA_WORKER
        )
        self.asha1_profile = AshaWorkerProfile.objects.create(
            user=self.asha1_user, panchayat=self.panchayat, worker_id='ASH001'
        )

        self.asha2_user = CustomUser.objects.create_user(
            username='asha_two', password='password123', role=CustomUser.Role.ASHA_WORKER
        )
        self.asha2_profile = AshaWorkerProfile.objects.create(
            user=self.asha2_user, panchayat=self.panchayat, worker_id='ASH002'
        )

        self.mother1_user = CustomUser.objects.create_user(
            username='mother_assigned', password='password123', role=CustomUser.Role.MOTHER, first_name='Mary'
        )
        self.mother1_profile = MotherProfile.objects.create(
            user=self.mother1_user, asha_worker=self.asha1_profile
        )

        self.mother2_user = CustomUser.objects.create_user(
            username='mother_other', password='password123', role=CustomUser.Role.MOTHER, first_name='Sarah'
        )
        self.mother2_profile = MotherProfile.objects.create(
            user=self.mother2_user, asha_worker=self.asha2_profile
        )

        self.template = VaccinationScheduleTemplate.objects.create(
            vaccine_name='BCG', age_in_weeks=0, dose_number=1
        )
        self.baby = BabyProfile.objects.create(
            mother=self.mother1_profile, name='Baby Mary', date_of_birth=date.today(), gender='F'
        )

    def test_asha_dashboard(self):
        self.client.login(username='asha_one', password='password123')
        response = self.client.get(reverse('asha:dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context['total_mothers'], 1)
        self.assertEqual(response.context['total_babies'], 1)

    def test_asha_mother_list_and_detail(self):
        self.client.login(username='asha_one', password='password123')
        resp_list = self.client.get(reverse('asha:mothers'))
        self.assertEqual(resp_list.status_code, 200)

        resp_detail = self.client.get(reverse('asha:mother_detail', kwargs={'pk': self.mother1_profile.pk}))
        self.assertEqual(resp_detail.status_code, 200)

    def test_asha_mother_add(self):
        self.client.login(username='asha_one', password='password123')
        phone_num = '9123456789'
        resp = self.client.post(reverse('asha:mother_add'), {
            'first_name': 'New',
            'last_name': 'Mother',
            'phone': phone_num,
            'pregnancy_status': 'pregnant',
            'blood_group': 'B+'
        })
        self.assertEqual(resp.status_code, 302)
        new_m = MotherProfile.objects.get(user__username=phone_num)
        self.assertEqual(new_m.asha_worker, self.asha1_profile)

    def test_asha_baby_add_and_growth_add(self):
        self.client.login(username='asha_one', password='password123')
        # Add Baby
        resp_baby = self.client.post(
            reverse('asha:baby_add', kwargs={'mother_pk': self.mother1_profile.pk}),
            {
                'name': 'Baby Two',
                'date_of_birth': str(date.today()),
                'gender': 'M'
            }
        )
        self.assertEqual(resp_baby.status_code, 302)
        b2 = BabyProfile.objects.get(name='Baby Two')
        self.assertEqual(b2.mother, self.mother1_profile)

        # Add Growth
        resp_growth = self.client.post(
            reverse('asha:growth_add', kwargs={'baby_pk': b2.pk}),
            {
                'record_date': str(date.today()),
                'weight_kg': '3.8',
                'height_cm': '51.0'
            }
        )
        self.assertEqual(resp_growth.status_code, 302)
        self.assertEqual(BabyGrowthRecord.objects.filter(baby=b2).count(), 1)

    def test_asha_vaccination_update(self):
        self.client.login(username='asha_one', password='password123')
        vax_record = VaccinationRecord.objects.get(baby=self.baby)
        resp_upd = self.client.post(
            reverse('asha:vaccination_update', kwargs={'pk': vax_record.pk}),
            {
                'status': 'given',
                'given_date': str(date.today()),
                'notes': 'Administered in clinic'
            }
        )
        self.assertEqual(resp_upd.status_code, 302)
        vax_record.refresh_from_db()
        self.assertEqual(vax_record.status, 'given')

    def test_asha_chat_thread(self):
        self.client.login(username='asha_one', password='password123')
        resp = self.client.post(
            reverse('asha:chat_thread', kwargs={'mother_pk': self.mother1_profile.pk}),
            {'content': 'Hello from ASHA'}
        )
        self.assertRedirects(resp, reverse('asha:chat_thread', kwargs={'mother_pk': self.mother1_profile.pk}))
        msg = Message.objects.filter(sender=self.asha1_user, recipient=self.mother1_user).first()
        self.assertIsNotNone(msg)

    def test_asha_access_isolation(self):
        # ASHA 1 tries to access Mother 2 (assigned to ASHA 2)
        self.client.login(username='asha_one', password='password123')
        resp = self.client.get(reverse('asha:mother_detail', kwargs={'pk': self.mother2_profile.pk}))
        self.assertEqual(resp.status_code, 404)

    def test_asha_registration_sets_pending(self):
        proof = SimpleUploadedFile('asha_id.pdf', b'%PDF-1.4 test content', content_type='application/pdf')
        resp = self.client.post(reverse('accounts:register_asha'), {
            'username': 'newasha',
            'first_name': 'New',
            'last_name': 'Asha',
            'email': 'newasha@example.com',
            'phone': '9876543200',
            'password1': 'StrongAshaPass@123',
            'password2': 'StrongAshaPass@123',
            'panchayat': self.panchayat.pk,
            'worker_id': 'ASH_NEW_001',
            'verification_document': proof,
            'address': 'Village Center',
        })
        self.assertRedirects(resp, reverse('accounts:login'))
        new_asha = CustomUser.objects.get(username='newasha')
        profile = new_asha.asha_profile
        self.assertEqual(profile.verification_status, AshaWorkerProfile.VerificationStatus.PENDING)
        self.assertFalse(profile.is_active)
        self.assertEqual(profile.worker_id, 'ASH_NEW_001')
        self.assertTrue(bool(profile.verification_document))

    def test_asha_file_validation_rejects_invalid_extension(self):
        bad_file = SimpleUploadedFile('bad_doc.exe', b'bad content', content_type='application/octet-stream')
        resp = self.client.post(reverse('accounts:register_asha'), {
            'username': 'badasha',
            'first_name': 'Bad',
            'last_name': 'Asha',
            'email': 'badasha@example.com',
            'phone': '9876543201',
            'password1': 'StrongAshaPass@123',
            'password2': 'StrongAshaPass@123',
            'panchayat': self.panchayat.pk,
            'worker_id': 'ASH_BAD_001',
            'verification_document': bad_file,
        })
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, 'Only PDF, JPG, and PNG documents are accepted for verification proof.')

    def test_pending_asha_cannot_access_dashboard_or_direct_urls(self):
        # Create a pending ASHA worker
        pending_user = CustomUser.objects.create_user(
            username='pendingasha', password='password123', role=CustomUser.Role.ASHA_WORKER
        )
        AshaWorkerProfile.objects.create(
            user=pending_user,
            panchayat=self.panchayat,
            worker_id='ASH_PENDING',
            verification_status=AshaWorkerProfile.VerificationStatus.PENDING,
            is_active=False
        )

        # Login routes to verification status
        login_resp = self.client.post(reverse('accounts:login'), {
            'username': 'pendingasha', 'password': 'password123'
        })
        self.assertRedirects(login_resp, reverse('asha:verification_status'))

        # Direct access to dashboard is blocked
        dash_resp = self.client.get(reverse('asha:dashboard'))
        self.assertRedirects(dash_resp, reverse('asha:verification_status'))

        # Direct access to mothers list is blocked
        moth_resp = self.client.get(reverse('asha:mothers'))
        self.assertRedirects(moth_resp, reverse('asha:verification_status'))

        # Status page renders cleanly
        status_resp = self.client.get(reverse('asha:verification_status'))
        self.assertEqual(status_resp.status_code, 200)
        self.assertContains(status_resp, 'Pending Review')

    def test_government_asha_approval_workflow(self):
        pending_user = CustomUser.objects.create_user(
            username='ashatoapprove', password='password123', role=CustomUser.Role.ASHA_WORKER
        )
        profile = AshaWorkerProfile.objects.create(
            user=pending_user,
            panchayat=self.panchayat,
            worker_id='ASH_APPR_REQ',
            verification_status=AshaWorkerProfile.VerificationStatus.PENDING,
            is_active=False
        )

        # Government views list
        self.client.login(username='testgovt_asha', password='password123')
        list_resp = self.client.get(reverse('government:asha_workers'))
        self.assertEqual(list_resp.status_code, 200)
        self.assertContains(list_resp, 'ashatoapprove')

        # Government approves the worker
        appr_resp = self.client.post(reverse('government:asha_approve', kwargs={'pk': profile.pk}))
        self.assertRedirects(appr_resp, reverse('government:asha_workers'))

        profile.refresh_from_db()
        self.assertEqual(profile.verification_status, AshaWorkerProfile.VerificationStatus.APPROVED)
        self.assertTrue(profile.is_active)

        # Notification sent
        notif = Notification.objects.filter(recipient=pending_user).first()
        self.assertIsNotNone(notif)
        self.assertIn('Approved', notif.title)

        # ASHA worker now has normal access
        self.client.logout()
        self.client.login(username='ashatoapprove', password='password123')
        dash_resp = self.client.get(reverse('asha:dashboard'))
        self.assertEqual(dash_resp.status_code, 200)

    def test_government_asha_rejection_workflow(self):
        pending_user = CustomUser.objects.create_user(
            username='ashatoreject', password='password123', role=CustomUser.Role.ASHA_WORKER
        )
        profile = AshaWorkerProfile.objects.create(
            user=pending_user,
            panchayat=self.panchayat,
            worker_id='ASH_REJ_REQ',
            verification_status=AshaWorkerProfile.VerificationStatus.PENDING,
            is_active=False
        )

        # Government rejects
        self.client.login(username='testgovt_asha', password='password123')
        rej_resp = self.client.post(reverse('government:asha_reject', kwargs={'pk': profile.pk}), {
            'rejection_reason': 'Invalid appointment documentation'
        })
        self.assertRedirects(rej_resp, reverse('government:asha_workers'))

        profile.refresh_from_db()
        self.assertEqual(profile.verification_status, AshaWorkerProfile.VerificationStatus.REJECTED)
        self.assertFalse(profile.is_active)
        self.assertEqual(profile.rejection_reason, 'Invalid appointment documentation')

        # ASHA login routes to verification status
        self.client.logout()
        self.client.login(username='ashatoreject', password='password123')
        dash_resp = self.client.get(reverse('asha:dashboard'))
        self.assertRedirects(dash_resp, reverse('asha:verification_status'))
        status_resp = self.client.get(reverse('asha:verification_status'))
        self.assertContains(status_resp, 'Registration Not Approved')
        self.assertContains(status_resp, 'Invalid appointment documentation')

    def test_unverified_asha_cannot_be_assigned_to_mother(self):
        pending_user = CustomUser.objects.create_user(
            username='ashapending_assign', password='password123', role=CustomUser.Role.ASHA_WORKER
        )
        pending_profile = AshaWorkerProfile.objects.create(
            user=pending_user,
            panchayat=self.panchayat,
            worker_id='ASH_NO_ASSIGN',
            verification_status=AshaWorkerProfile.VerificationStatus.PENDING,
            is_active=False
        )

        self.client.login(username='testgovt_asha', password='password123')
        assign_page = self.client.get(reverse('government:assign_asha', kwargs={'mother_pk': self.mother1_profile.pk}))
        self.assertEqual(assign_page.status_code, 200)
        # Pending ASHA worker should NOT be in the candidate list
        candidates = assign_page.context['asha_workers']
        self.assertNotIn(pending_profile, candidates)

