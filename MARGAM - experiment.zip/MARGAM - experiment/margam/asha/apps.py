from django.apps import AppConfig


class AshaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'asha'
