from django.contrib import admin
from .models import AshaWorkerProfile

@admin.register(AshaWorkerProfile)
class AshaWorkerProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'panchayat', 'worker_id', 'verification_status', 'is_active')
    list_filter = ('verification_status', 'is_active', 'panchayat')
    search_fields = ('user__first_name', 'user__last_name', 'worker_id')
