from django import forms
from django.contrib.auth.forms import UserCreationForm
from accounts.models import CustomUser
from core.models import HealthTip, Food, Disease
from mother.models import (MotherProfile, BabyProfile,
    BabyGrowthRecord, VaccinationRecord)


class BootstrapMixin:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            widget = field.widget
            if isinstance(widget, forms.CheckboxInput):
                widget.attrs['class'] = 'form-check-input'
            elif isinstance(widget, (forms.Select, forms.SelectMultiple)):
                widget.attrs['class'] = 'form-select'
            else:
                widget.attrs['class'] = 'form-control'
            if not isinstance(widget, forms.CheckboxInput):
                widget.attrs.setdefault('placeholder', field.label or name.replace('_', ' ').title())


PREGNANCY_CHOICES = [
    ('pregnant',  'Pregnant'),
    ('postnatal', 'Postnatal'),
    ('lactating', 'Lactating'),
    ('other',     'Other'),
]

BLOOD_GROUP_CHOICES = [
    ('', 'Select blood group (optional)'),
    ('A+','A+'), ('A-','A-'), ('B+','B+'), ('B-','B-'),
    ('O+','O+'), ('O-','O-'), ('AB+','AB+'), ('AB-','AB-'),
]


class AddMotherForm(BootstrapMixin, forms.Form):
    """Asha worker registers a new mother — creates CustomUser + MotherProfile."""
    first_name        = forms.CharField(max_length=150)
    last_name         = forms.CharField(max_length=150, required=False)
    phone             = forms.CharField(max_length=15, help_text="Used as username AND initial password")
    address           = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}), required=False)
    date_of_birth     = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}), required=False)
    guardian_name     = forms.CharField(max_length=100, required=False)
    guardian_phone    = forms.CharField(max_length=15, required=False)
    pregnancy_status  = forms.ChoiceField(choices=PREGNANCY_CHOICES)
    expected_due_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}), required=False)
    blood_group       = forms.ChoiceField(choices=BLOOD_GROUP_CHOICES, required=False)

    def clean_phone(self):
        phone = self.cleaned_data['phone'].strip()
        from accounts.models import CustomUser
        if CustomUser.objects.filter(username=phone).exists():
            raise forms.ValidationError("A user with this phone number already exists.")
        return phone

    def save(self, asha_worker):
        user = CustomUser.objects.create_user(
            username=self.cleaned_data['phone'],
            password=self.cleaned_data['phone'],
            first_name=self.cleaned_data['first_name'],
            last_name=self.cleaned_data['last_name'],
            phone=self.cleaned_data['phone'],
            role='mother'
        )
        profile = MotherProfile.objects.create(
            user=user,
            asha_worker=asha_worker,
            date_of_birth=self.cleaned_data.get('date_of_birth'),
            address=self.cleaned_data.get('address',''),
            guardian_name=self.cleaned_data.get('guardian_name',''),
            guardian_phone=self.cleaned_data.get('guardian_phone',''),
            pregnancy_status=self.cleaned_data.get('pregnancy_status','other'),
            expected_due_date=self.cleaned_data.get('expected_due_date'),
            blood_group=self.cleaned_data.get('blood_group','')
        )
        return profile


class AddBabyForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = BabyProfile
        fields = ('name', 'date_of_birth', 'gender', 'birth_weight', 'blood_group', 'notes')
        widgets = {
            'date_of_birth': forms.DateInput(attrs={'type': 'date'}),
        }


class GrowthRecordForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = BabyGrowthRecord
        fields = ('record_date', 'weight_kg', 'height_cm',
                  'head_circumference_cm', 'notes')
        widgets = {
            'record_date': forms.DateInput(attrs={'type': 'date'}),
        }


class VaccinationUpdateForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = VaccinationRecord
        fields = ('status', 'given_date', 'batch_number', 'notes')
        widgets = {
            'given_date': forms.DateInput(attrs={'type': 'date'}),
        }


class HealthTipForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = HealthTip
        fields = ('title', 'content', 'category')


class FoodForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = Food
        fields = ('name', 'description', 'nutrients', 'benefits', 'target_group')
