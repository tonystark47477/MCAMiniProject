from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.utils import timezone
from core.decorators import asha_required, role_required
from core.models import HealthTip, Food, Disease
from mother.models import (MotherProfile, BabyProfile,
    BabyGrowthRecord, VaccinationRecord)
from .forms import (AddMotherForm, AddBabyForm, GrowthRecordForm,
    VaccinationUpdateForm, HealthTipForm, FoodForm)


# ─────────────────────────────────────────
# Dashboard
# ─────────────────────────────────────────

@asha_required
def dashboard(request):
    asha_profile = request.user.asha_profile
    today = timezone.now().date()

    total_mothers = MotherProfile.objects.filter(
        asha_worker=asha_profile, is_active=True).count()
    total_babies = BabyProfile.objects.filter(
        mother__asha_worker=asha_profile).count()

    overdue_vaccinations = VaccinationRecord.objects.filter(
        baby__mother__asha_worker=asha_profile,
        status='pending',
        due_date__lt=today
    ).select_related('baby', 'schedule', 'baby__mother__user').order_by('due_date')

    due_this_week = VaccinationRecord.objects.filter(
        baby__mother__asha_worker=asha_profile,
        status='pending',
        due_date__gte=today,
        due_date__lte=today + timezone.timedelta(days=7)
    ).count()

    unread_notifications = request.user.received_notifications.filter(is_read=False).count()

    return render(request, 'asha/dashboard.html', {
        'total_mothers':        total_mothers,
        'total_babies':         total_babies,
        'overdue_vaccinations': overdue_vaccinations,
        'due_this_week':        due_this_week,
        'unread_notifications': unread_notifications,
    })


# ─────────────────────────────────────────
# Mothers
# ─────────────────────────────────────────

@asha_required
def mothers(request):
    asha_profile = request.user.asha_profile
    qs = MotherProfile.objects.filter(
        asha_worker=asha_profile, is_active=True
    ).select_related('user').prefetch_related('babies').order_by('-created_at')

    q = request.GET.get('q', '').strip()
    if q:
        qs = qs.filter(
            user__first_name__icontains=q
        ) | qs.filter(user__last_name__icontains=q)

    return render(request, 'asha/mothers.html', {'mothers': qs, 'q': q})


@asha_required
def mother_detail(request, pk):
    asha_profile = request.user.asha_profile
    mother = get_object_or_404(MotherProfile, pk=pk, asha_worker=asha_profile)
    babies = mother.babies.all()
    return render(request, 'asha/mother_detail.html', {
        'mother': mother, 'babies': babies
    })


@asha_required
def mother_add(request):
    asha_profile = request.user.asha_profile
    if request.method == 'POST':
        form = AddMotherForm(request.POST)
        if form.is_valid():
            profile = form.save(asha_worker=asha_profile)
            messages.success(request,
                f"Mother {profile.user.get_full_name()} registered. "
                f"Login: {profile.user.username} / Password: {form.cleaned_data['phone']}")
            return redirect('asha:mother_detail', pk=profile.pk)
    else:
        form = AddMotherForm()
    return render(request, 'asha/mother_add.html', {'form': form})


# ─────────────────────────────────────────
# Babies
# ─────────────────────────────────────────

@asha_required
def baby_add(request, mother_pk):
    asha_profile = request.user.asha_profile
    mother = get_object_or_404(MotherProfile, pk=mother_pk, asha_worker=asha_profile)
    if request.method == 'POST':
        form = AddBabyForm(request.POST)
        if form.is_valid():
            baby = form.save(commit=False)
            baby.mother = mother
            baby.save()
            messages.success(request,
                f"Baby {baby.name} added. Vaccination schedule generated automatically.")
            return redirect('asha:baby_detail', pk=baby.pk)
    else:
        form = AddBabyForm()
    return render(request, 'asha/baby_add.html', {'form': form, 'mother': mother})


@asha_required
def baby_detail(request, pk):
    baby = get_object_or_404(
        BabyProfile, mother__asha_worker=request.user.asha_profile, pk=pk)
    growth_records = baby.growth_records.order_by('record_date')
    vaccinations   = baby.vaccinations.select_related('schedule').order_by('due_date')
    return render(request, 'asha/baby_detail.html', {
        'baby':           baby,
        'growth_records': growth_records,
        'vaccinations':   vaccinations,
    })


# ─────────────────────────────────────────
# Growth Records
# ─────────────────────────────────────────

@asha_required
def growth_add(request, baby_pk):
    baby = get_object_or_404(
        BabyProfile, mother__asha_worker=request.user.asha_profile, pk=baby_pk)
    if request.method == 'POST':
        form = GrowthRecordForm(request.POST)
        if form.is_valid():
            record = form.save(commit=False)
            record.baby        = baby
            record.recorded_by = request.user
            record.save()
            messages.success(request, 'Growth record saved.')
            return redirect('asha:baby_detail', pk=baby.pk)
    else:
        form = GrowthRecordForm()
    return render(request, 'asha/growth_add.html', {'form': form, 'baby': baby})


# ─────────────────────────────────────────
# Vaccinations
# ─────────────────────────────────────────

@asha_required
def vaccinations(request):
    asha_profile = request.user.asha_profile
    today = timezone.now().date()
    filter_type = request.GET.get('filter', 'all')

    qs = VaccinationRecord.objects.filter(
        baby__mother__asha_worker=asha_profile
    ).select_related('baby', 'schedule', 'baby__mother__user')

    if filter_type == 'overdue':
        qs = qs.filter(status='pending', due_date__lt=today)
    elif filter_type == 'this_week':
        qs = qs.filter(
            status='pending',
            due_date__gte=today,
            due_date__lte=today + timezone.timedelta(days=7)
        )
    elif filter_type == 'given':
        qs = qs.filter(status='given')

    return render(request, 'asha/vaccinations.html', {
        'vaccinations': qs.order_by('due_date'),
        'filter_type':  filter_type,
        'today':        today,
    })


@asha_required
def vaccination_update(request, pk):
    record = get_object_or_404(
        VaccinationRecord,
        pk=pk,
        baby__mother__asha_worker=request.user.asha_profile
    )
    if request.method == 'POST':
        form = VaccinationUpdateForm(request.POST, instance=record)
        if form.is_valid():
            form.save()
            messages.success(request, 'Vaccination record updated.')
            return redirect('asha:vaccinations')
    else:
        form = VaccinationUpdateForm(instance=record)
    return render(request, 'asha/vaccination_update.html', {
        'form': form, 'record': record
    })


# ─────────────────────────────────────────
# Health Tips
# ─────────────────────────────────────────

@asha_required
def health_tips(request):
    tips = HealthTip.objects.filter(is_active=True).order_by('-created_at')
    return render(request, 'asha/health_tips.html', {'tips': tips})


@asha_required
def tip_add(request):
    if request.method == 'POST':
        form = HealthTipForm(request.POST)
        if form.is_valid():
            tip = form.save(commit=False)
            tip.added_by = request.user
            tip.save()
            messages.success(request, 'Health tip added.')
            return redirect('asha:health_tips')
    else:
        form = HealthTipForm()
    return render(request, 'asha/tip_add.html', {'form': form})


# ─────────────────────────────────────────
# Diseases
# ─────────────────────────────────────────

@asha_required
def diseases(request):
    diseases_qs = Disease.objects.filter(is_active=True)
    return render(request, 'asha/diseases.html', {'diseases': diseases_qs})


# ─────────────────────────────────────────
# Food / Nutrition
# ─────────────────────────────────────────

@asha_required
def food(request):
    target = request.GET.get('target', '')
    food_qs = Food.objects.filter(is_active=True)
    if target:
        food_qs = food_qs.filter(target_group=target)
    target_choices = Food.TargetGroup.choices
    return render(request, 'asha/food.html', {
        'foods':          food_qs,
        'target':         target,
        'target_choices': target_choices,
    })


@asha_required
def food_add(request):
    if request.method == 'POST':
        form = FoodForm(request.POST)
        if form.is_valid():
            item = form.save(commit=False)
            item.added_by = request.user
            item.save()
            messages.success(request, f"Food item '{item.name}' added.")
            return redirect('asha:food')
    else:
        form = FoodForm()
    return render(request, 'asha/food_add.html', {'form': form})


# ─────────────────────────────────────────
# Notifications
# ─────────────────────────────────────────

@asha_required
def notifications(request):
    notifs = request.user.received_notifications.select_related(
        'sender').order_by('-created_at')
    notifs.filter(is_read=False).update(is_read=True)
    return render(request, 'asha/notifications.html', {'notifications': notifs})


# ─────────────────────────────────────────
# Chat
# ─────────────────────────────────────────

@asha_required
def chat(request):
    asha_profile = request.user.asha_profile
    mothers = MotherProfile.objects.filter(
        asha_worker=asha_profile, is_active=True
    ).select_related('user')

    from core.models import Message
    mother_list = []
    for m in mothers:
        last_msg = (
            Message.objects.filter(
                sender=m.user, recipient=request.user
            ).order_by('-created_at').first()
            or
            Message.objects.filter(
                sender=request.user, recipient=m.user
            ).order_by('-created_at').first()
        )
        unread = Message.objects.filter(
            sender=m.user, recipient=request.user, is_read=False
        ).count()
        mother_list.append({
            'mother':       m,
            'last_message': last_msg,
            'unread_count': unread,
        })

    return render(request, 'asha/chat.html', {'mother_list': mother_list})


@asha_required
def chat_thread(request, mother_pk):
    asha_profile = request.user.asha_profile
    mother = get_object_or_404(MotherProfile, pk=mother_pk, asha_worker=asha_profile)
    from core.models import Message

    if request.method == 'POST':
        content = request.POST.get('content', '').strip()
        if content:
            Message.objects.create(
                sender=request.user,
                recipient=mother.user,
                content=content,
            )
        return redirect('asha:chat_thread', mother_pk=mother_pk)

    messages_qs = (
        Message.objects.filter(sender=request.user, recipient=mother.user) |
        Message.objects.filter(sender=mother.user, recipient=request.user)
    ).order_by('created_at')

    Message.objects.filter(
        sender=mother.user, recipient=request.user, is_read=False
    ).update(is_read=True)

    return render(request, 'asha/chat_thread.html', {
        'mother':   mother,
        'messages': messages_qs,
    })


@asha_required
def chat_messages_api(request, mother_pk):
    from core.models import Message
    from django.http import JsonResponse
    asha_profile = request.user.asha_profile
    mother   = get_object_or_404(MotherProfile, pk=mother_pk, asha_worker=asha_profile)
    after_id = int(request.GET.get('after', 0))
    msgs     = Message.objects.filter(
        sender__in=[request.user, mother.user],
        recipient__in=[request.user, mother.user],
        id__gt=after_id,
    ).order_by('created_at')
    data = [{
        'id':      m.id,
        'content': m.content,
        'is_mine': m.sender == request.user,
        'time':    m.created_at.strftime('%H:%M'),
    } for m in msgs]
    return JsonResponse({'messages': data})


@role_required('asha_worker')
def verification_status(request):
    profile = getattr(request.user, 'asha_profile', None)
    if profile and profile.is_approved:
        return redirect('asha:dashboard')
    return render(request, 'asha/verification_status.html', {
        'profile': profile,
    })


