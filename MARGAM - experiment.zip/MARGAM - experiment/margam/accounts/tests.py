from django.test import TestCase, Client
from django.urls import reverse
from django.core import mail
from django.utils.http import urlsafe_base64_encode
from django.utils.encoding import force_bytes
from django.contrib.auth.tokens import default_token_generator
from accounts.models import CustomUser
from mother.models import MotherProfile
from asha.models import AshaWorkerProfile
from doctor.models import DoctorProfile
from core.models import Panchayat


class AuthenticationTests(TestCase):
    def setUp(self):
        self.client = Client()
        
        # Mother
        self.mother_user = CustomUser.objects.create_user(
            username='testmother',
            password='password123',
            role=CustomUser.Role.MOTHER,
            phone='9876543210'
        )
        self.mother_profile = MotherProfile.objects.create(user=self.mother_user)

        # Asha Worker
        self.panchayat = Panchayat.objects.create(name='Test Panchayat', district='Test District')
        self.asha_user = CustomUser.objects.create_user(
            username='testasha',
            password='password123',
            role=CustomUser.Role.ASHA_WORKER,
            phone='9876543211'
        )
        self.asha_profile = AshaWorkerProfile.objects.create(
            user=self.asha_user, panchayat=self.panchayat, worker_id='ASH123'
        )

        # Doctor
        self.doctor_user = CustomUser.objects.create_user(
            username='testdoctor',
            password='password123',
            role=CustomUser.Role.DOCTOR,
            phone='9876543212'
        )
        self.doctor_profile = DoctorProfile.objects.create(user=self.doctor_user)

        # Govt
        self.govt_user = CustomUser.objects.create_user(
            username='testgovt',
            password='password123',
            role=CustomUser.Role.GOVERNMENT,
            phone='9876543213'
        )

    def test_mother_login(self):
        response = self.client.post(reverse('accounts:login'), {
            'username': 'testmother',
            'password': 'password123'
        })
        self.assertRedirects(response, reverse('mother:dashboard'))

    def test_asha_login(self):
        response = self.client.post(reverse('accounts:login'), {
            'username': 'testasha',
            'password': 'password123'
        })
        self.assertRedirects(response, reverse('asha:dashboard'))

    def test_doctor_login(self):
        response = self.client.post(reverse('accounts:login'), {
            'username': 'testdoctor',
            'password': 'password123'
        })
        self.assertRedirects(response, reverse('doctor:dashboard'))

    def test_government_login(self):
        response = self.client.post(reverse('accounts:login'), {
            'username': 'testgovt',
            'password': 'password123'
        })
        self.assertRedirects(response, reverse('government:dashboard'))

    def test_invalid_login(self):
        response = self.client.post(reverse('accounts:login'), {
            'username': 'testmother',
            'password': 'wrongpassword'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Invalid username or password')

    def test_logout(self):
        self.client.login(username='testmother', password='password123')
        response = self.client.get(reverse('accounts:logout'))
        self.assertRedirects(response, reverse('accounts:login'))

    def test_unauthorized_dashboard_access(self):
        # Mother attempting to access doctor/asha/govt dashboards
        self.client.login(username='testmother', password='password123')
        
        resp_govt = self.client.get(reverse('government:dashboard'))
        self.assertRedirects(resp_govt, reverse('mother:dashboard'))
        
        resp_asha = self.client.get(reverse('asha:dashboard'))
        self.assertRedirects(resp_asha, reverse('mother:dashboard'))
        
        resp_doctor = self.client.get(reverse('doctor:dashboard'))
        self.assertRedirects(resp_doctor, reverse('mother:dashboard'))

    def test_mother_password_change(self):
        self.client.login(username='testmother', password='password123')
        response = self.client.post(reverse('accounts:password_change'), {
            'old_password': 'password123',
            'new_password1': 'newpassword456',
            'new_password2': 'newpassword456',
        })
        self.assertEqual(response.status_code, 302)
        # Verify login with new password
        self.client.logout()
        login_new = self.client.login(username='testmother', password='newpassword456')
        self.assertTrue(login_new)

    def test_login_page_has_forgot_password_link(self):
        response = self.client.get(reverse('accounts:login'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Forgot Password?')
        self.assertContains(response, reverse('accounts:password_reset'))

    def test_password_reset_page_renders(self):
        response = self.client.get(reverse('accounts:password_reset'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Reset Password')

    def test_password_reset_unknown_email_does_not_reveal(self):
        response = self.client.post(reverse('accounts:password_reset'), {
            'email': 'unknown@example.com'
        })
        self.assertRedirects(response, reverse('accounts:password_reset_done'))
        self.assertEqual(len(mail.outbox), 0)

    def test_password_reset_full_workflow(self):
        # Assign email to mother user
        self.mother_user.email = 'mother@example.com'
        self.mother_user.save()

        # Step 1: Request reset link
        response = self.client.post(reverse('accounts:password_reset'), {
            'email': 'mother@example.com'
        })
        self.assertRedirects(response, reverse('accounts:password_reset_done'))

        # Check local email backend generated message
        self.assertEqual(len(mail.outbox), 1)
        email_msg = mail.outbox[0]
        self.assertIn('MARGAM Password Reset', email_msg.subject)
        self.assertIn('mother@example.com', email_msg.to)

        # Generate token and uid
        uid = urlsafe_base64_encode(force_bytes(self.mother_user.pk))
        token = default_token_generator.make_token(self.mother_user)

        # Step 2: Open reset link (follows standard Django referer-protection redirect to /set-password/)
        confirm_url = reverse('accounts:password_reset_confirm', kwargs={'uidb64': uid, 'token': token})
        confirm_resp = self.client.get(confirm_url, follow=True)
        self.assertEqual(confirm_resp.status_code, 200)
        self.assertTrue(confirm_resp.context['validlink'])

        # Step 3: Set new password
        post_url = confirm_resp.redirect_chain[-1][0] if confirm_resp.redirect_chain else confirm_url
        set_resp = self.client.post(post_url, {
            'new_password1': 'BrandNewPass@123',
            'new_password2': 'BrandNewPass@123',
        })
        self.assertRedirects(set_resp, reverse('accounts:password_reset_complete'))

        # Step 4: Login with new password
        login_success = self.client.login(username='testmother', password='BrandNewPass@123')
        self.assertTrue(login_success)

