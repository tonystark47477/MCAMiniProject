from django.urls import path, reverse_lazy
from django.contrib.auth.views import (
    PasswordChangeView, PasswordChangeDoneView,
    PasswordResetView, PasswordResetDoneView,
    PasswordResetConfirmView, PasswordResetCompleteView
)
from .forms import CustomPasswordResetForm, CustomSetPasswordForm
from . import views

app_name = 'accounts'

urlpatterns = [
    path('login/',                views.login_view,          name='login'),
    path('logout/',               views.logout_view,         name='logout'),
    path('register/',             views.register_select,     name='register_select'),
    path('register/government/',  views.register_government, name='register_government'),
    path('register/asha/',        views.register_asha,       name='register_asha'),
    path('register/doctor/',      views.register_doctor,     name='register_doctor'),
    path('register/mother/',      views.register_mother,     name='register_mother'),
    path('notifications/',        views.notifications_view,  name='notifications'),
    path('profile/',              views.profile_view,        name='profile'),
    path('password/change/',
         PasswordChangeView.as_view(
             template_name='accounts/password_change.html',
             success_url='/accounts/password/done/'
         ),
         name='password_change'),
    path('password/done/',
         PasswordChangeDoneView.as_view(
             template_name='accounts/password_change_done.html'
         ),
         name='password_change_done'),
    path('password/reset/',
         PasswordResetView.as_view(
             template_name='accounts/password_reset.html',
             email_template_name='accounts/password_reset_email.txt',
             subject_template_name='accounts/password_reset_subject.txt',
             form_class=CustomPasswordResetForm,
             success_url=reverse_lazy('accounts:password_reset_done'),
         ),
         name='password_reset'),
    path('password/reset/done/',
         PasswordResetDoneView.as_view(
             template_name='accounts/password_reset_done.html',
         ),
         name='password_reset_done'),
    path('password/reset/<uidb64>/<token>/',
         PasswordResetConfirmView.as_view(
             template_name='accounts/password_reset_confirm.html',
             form_class=CustomSetPasswordForm,
             success_url=reverse_lazy('accounts:password_reset_complete'),
         ),
         name='password_reset_confirm'),
    path('password/reset/complete/',
         PasswordResetCompleteView.as_view(
             template_name='accounts/password_reset_complete.html',
         ),
         name='password_reset_complete'),
]