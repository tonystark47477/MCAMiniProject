import os
from django import forms
from django.contrib.auth.forms import (
    UserCreationForm, AuthenticationForm, PasswordResetForm, SetPasswordForm
)
from django.core.exceptions import ValidationError
from accounts.models import CustomUser
from core.models import Panchayat


def validate_verification_document(file):
    max_mb = 5
    if file.size > max_mb * 1024 * 1024:
        raise ValidationError(f'File size must not exceed {max_mb} MB.')
    allowed_extensions = ['.pdf', '.jpg', '.jpeg', '.png']
    ext = os.path.splitext(file.name)[1].lower()
    if ext not in allowed_extensions:
        raise ValidationError('Only PDF, JPG, and PNG documents are accepted for verification proof.')


class BootstrapMixin:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            widget = field.widget
            if isinstance(widget, forms.CheckboxInput):
                widget.attrs['class'] = 'form-check-input'
            elif isinstance(widget, (forms.Select, forms.SelectMultiple)):
                widget.attrs['class'] = 'form-select'
            else:
                widget.attrs['class'] = 'form-control'
            widget.attrs['placeholder'] = field.label or name.replace('_', ' ').title()


class LoginForm(BootstrapMixin, AuthenticationForm):
    remember_me = forms.BooleanField(required=False, label='Keep me signed in')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs['placeholder'] = 'Username'
        self.fields['password'].widget.attrs['placeholder'] = 'Password'


class GovernmentRegisterForm(BootstrapMixin, UserCreationForm):
    class Meta:
        model = CustomUser
        fields = ('username', 'first_name', 'last_name', 'email', 'phone',
                  'password1', 'password2')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = CustomUser.Role.GOVERNMENT
        if commit:
            user.save()
        return user


class AshaRegisterForm(BootstrapMixin, UserCreationForm):
    panchayat             = forms.ModelChoiceField(
        queryset=Panchayat.objects.all(),
        empty_label='Select Panchayat'
    )
    worker_id             = forms.CharField(max_length=50, required=False, label='Worker ID')
    verification_document = forms.FileField(
        required=False,
        label='Supporting Proof Document (PDF, JPG, PNG — max 5MB)',
        help_text='Upload ASHA appointment letter or official identification card.'
    )
    address               = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}),
                                            required=False)

    class Meta:
        model = CustomUser
        fields = ('username', 'first_name', 'last_name', 'email', 'phone',
                  'password1', 'password2', 'panchayat', 'worker_id',
                  'verification_document', 'address')

    def clean_verification_document(self):
        doc = self.cleaned_data.get('verification_document')
        if doc:
            validate_verification_document(doc)
        return doc

    def save(self, commit=True):
        from asha.models import AshaWorkerProfile
        user = super().save(commit=False)
        user.role = CustomUser.Role.ASHA_WORKER
        if commit:
            user.save()
            AshaWorkerProfile.objects.create(
                user=user,
                panchayat=self.cleaned_data['panchayat'],
                worker_id=self.cleaned_data.get('worker_id', ''),
                verification_document=self.cleaned_data.get('verification_document'),
                address=self.cleaned_data.get('address', ''),
                verification_status=AshaWorkerProfile.VerificationStatus.PENDING,
                is_active=False
            )
        return user


class DoctorRegisterForm(BootstrapMixin, UserCreationForm):
    from doctor.models import DoctorProfile
    SPECIALIZATION_CHOICES = [
        ('general',    'General Physician'),
        ('pediatrics', 'Pediatrics'),
        ('gynecology', 'Gynecology & Obstetrics'),
        ('nutrition',  'Nutrition'),
        ('other',      'Other'),
    ]
    specialization              = forms.ChoiceField(choices=SPECIALIZATION_CHOICES)
    qualification               = forms.CharField(max_length=200, required=False)
    hospital                    = forms.CharField(max_length=200, required=False)
    experience_years            = forms.IntegerField(min_value=0, initial=0)
    medical_registration_number = forms.CharField(
        max_length=100, required=False, label='Medical Registration / Council Number',
        help_text='State Medical Council or NMC/MCI registration number.'
    )
    verification_document       = forms.FileField(
        required=False, label='Supporting Proof Document (PDF, JPG, PNG — max 5MB)',
        help_text='Upload medical degree certificate or council registration document.'
    )
    bio                         = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}),
                                                 required=False)

    class Meta:
        model = CustomUser
        fields = ('username', 'first_name', 'last_name', 'email', 'phone',
                  'password1', 'password2', 'specialization', 'qualification',
                  'hospital', 'experience_years', 'medical_registration_number',
                  'verification_document', 'bio')

    def clean_verification_document(self):
        doc = self.cleaned_data.get('verification_document')
        if doc:
            validate_verification_document(doc)
        return doc

    def save(self, commit=True):
        from doctor.models import DoctorProfile
        user = super().save(commit=False)
        user.role = CustomUser.Role.DOCTOR
        if commit:
            user.save()
            DoctorProfile.objects.create(
                user=user,
                specialization=self.cleaned_data['specialization'],
                qualification=self.cleaned_data.get('qualification', ''),
                hospital=self.cleaned_data.get('hospital', ''),
                experience_years=self.cleaned_data.get('experience_years', 0),
                medical_registration_number=self.cleaned_data.get('medical_registration_number', ''),
                verification_document=self.cleaned_data.get('verification_document'),
                bio=self.cleaned_data.get('bio', ''),
                verification_status=DoctorProfile.VerificationStatus.PENDING,
                is_active=False
            )
        return user



class MotherRegisterForm(BootstrapMixin, UserCreationForm):
    PREGNANCY_CHOICES = [
        ('pregnant',  'Pregnant'),
        ('postnatal', 'Postnatal'),
        ('lactating', 'Lactating'),
        ('other',     'Other'),
    ]
    BLOOD_GROUP_CHOICES = [
        ('', 'Select blood group (optional)'),
        ('A+','A+'),('A-','A-'),('B+','B+'),('B-','B-'),
        ('O+','O+'),('O-','O-'),('AB+','AB+'),('AB-','AB-'),
    ]
    date_of_birth     = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}), required=False)
    address           = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 2}), required=False)
    guardian_name     = forms.CharField(max_length=100, required=False)
    guardian_phone    = forms.CharField(max_length=15, required=False)
    pregnancy_status  = forms.ChoiceField(choices=PREGNANCY_CHOICES)
    expected_due_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}), required=False)
    blood_group       = forms.ChoiceField(choices=BLOOD_GROUP_CHOICES, required=False)

    class Meta:
        model = CustomUser
        fields = ('username', 'first_name', 'last_name', 'email', 'phone',
                  'password1', 'password2', 'date_of_birth', 'address',
                  'guardian_name', 'guardian_phone', 'pregnancy_status',
                  'expected_due_date', 'blood_group')

    def save(self, commit=True):
        from mother.models import MotherProfile
        user = super().save(commit=False)
        user.role = CustomUser.Role.MOTHER
        if commit:
            user.save()
            MotherProfile.objects.create(
                user=user,
                date_of_birth=self.cleaned_data.get('date_of_birth'),
                address=self.cleaned_data.get('address', ''),
                guardian_name=self.cleaned_data.get('guardian_name', ''),
                guardian_phone=self.cleaned_data.get('guardian_phone', ''),
                pregnancy_status=self.cleaned_data.get('pregnancy_status', 'other'),
                expected_due_date=self.cleaned_data.get('expected_due_date'),
                blood_group=self.cleaned_data.get('blood_group', '')
            )
        return user


class CustomPasswordResetForm(BootstrapMixin, PasswordResetForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['email'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Enter your registered email address',
            'autocomplete': 'email',
        })


class CustomSetPasswordForm(BootstrapMixin, SetPasswordForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['new_password1'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Enter new password',
        })
        self.fields['new_password2'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Confirm new password',
        })
