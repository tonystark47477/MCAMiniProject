from django.contrib.auth.models import AbstractUser
from django.db import models
from django.urls import reverse
from django.utils.translation import gettext_lazy as _


class CustomUser(AbstractUser):
    class Role(models.TextChoices):
        GOVERNMENT  = 'government',  _('Government Official')
        ASHA_WORKER = 'asha_worker', _('Asha Worker')
        DOCTOR      = 'doctor',      _('Doctor')
        MOTHER      = 'mother',      _('Mother')

    role  = models.CharField(max_length=20, choices=Role.choices, db_index=True, blank=True)
    phone = models.CharField(max_length=15, blank=True)

    class Meta:
        verbose_name        = 'User'
        verbose_name_plural = 'Users'

    # Role checks as properties (not methods — cleaner in templates)
    @property
    def is_government(self):  return self.role == self.Role.GOVERNMENT
    @property
    def is_asha_worker(self): return self.role == self.Role.ASHA_WORKER
    @property
    def is_doctor(self):      return self.role == self.Role.DOCTOR
    @property
    def is_mother(self):      return self.role == self.Role.MOTHER

    def get_dashboard_url(self):
        """Returns the correct dashboard URL based on role."""
        if self.role == self.Role.DOCTOR:
            profile = getattr(self, 'doctor_profile', None)
            if profile and not profile.is_approved:
                return reverse('doctor:verification_status')
            return reverse('doctor:dashboard')
        if self.role == self.Role.ASHA_WORKER:
            profile = getattr(self, 'asha_profile', None)
            if profile and not profile.is_approved:
                return reverse('asha:verification_status')
            return reverse('asha:dashboard')
        role_map = {
            self.Role.GOVERNMENT:  'government:dashboard',
            self.Role.MOTHER:      'mother:dashboard',
        }
        url_name = role_map.get(self.role)
        return reverse(url_name) if url_name else '/'

    def __str__(self):
        name = self.get_full_name() or self.username
        return f'{name} ({self.get_role_display()})' if self.role else name