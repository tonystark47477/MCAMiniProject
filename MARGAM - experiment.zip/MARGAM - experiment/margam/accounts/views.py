from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import (LoginForm, GovernmentRegisterForm, AshaRegisterForm,
                    DoctorRegisterForm, MotherRegisterForm)
from core.models import Notification


def login_view(request):
    if request.user.is_authenticated:
        return redirect(request.user.get_dashboard_url())
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            if not form.cleaned_data.get('remember_me'):
                request.session.set_expiry(0)
            return redirect(user.get_dashboard_url())
        else:
            messages.error(request, 'Invalid username or password.')
    else:
        form = LoginForm(request)
    return render(request, 'accounts/login.html', {'form': form})


def logout_view(request):
    logout(request)
    messages.success(request, 'You have been signed out.')
    return redirect('accounts:login')


def register_select(request):
    if request.user.is_authenticated:
        return redirect(request.user.get_dashboard_url())
    return render(request, 'accounts/register_select.html')


def _register_view(request, form_class, template_name, role_label):
    if request.user.is_authenticated:
        return redirect(request.user.get_dashboard_url())
    if request.method == 'POST':
        form = form_class(request.POST, request.FILES)
        if form.is_valid():
            user = form.save()
            if user.is_doctor:
                messages.info(
                    request,
                    f'Account created successfully! Your doctor registration has been submitted for Government verification. Please sign in.'
                )
            elif user.is_asha_worker:
                messages.info(
                    request,
                    f'Account created successfully! Your ASHA Worker registration has been submitted for Government verification. Please sign in.'
                )
            else:
                messages.success(
                    request,
                    f'Account created successfully! Welcome to MARGAM, {user.get_full_name() or user.username}. Please sign in.'
                )
            return redirect('accounts:login')
    else:
        form = form_class()
    role_slug = 'government' if 'Government' in role_label else 'asha_worker' if 'Asha' in role_label else 'doctor' if 'Doctor' in role_label else 'mother'
    return render(request, template_name, {'form': form, 'role_label': role_label, 'role_slug': role_slug})


def register_government(request):
    return _register_view(request, GovernmentRegisterForm,
                          'accounts/register_government.html', 'Government Official')

def register_asha(request):
    return _register_view(request, AshaRegisterForm,
                          'accounts/register_asha.html', 'Asha Worker')

def register_doctor(request):
    return _register_view(request, DoctorRegisterForm,
                          'accounts/register_doctor.html', 'Doctor')

def register_mother(request):
    return _register_view(request, MotherRegisterForm,
                          'accounts/register_mother.html', 'Mother')


@login_required
def notifications_view(request):
    notifications = Notification.objects.filter(
        recipient=request.user
    ).select_related('sender').order_by('-created_at')
    unread = notifications.filter(is_read=False)
    unread.update(is_read=True)
    return render(request, 'accounts/notifications.html',
                  {'notifications': notifications})


@login_required
def profile_view(request):
    return render(request, 'accounts/profile.html')
