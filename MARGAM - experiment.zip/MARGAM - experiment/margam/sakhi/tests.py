from datetime import date
from django.test import TestCase, Client
from django.urls import reverse
from accounts.models import CustomUser
from mother.models import MotherProfile, Booking
from asha.models import AshaWorkerProfile
from doctor.models import DoctorProfile
from core.models import Panchayat, Notification
from sakhi.bot import get_response


class SakhiRegressionTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.panchayat = Panchayat.objects.create(name='Panchayat S', district='District S')

        # ASHA
        self.asha_user = CustomUser.objects.create_user(
            username='asha_sakhi', password='password123', role=CustomUser.Role.ASHA_WORKER
        )
        self.asha_profile = AshaWorkerProfile.objects.create(
            user=self.asha_user, panchayat=self.panchayat, worker_id='ASHS001'
        )

        # Doctor
        self.doc_user = CustomUser.objects.create_user(
            username='doctor_sakhi', password='password123', role=CustomUser.Role.DOCTOR
        )
        self.doc_profile = DoctorProfile.objects.create(user=self.doc_user)

        # Mother
        self.mother_user = CustomUser.objects.create_user(
            username='mother_sakhi', password='password123', role=CustomUser.Role.MOTHER, first_name='Rani'
        )
        self.mother_profile = MotherProfile.objects.create(
            user=self.mother_user, asha_worker=self.asha_profile
        )

        # Active booking for doctor
        self.booking = Booking.objects.create(
            mother=self.mother_profile,
            doctor=self.doc_profile,
            appointment_date=date.today(),
            status=Booking.Status.CONFIRMED
        )

    def test_sakhi_chat_page(self):
        self.client.login(username='mother_sakhi', password='password123')
        response = self.client.get(reverse('sakhi:chat'))
        self.assertEqual(response.status_code, 200)

    def test_sakhi_chat_send_api(self):
        self.client.login(username='mother_sakhi', password='password123')
        resp = self.client.post(reverse('sakhi:chat_send_api'), {
            'content': 'What should I eat during pregnancy?'
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertIn('message', data)
        self.assertEqual(data['message']['role'], 'assistant')
        self.assertTrue(len(data['message']['content']) > 0)

    def test_sakhi_chat_reset(self):
        self.client.login(username='mother_sakhi', password='password123')
        self.client.post(reverse('sakhi:chat_send_api'), {'content': 'Hi'})
        resp_get = self.client.get(reverse('sakhi:chat_reset'))
        self.assertEqual(resp_get.status_code, 405)
        resp = self.client.post(reverse('sakhi:chat_reset'))
        self.assertRedirects(resp, reverse('sakhi:chat'))
        self.assertEqual(self.client.session.get('sakhi_conversation'), [])

    def test_sakhi_bot_logic(self):
        # 1. Knowledge retrieval
        resp = get_response("What foods are healthy while pregnant?")
        self.assertTrue(len(resp['answer']) > 0)
        self.assertEqual(resp['is_emergency'], False)

        # 2. Context blending
        context = {'last_category_raw': 'nutrition'}
        resp_followup = get_response("What about bananas?", context=context)
        self.assertTrue(len(resp_followup['answer']) > 0)

        # 3. Emergency detection
        resp_emerg = get_response("I have heavy bleeding and severe abdominal pain")
        self.assertTrue(resp_emerg['is_emergency'])

    def test_sakhi_emergency_alert_api(self):
        self.client.login(username='mother_sakhi', password='password123')
        resp = self.client.post(reverse('sakhi:trigger_emergency_alert_api'), {
            'issue': 'Heavy bleeding and high fever'
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertTrue(data['success'])

        # Verify Notification created for ASHA and Doctor
        asha_notif = Notification.objects.filter(recipient=self.asha_user).first()
        self.assertIsNotNone(asha_notif)
        self.assertIn('EMERGENCY ALERT', asha_notif.title)

        doc_notif = Notification.objects.filter(recipient=self.doc_user).first()
        self.assertIsNotNone(doc_notif)
        self.assertIn('EMERGENCY ALERT', doc_notif.title)
