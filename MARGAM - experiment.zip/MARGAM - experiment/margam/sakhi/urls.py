from django.urls import path

from . import views

app_name = 'sakhi'

urlpatterns = [
    path('', views.chat, name='chat'),
    path('send/', views.chat_send_api, name='chat_send_api'),
    path('reset/', views.chat_reset, name='chat_reset'),
    path('trigger_emergency_alert/', views.trigger_emergency_alert_api, name='trigger_emergency_alert_api'),
]
