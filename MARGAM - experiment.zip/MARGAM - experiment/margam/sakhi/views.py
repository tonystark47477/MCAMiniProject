from datetime import datetime
from django.utils import timezone
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.urls import reverse
from django.views.decorators.http import require_http_methods

from core.decorators import mother_required
from core.models import Notification
from .bot import get_response, get_suggested_questions


STARTER_SUGGESTIONS = [
    "🥗 What foods should I eat?",
    "💉 Which vaccine is next?",
    "🤰 Is back pain normal?",
    "👶 Baby movement",
    "💊 Can I take medicine?",
    "🚨 Emergency symptoms",
]


def _get_conversation(request):
    return request.session.setdefault('sakhi_conversation', [])


def _format_timestamp(value: datetime) -> str:
    return value.strftime('%I:%M %p').lstrip('0')


def _get_mother_context(user):
    context = {
        'mother_name': (user.first_name or user.get_full_name() or user.username).title(),
        'pregnancy_week': None,
        'baby_info': None,
        'asha_name': None,
        'proactive_cards': [
            {
                'icon': 'bi-droplet-fill text-info',
                'title': 'Hydration Goal',
                'text': 'Aim for 8–10 glasses of clean water daily for healthy amniotic fluid.',
            },
            {
                'icon': 'bi-egg-fried text-warning',
                'title': 'Daily Nutrition',
                'text': 'Include iron-rich spinach, lentils, and calcium in your daily diet.',
            },
        ],
    }

    if hasattr(user, 'mother_profile') and user.mother_profile:
        profile = user.mother_profile

        if profile.asha_worker and profile.asha_worker.user:
            context['asha_name'] = profile.asha_worker.user.get_full_name() or profile.asha_worker.user.username

        if profile.expected_due_date:
            days_left = (profile.expected_due_date - timezone.now().date()).days
            weeks = 40 - (days_left // 7)
            context['pregnancy_week'] = max(1, min(42, weeks))
            context['proactive_cards'].insert(0, {
                'icon': 'bi-heart-pulse text-danger',
                'title': 'Pregnancy Status',
                'text': f"You are currently in Week {context['pregnancy_week']} of your pregnancy journey.",
            })

        try:
            babies = profile.babies.all()
            if babies.exists():
                first_baby = babies.first()
                context['baby_info'] = f"{first_baby.name} ({first_baby.age_display})"
        except Exception:
            pass

        try:
            from mother.models import VaccinationRecord, Booking
            pending_vacs = VaccinationRecord.objects.filter(
                baby__mother=profile, status='pending'
            ).order_by('due_date')
            if pending_vacs.exists():
                next_vac = pending_vacs.first()
                vac_name = next_vac.schedule.vaccine_name if next_vac.schedule else 'Vaccine'
                context['proactive_cards'].insert(0, {
                    'icon': 'bi-shield-plus text-primary',
                    'title': 'Upcoming Vaccination',
                    'text': f"{vac_name} scheduled around {next_vac.due_date.strftime('%b %d')}.",
                })

            upcoming_booking = Booking.objects.filter(
                mother=profile,
                status__in=[Booking.Status.PENDING, Booking.Status.CONFIRMED]
            ).order_by('appointment_date').first()
            if upcoming_booking:
                doc_name = upcoming_booking.doctor.user.get_full_name() if upcoming_booking.doctor and upcoming_booking.doctor.user else "Doctor"
                context['proactive_cards'].insert(0, {
                    'icon': 'bi-calendar-check text-success',
                    'title': 'Doctor Appointment',
                    'text': f"Appointment with Dr. {doc_name} on {upcoming_booking.appointment_date.strftime('%b %d')}.",
                })
        except Exception:
            pass

    return context


@mother_required
def chat(request):
    conversation = _get_conversation(request)
    context = _get_mother_context(request.user)
    context.update({
        'conversation': conversation,
        'suggestions': STARTER_SUGGESTIONS,
        'send_url': reverse('sakhi:chat_send_api'),
        'reset_url': reverse('sakhi:chat_reset'),
        'alert_url': reverse('sakhi:trigger_emergency_alert_api'),
    })
    return render(request, 'sakhi/chat.html', context)


@mother_required
@require_http_methods(['POST'])
def chat_send_api(request):
    content = request.POST.get('content', '').strip()
    if not content:
        return JsonResponse({'error': 'Please enter a question.'}, status=400)

    conversation = _get_conversation(request)
    now = _format_timestamp(datetime.now())

    # Multi-turn conversational context blending
    bot_context = {}
    if conversation:
        for prev in reversed(conversation):
            if prev.get('role') == 'assistant' and prev.get('category_raw'):
                bot_context['last_category_raw'] = prev.get('category_raw')
                break

    conversation.append({
        'role': 'user',
        'content': content,
        'time': now,
    })

    response = get_response(content, context=bot_context)
    conversation.append({
        'role': 'assistant',
        'content': response['answer'],
        'time': _format_timestamp(datetime.now()),
        'confidence': response['confidence'],
        'confidence_level': response.get('confidence_level', 'High'),
        'is_emergency': response['is_emergency'],
        'category': response.get('category', '🛡️ Guidance Note'),
        'category_raw': response.get('category_raw', 'general'),
        'source': response.get('source', 'WHO / UNICEF / Government Maternal Health Dataset'),
        'related_questions': response.get('related_questions', []),
    })
    request.session['sakhi_conversation'] = conversation

    return JsonResponse({
        'message': conversation[-1],
        'conversation': conversation,
    })


@mother_required
@require_http_methods(['POST'])
def chat_reset(request):
    request.session['sakhi_conversation'] = []
    return redirect('sakhi:chat')


@mother_required
@require_http_methods(['POST'])
def trigger_emergency_alert_api(request):
    """
    Creates an explicit high-priority emergency alert notification in MARGAM's
    existing Notification system for the mother's assigned ASHA worker and doctor.
    """
    user = request.user
    if not hasattr(user, 'mother_profile') or not user.mother_profile:
        return JsonResponse({'error': 'Mother profile not found.'}, status=400)

    profile = user.mother_profile
    issue = request.POST.get('issue', '').strip() or 'Emergency symptom reported via Sakhi Assistant'
    now_str = datetime.now().strftime('%Y-%m-%d %I:%M %p')
    mother_name = user.get_full_name() or user.username

    recipients = []
    notified_names = []

    # 1. Assigned ASHA Worker
    if profile.asha_worker and profile.asha_worker.user:
        recipients.append(profile.asha_worker.user)
        asha_name = profile.asha_worker.user.get_full_name() or profile.asha_worker.user.username
        notified_names.append(f"ASHA Worker ({asha_name})")

    # 2. Assigned Doctor (if active booking exists)
    try:
        from mother.models import Booking
        active_booking = Booking.objects.filter(
            mother=profile,
            status__in=[Booking.Status.PENDING, Booking.Status.CONFIRMED]
        ).select_related('doctor__user').first()
        if active_booking and active_booking.doctor and active_booking.doctor.user:
            doc_user = active_booking.doctor.user
            if doc_user not in recipients:
                recipients.append(doc_user)
                doc_name = doc_user.get_full_name() or doc_user.username
                notified_names.append(f"Dr. {doc_name}")
    except Exception:
        pass

    if not recipients:
        return JsonResponse({
            'error': 'No assigned ASHA Worker or Doctor found. Please contact nearest emergency hospital directly.'
        }, status=400)

    alert_title = f"🚨 EMERGENCY ALERT: {mother_name}"
    alert_message = (
        f"🚨 EMERGENCY ALERT\n\n"
        f"Mother: {mother_name}\n"
        f"Guardian Contact: {profile.guardian_name} ({profile.guardian_phone})\n"
        f"Issue Description: {issue}\n"
        f"Time: {now_str}\n"
        f"Priority: HIGH\n\n"
        f"Please check on this mother immediately."
    )

    created_count = 0
    for r in recipients:
        Notification.objects.create(
            sender=user,
            recipient=r,
            title=alert_title,
            message=alert_message,
            notif_type=Notification.NotifType.GENERAL,
        )
        created_count += 1

    return JsonResponse({
        'success': True,
        'message': f"Emergency alert created successfully for {', '.join(notified_names)}.",
        'recipients': notified_names,
    })
