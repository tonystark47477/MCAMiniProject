import math
import re
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional

try:
    from rapidfuzz import fuzz, process
    RAPIDFUZZ_AVAILABLE = True
except ImportError:
    RAPIDFUZZ_AVAILABLE = False

STOP_WORDS = {
    'a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from', 'has',
    'have', 'in', 'is', 'it', 'its', 'of', 'on', 'or', 'that', 'the',
    'this', 'to', 'was', 'were', 'what', 'when', 'which', 'with', 'you',
    'your', 'how', 'can', 'should', 'my', 'about', 'during', 'while', 'if',
    'do', 'i', 'me', 'also', 'may', 'will', 'need', 'please', 'tell', 'give',
    'suggest', 'get', 'any', 'some'
}

EMERGENCY_TERMS = {
    'bleeding', 'heavy bleeding', 'spotting', 'severe pain', 'sharp pain',
    'abdominal pain', 'stomach pain', 'severe cramps', 'contraction', 'contractions',
    'dizziness', 'faint', 'fainting', 'unconscious', 'unconsciousness',
    'shortness of breath', 'difficulty breathing', 'gasping', 'convulsion', 'seizure',
    'seizures', 'swelling', 'sudden swelling', 'face swelling', 'hand swelling',
    'blurred vision', 'loss of vision', 'seeing spots', 'headache', 'severe headache',
    'fever', 'high fever', 'chills', 'leakage', 'water broke', 'fluid leak',
    'fast heart', 'heart racing', 'chest pain', 'severe chest pain', 'panic',
    'reduced movement', 'no movement', 'baby not moving', 'decreased movement',
    'fetal movement decrease', 'vomiting blood'
}

EMERGENCY_PATTERNS = [
    re.compile(r'\b(?:baby|fetal|fetus|infant|child)\b.*\b(?:not moving|no movement|decreased movement|reduced movement|less movement|no kicks|not felt|not feel)\b'),
    re.compile(r'\b(?:not moving|no movement|no kicks|decreased movement|reduced movement|less movement|not felt|not feel)\b'),
]

SYNONYMS = {
    'eat': ['food', 'diet', 'meal', 'nutrition', 'healthy', 'eating', 'hungry', 'fruit', 'vegetable', 'banana', 'apple', 'spinach', 'lentil', 'calcium', 'iron'],
    'food': ['eat', 'diet', 'meal', 'nutrition', 'healthy', 'eating', 'banana', 'fruit', 'vegetable'],
    'diet': ['eat', 'food', 'meal', 'nutrition', 'healthy', 'eating'],
    'banana': ['food', 'eat', 'fruit', 'diet', 'nutrition', 'healthy'],
    'healthy': ['eat', 'food', 'diet', 'nutrition', 'safe', 'meal', 'fruit', 'vegetable'],
    'vaccine': ['vaccination', 'injection', 'shot', 'td', 'tt', 'bcg', 'opv', 'immunization', 'dose', 'schedule'],
    'vaccination': ['vaccine', 'injection', 'shot', 'td', 'tt', 'bcg', 'opv', 'immunization', 'dose'],
    'pain': ['ache', 'sore', 'cramps', 'discomfort', 'hurt', 'backache', 'headache'],
    'back': ['backache', 'spine', 'posture', 'lower back'],
    'medicine': ['medication', 'drug', 'tablet', 'pill', 'painkiller', 'prescription', 'syrup', 'safe', 'remedy'],
    'safe': ['safety', 'precaution', 'allowed', 'medicine', 'exercise'],
    'exercise': ['workout', 'walk', 'walking', 'yoga', 'stretch', 'stretching', 'physical activity', 'movement'],
    'moving': ['movement', 'baby', 'fetal', 'kick', 'kicks', 'activity'],
    'baby': ['newborn', 'child', 'infant', 'fetal', 'fetus', 'kick', 'kicks', 'movement', 'moving'],
    'breastfeed': ['breastfeeding', 'lactation', 'milk', 'latch', 'nursing', 'feed', 'feeding'],
    'scheme': ['pmmvy', 'jsy', 'government', 'money', 'benefit', 'financial', 'support', 'assistance', 'mcp'],
    'doctor': ['asha', 'checkup', 'appointment', 'visit', 'hospital', 'clinic', 'consult'],
}

CATEGORY_KEYWORDS = {
    'nutrition': {'eat', 'food', 'diet', 'nutrition', 'healthy', 'fruit', 'vegetable', 'meal', 'iron', 'calcium', 'protein', 'lentil', 'banana'},
    'vaccination': {'vaccine', 'vaccination', 'immunization', 'shot', 'dose', 'tt', 'td', 'bcg', 'opv'},
    'pregnancy': {'pregnant', 'pregnancy', 'backache', 'back pain', 'trimester', 'due date', 'gestation', 'morning sickness'},
    'symptoms': {'pain', 'ache', 'cramps', 'fever', 'nausea', 'dizziness', 'headache', 'vomit', 'nauseous'},
    'baby': {'baby', 'newborn', 'child', 'infant', 'kick', 'kicks', 'movement', 'moving', 'fetal', 'fetus'},
    'medicine': {'medicine', 'medication', 'tablet', 'pill', 'painkiller', 'prescription', 'pill', 'safe'},
    'exercise': {'exercise', 'walk', 'walking', 'yoga', 'stretch', 'activity', 'workout'},
    'breastfeeding': {'breastfeed', 'breastfeeding', 'lactation', 'milk', 'feed', 'nursing'},
    'postnatal': {'postnatal', 'after delivery', 'delivery', 'birth', 'recovery'},
    'schemes': {'scheme', 'pmmvy', 'jsy', 'government', 'benefit', 'support'},
    'appointments': {'appointment', 'checkup', 'clinic', 'hospital', 'visit', 'doctor', 'booking'},
    'care': {'emergency', 'urgent', 'bleeding', 'pain', 'swelling', 'fever', 'movement', 'not moving'},
}

MATCH_THRESHOLD = 0.12

@dataclass(frozen=True)
class KnowledgeItem:
    question: str
    answer: str
    category: str
    tags: str = ''


KNOWLEDGE_ENTRIES: List[KnowledgeItem] = [
    # 🥗 Nutrition
    KnowledgeItem(
        question="What should I eat during pregnancy?",
        answer=(
            "Choose balanced meals rich in iron, protein, calcium, and vitamins. "
            "Eat green leafy vegetables (spinach), lentils, whole grains, eggs, fruits (like bananas and oranges), and dairy products. "
            "Drink 8–10 glasses of water daily and take your iron-folic acid tablets as prescribed by your health worker."
        ),
        category="nutrition",
        tags="diet food pregnancy nutrition healthy meals eat vegetables iron folic acid fruit banana meal nourishment",
    ),
    KnowledgeItem(
        question="Are fruits like bananas, apples, and oranges safe during pregnancy?",
        answer=(
            "Yes! Fresh fruits such as bananas, apples, oranges, and pomegranates are very healthy during pregnancy. "
            "They provide essential potassium, dietary fiber, vitamin C, and natural energy. Always wash fruits thoroughly before eating."
        ),
        category="nutrition",
        tags="fruits banana apple orange healthy food diet snacks vitamins potassium fiber safe fruit",
    ),
    KnowledgeItem(
        question="What foods should I avoid while pregnant?",
        answer=(
            "Avoid raw or undercooked meat and eggs, unpasteurized milk or cheese, raw papaya, unwashed raw vegetables, and excessive caffeine. "
            "Completely avoid alcohol, tobacco, and self-prescribed medications."
        ),
        category="nutrition",
        tags="avoid bad food unsafe papaya raw egg alcohol caffeine diet safety risk",
    ),

    # 💉 Vaccination
    KnowledgeItem(
        question="Which vaccine is next for me or my baby?",
        answer=(
            "During pregnancy, two doses of Td (Tetanus & Diphtheria) vaccine or a booster dose are given. "
            "At birth, your baby receives BCG, OPV-0, and Hepatitis B-0. "
            "Subsequent pentavalent and rotavirus doses are due at 6, 10, and 14 weeks. Check your MCP card or ask your ASHA worker for your exact schedule."
        ),
        category="vaccination",
        tags="vaccine vaccination schedule tt td bcg opv injection immunization next dose child baby schedule",
    ),
    KnowledgeItem(
        question="Why is the Td vaccine important in pregnancy?",
        answer=(
            "The Td (Tetanus & Diphtheria) vaccine protects both mother and newborn baby against maternal and neonatal tetanus, a serious infection. "
            "It is given early in pregnancy and repeated 4 weeks later or given as a booster if previously vaccinated."
        ),
        category="vaccination",
        tags="td tetanus vaccine injection maternal protection safety dose pregnant",
    ),

    # 🤰 Pregnancy Care & Symptoms
    KnowledgeItem(
        question="Is back pain normal during pregnancy?",
        answer=(
            "Mild back pain is common as your body weight increases and ligaments soften. "
            "Practice good posture, avoid lifting heavy objects, wear flat comfortable footwear, and rest with a pillow supporting your back or between your knees. Contact your doctor if pain is severe or persistent."
        ),
        category="pregnancy",
        tags="back pain spine posture cramps body ache pregnancy normal pain symptom posture lumbar",
    ),
    KnowledgeItem(
        question="How can I manage morning sickness and nausea?",
        answer=(
            "Eat small, frequent meals throughout the day instead of heavy meals. "
            "Keep dry crackers or toast by your bed, sip lemon water or ginger tea, and avoid fried or strong-smelling foods. Consult your doctor if you cannot retain fluids."
        ),
        category="symptoms",
        tags="nausea morning sickness vomit sick feeling dizzy appetite ginger toast morning relief",
    ),
    KnowledgeItem(
        question="What should I do if I feel dizzy or lightheaded?",
        answer=(
            "Sit or lie down on your left side immediately to increase blood flow to your baby. "
            "Sip clean water, avoid standing up rapidly, and do not skip meals. If dizziness persists, is accompanied by blurred vision, or causes fainting, seek medical care right away."
        ),
        category="symptoms",
        tags="dizzy faint lightheaded balance weakness blood pressure fainting symptoms",
    ),

    # 👶 Baby Care & Movement
    KnowledgeItem(
        question="How do I know if my baby is moving normally?",
        answer=(
            "From week 20–24 onwards, feel for regular kicks, rolls, or flutters. "
            "You should notice regular movement, especially after meals or when resting quietly. If you notice a sudden decrease or absence of baby movement, contact your ASHA worker or doctor immediately."
        ),
        category="baby",
        tags="baby movement kicks fetal activity monitoring baby moving normal count fetal kick count",
    ),
    KnowledgeItem(
        question="How can I keep my newborn baby warm safely?",
        answer=(
            "Practice Kangaroo Mother Care (skin-to-skin contact) on your chest. "
            "Dress baby in soft warm layers including a cap and socks. Keep baby away from cold drafts and avoid heavy blankets that could cover baby's face."
        ),
        category="baby",
        tags="baby warmth skin to skin KMC newborn care warmth temperature safe baby cover cold",
    ),

    # 💊 Medicine Safety
    KnowledgeItem(
        question="Can I take medicine during pregnancy?",
        answer=(
            "Never take self-prescribed over-the-counter tablets, painkillers, or antibiotics during pregnancy. "
            "Always consult your doctor or ASHA worker before taking any medication to ensure it is 100% safe for your baby."
        ),
        category="medicine",
        tags="medicine medication drug tablet painkiller safe doctor prescription pill OTC safe take",
    ),
    KnowledgeItem(
        question="Should I continue taking Iron and Folic Acid (IFA) tablets?",
        answer=(
            "Yes! Iron and Folic Acid (IFA) tablets prevent maternal anemia and support healthy baby growth. "
            "Take your daily IFA tablet with water after a meal (not with milk or tea). Continue as advised by your healthcare worker."
        ),
        category="medicine",
        tags="iron folic acid ifa tablet supplement calcium anemia safe blood daily",
    ),

    # 🧘 Exercise
    KnowledgeItem(
        question="What safe exercises can I do during pregnancy?",
        answer=(
            "Gentle walking for 20-30 minutes daily, mild pelvic floor exercises (Kegels), and prenatal stretching are usually very safe and beneficial. "
            "Avoid high-impact jumping, heavy lifting, or sports with falling risks. Stop immediately if you feel pain, dizziness, or shortness of breath."
        ),
        category="exercise",
        tags="exercise movement pregnancy safe workout walking prenatal stretching kegels activity active",
    ),

    # 🤱 Breastfeeding & Postnatal Care
    KnowledgeItem(
        question="How soon should I start breastfeeding after delivery?",
        answer=(
            "Initiate breastfeeding within 1 hour of birth (golden hour). "
            "Colostrum (first thick yellowish milk) is rich in antibodies and acts as baby's first natural vaccine. Feed on demand day and night."
        ),
        category="breastfeeding",
        tags="breastfeeding lactation colostrum golden hour milk newborn latch feed nursing mother",
    ),
    KnowledgeItem(
        question="What care is needed after delivery (postnatal period)?",
        answer=(
            "Rest as much as possible, eat nutritious meals, drink plenty of water, and keep your hygiene clean. "
            "Ensure postnatal health checkups at 48 hours, day 7, and week 6. Watch for warning signs like heavy bleeding or fever."
        ),
        category="postnatal",
        tags="postnatal delivery recovery care checkup 48 hours fever bleeding resting mother heal",
    ),

    # 🏛️ Government Schemes
    KnowledgeItem(
        question="What government schemes are available for mothers?",
        answer=(
            "Key government maternal schemes include: "
            "1. Pradhan Mantri Matru Vandana Yojana (PMMVY): Cash incentive for pregnant & lactating mothers. "
            "2. Janani Suraksha Yojana (JSY): Financial support for hospital delivery. "
            "3. PMSMA: Free monthly health checkups. Contact your ASHA worker for registration guidance."
        ),
        category="schemes",
        tags="government scheme pmmvy jsy financial assistance benefit asha registry card maternal money support checkup",
    ),

    # 🏥 Appointments & Checkups
    KnowledgeItem(
        question="How should I prepare for my antenatal clinic visit?",
        answer=(
            "Bring your Mother & Child Protection (MCP) card, ID proof, prior prescription slips, and a written list of any questions or symptoms you have. "
            "Wear comfortable loose clothing and eat a light snack before going."
        ),
        category="appointments",
        tags="antenatal visit appointment prepare checklist mcp card checkup doctor clinic hospital",
    ),

    # 🚨 Emergency Guidance
    KnowledgeItem(
        question="What are emergency warning signs during pregnancy?",
        answer=(
            "Emergency warning signs include heavy vaginal bleeding, severe abdominal pain, sudden swelling of face or hands, high fever, severe headache with blurred vision, or decreased baby movement. Seek immediate hospital care."
        ),
        category="care",
        tags="emergency warning signs danger symptoms bleeding severe pain hospital doctor urgent hospital care",
    ),
]

FALLBACK_RESPONSE = (
    "I want to make sure you receive accurate guidance.\n"
    "I couldn't find a direct verified record for that specific phrasing.\n"
    "Please consult your Doctor or ASHA Worker for personal health advice."
)

EMERGENCY_RESPONSE = (
    "🚨 IMMEDIATE MEDICAL ASSESSMENT RECOMMENDED 🚨\n\n"
    "You reported symptoms that may require urgent healthcare assessment (such as bleeding, severe pain, high fever, or reduced baby movement).\n\n"
    "Please contact your Doctor or assigned ASHA worker immediately, or visit the nearest healthcare facility."
)

CATEGORY_DISPLAY_MAP = {
    'nutrition': '🥗 Nutrition & Diet',
    'vaccination': '💉 Vaccination',
    'pregnancy': '🤰 Pregnancy Care',
    'symptoms': '🌸 Pregnancy Symptoms',
    'baby': '👶 Baby Care',
    'medicine': '💊 Medicine Safety',
    'exercise': '🧘 Safe Exercise',
    'breastfeeding': '🤱 Breastfeeding',
    'postnatal': '🏥 Postnatal Care',
    'schemes': '🏛️ Government Schemes',
    'appointments': '📅 Doctor Appointments',
    'care': '🚨 Emergency & Medical Care',
    'general': '🛡️ General Health',
}


def normalize_text(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def expand_synonyms(tokens: List[str]) -> List[str]:
    expanded = list(tokens)
    for token in tokens:
        if token in SYNONYMS:
            expanded.extend(SYNONYMS[token])
    return expanded


def tokenize(text: str) -> List[str]:
    normalized = normalize_text(text)
    raw_tokens = [t for t in normalized.split() if t and t not in STOP_WORDS]
    return expand_synonyms(raw_tokens)


def term_frequency(tokens: List[str]) -> Dict[str, float]:
    frequencies: Dict[str, float] = {}
    for token in tokens:
        frequencies[token] = frequencies.get(token, 0.0) + 1.0
    return frequencies


def build_index() -> Tuple[List[Dict[str, float]], Dict[str, float], List[float]]:
    document_tfs: List[Dict[str, float]] = []
    document_vectors: List[Dict[str, float]] = []
    document_norms: List[float] = []
    df: Dict[str, int] = {}

    for item in KNOWLEDGE_ENTRIES:
        tokens = tokenize(item.question + ' ' + item.tags + ' ' + item.category)
        tf = term_frequency(tokens)
        document_tfs.append(tf)
        for token in set(tokens):
            df[token] = df.get(token, 0) + 1

    total_docs = len(KNOWLEDGE_ENTRIES)
    idf = {
        token: math.log((total_docs + 1) / (count + 1)) + 1
        for token, count in df.items()
    }

    for tf in document_tfs:
        vector = {token: value * idf[token] for token, value in tf.items()}
        document_vectors.append(vector)
        document_norms.append(math.sqrt(sum(val * val for val in vector.values())))

    return document_vectors, idf, document_norms


DOCUMENT_VECTORS, IDF_INDEX, DOCUMENT_NORMS = build_index()


def build_query_vector(query: str) -> Tuple[Dict[str, float], float]:
    tokens = tokenize(query)
    tf = term_frequency(tokens)
    vector = {token: tf[token] * IDF_INDEX.get(token, 1.0) for token in tf}
    norm = math.sqrt(sum(value * value for value in vector.values()))
    return vector, norm


def cosine_similarity(a: Dict[str, float], a_norm: float, b: Dict[str, float], b_norm: float) -> float:
    if a_norm < 1e-9 or b_norm < 1e-9:
        return 0.0
    dot = sum(a.get(token, 0.0) * b.get(token, 0.0) for token in a)
    return dot / (a_norm * b_norm)


def contains_emergency_terms(text: str) -> bool:
    lower = text.lower()
    if any(pattern.search(lower) for pattern in EMERGENCY_PATTERNS):
        return True
    for term in EMERGENCY_TERMS:
        if re.search(rf'\b{re.escape(term)}\b', lower):
            return True
    return False


def detect_intent_category(query: str) -> Optional[str]:
    normalized = normalize_text(query)
    for category, keywords in CATEGORY_KEYWORDS.items():
        for keyword in keywords:
            if keyword in normalized:
                return category
    return None


def _find_best_match(query: str, context_category: Optional[str] = None) -> Tuple[KnowledgeItem, float]:
    augmented_query = query
    if context_category and len(query.split()) <= 4:
        augmented_query = f"{query} {context_category}"

    if RAPIDFUZZ_AVAILABLE:
        questions = [f"{item.question} {item.tags}" for item in KNOWLEDGE_ENTRIES]
        match = process.extractOne(augmented_query, questions, scorer=fuzz.token_set_ratio)
        if match:
            index = match[2] if len(match) > 2 else 0
            score = float(match[1]) / 100.0
            best_item = KNOWLEDGE_ENTRIES[index]
            if context_category and best_item.category == context_category:
                score = min(1.0, score + 0.1)
            return best_item, score

    query_vector, query_norm = build_query_vector(augmented_query)
    best_item = KNOWLEDGE_ENTRIES[0]
    best_score = 0.0

    for item, document_vector, document_norm in zip(KNOWLEDGE_ENTRIES, DOCUMENT_VECTORS, DOCUMENT_NORMS):
        score = cosine_similarity(query_vector, query_norm, document_vector, document_norm)
        if context_category and item.category == context_category:
            score = min(1.0, score + 0.08)
        if score > best_score:
            best_item = item
            best_score = score

    return best_item, best_score


def get_suggested_questions(limit: int = 6) -> List[str]:
    return [item.question for item in KNOWLEDGE_ENTRIES[:limit]]


def get_related_questions(current_question: str, category: str = '', limit: int = 3) -> List[str]:
    related: List[str] = []
    for item in KNOWLEDGE_ENTRIES:
        if item.question != current_question and item.category == category:
            related.append(item.question)
            if len(related) >= limit:
                return related
    for item in KNOWLEDGE_ENTRIES:
        if item.question != current_question and item.question not in related:
            related.append(item.question)
            if len(related) >= limit:
                break
    return related[:limit]


def get_response(query: str, context: Optional[dict] = None) -> Dict[str, object]:
    context_category = None
    if context and isinstance(context, dict):
        context_category = context.get('last_category_raw')

    detected_category = detect_intent_category(query)
    if detected_category:
        context_category = detected_category

    if not query or not query.strip():
        return {
            'answer': FALLBACK_RESPONSE,
            'confidence': 35,
            'confidence_level': 'Medium',
            'is_emergency': False,
            'source': 'WHO / UNICEF / Government Maternal Health Dataset',
            'category': '🛡️ General Care',
            'category_raw': 'general',
            'related_questions': get_related_questions('', limit=3),
        }

    if contains_emergency_terms(query):
        return {
            'answer': EMERGENCY_RESPONSE,
            'confidence': 100,
            'confidence_level': 'High',
            'is_emergency': True,
            'source': 'Emergency Healthcare Protocol',
            'category': '🚨 Emergency Guidance',
            'category_raw': 'care',
            'related_questions': [
                "When should I contact my doctor or ASHA worker?",
                "What are emergency warning signs during pregnancy?",
                "How should I prepare for my antenatal clinic visit?",
            ],
        }

    best_item, relevance = _find_best_match(query, context_category=context_category)
    confidence = min(98, max(30, int(relevance * 100)))

    if relevance < MATCH_THRESHOLD:
        return {
            'answer': FALLBACK_RESPONSE,
            'confidence': confidence,
            'confidence_level': 'Medium',
            'is_emergency': False,
            'source': 'WHO / UNICEF / Government Maternal Health Dataset',
            'category': '🛡️ Guidance Note',
            'category_raw': 'general',
            'related_questions': get_related_questions(best_item.question, limit=3),
        }

    category_label = CATEGORY_DISPLAY_MAP.get(best_item.category, '🌸 Health Care')
    conf_level = 'High' if confidence >= 55 else 'Medium'

    return {
        'answer': best_item.answer,
        'confidence': confidence,
        'confidence_level': conf_level,
        'is_emergency': best_item.category == 'care',
        'source': 'WHO / UNICEF / Government Maternal Health Dataset',
        'category': category_label,
        'category_raw': best_item.category,
        'related_questions': get_related_questions(best_item.question, best_item.category, limit=3),
    }
