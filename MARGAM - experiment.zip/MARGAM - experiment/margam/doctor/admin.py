from django.contrib import admin
from .models import DoctorProfile, DoctorAvailability

@admin.register(DoctorProfile)
class DoctorProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'specialization', 'hospital', 'medical_registration_number', 'verification_status', 'is_active')
    list_filter = ('verification_status', 'specialization', 'is_active')
    search_fields = ('user__first_name', 'user__last_name', 'hospital', 'medical_registration_number')

@admin.register(DoctorAvailability)
class DoctorAvailabilityAdmin(admin.ModelAdmin):
    list_display = ('doctor', 'day_of_week', 'start_time', 'end_time', 'is_available')
    list_filter = ('day_of_week', 'is_available')
