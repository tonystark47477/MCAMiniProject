from datetime import date

from django import forms as dj_forms
from django.contrib import messages
from django.core.exceptions import ObjectDoesNotExist
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from django.views.decorators.http import require_http_methods

from core.decorators import doctor_required, role_required
from core.models import Food, HealthTip, Notification
from doctor.models import DoctorAvailability, DoctorProfile
from mother.models import Booking, MotherProfile, VaccinationRecord


@doctor_required
def dashboard(request):
    doctor = request.user.doctor_profile
    today = timezone.now().date()
    today_bookings = Booking.objects.filter(
        doctor=doctor,
        appointment_date=today,
        status=Booking.Status.CONFIRMED,
    ).select_related('mother__user')
    pending_bookings = Booking.objects.filter(
        doctor=doctor,
        status=Booking.Status.PENDING,
    ).select_related('mother__user').order_by('appointment_date')
    total_bookings = Booking.objects.filter(doctor=doctor).count()
    completed_this_month = Booking.objects.filter(
        doctor=doctor,
        status=Booking.Status.COMPLETED,
        appointment_date__month=today.month,
        appointment_date__year=today.year,
    ).count()
    return render(request, 'doctor/dashboard.html', {
        'today_bookings': today_bookings,
        'pending_bookings': pending_bookings,
        'total_bookings': total_bookings,
        'completed_this_month': completed_this_month,
    })


@doctor_required
def bookings(request):
    doctor = request.user.doctor_profile
    tab = request.GET.get('tab', 'pending')
    all_bookings = Booking.objects.filter(
        doctor=doctor,
    ).select_related('mother__user').order_by('-appointment_date')
    if tab == 'pending':
        bookings_qs = all_bookings.filter(status=Booking.Status.PENDING)
    elif tab == 'confirmed':
        bookings_qs = all_bookings.filter(status=Booking.Status.CONFIRMED)
    elif tab == 'completed':
        bookings_qs = all_bookings.filter(status=Booking.Status.COMPLETED)
    elif tab == 'rejected':
        bookings_qs = all_bookings.filter(status=Booking.Status.REJECTED)
    else:
        bookings_qs = all_bookings
    return render(request, 'doctor/bookings.html', {
        'bookings': bookings_qs,
        'active_tab': tab,
        'tabs': [
            ('pending', 'Pending'),
            ('confirmed', 'Confirmed'),
            ('completed', 'Completed'),
            ('rejected', 'Rejected'),
            ('all', 'All'),
        ]
    })


@doctor_required
def booking_detail(request, pk):
    doctor = request.user.doctor_profile
    booking = get_object_or_404(Booking, pk=pk, doctor=doctor)
    return render(request, 'doctor/booking_detail.html', {
        'booking': booking,
    })


@doctor_required
@require_http_methods(['POST'])
def booking_confirm(request, pk):
    doctor = request.user.doctor_profile
    booking = get_object_or_404(Booking, pk=pk, doctor=doctor)
    booking.status = Booking.Status.CONFIRMED
    booking.save(update_fields=['status'])
    Notification.objects.create(
        sender=request.user,
        recipient=booking.mother.user,
        title='Appointment Confirmed',
        message=f'Your appointment on {booking.appointment_date} has been confirmed.',
        notif_type=Notification.NotifType.APPOINTMENT,
    )
    messages.success(request, 'Appointment confirmed.')
    return redirect('doctor:booking_detail', pk=pk)


@doctor_required
@require_http_methods(['POST'])
def booking_reject(request, pk):
    doctor = request.user.doctor_profile
    booking = get_object_or_404(Booking, pk=pk, doctor=doctor)
    reason = request.POST.get('rejection_reason', '') or request.POST.get('reason', '')
    booking.status = Booking.Status.REJECTED
    booking.rejection_reason = reason
    booking.save(update_fields=['status', 'rejection_reason'])
    Notification.objects.create(
        sender=request.user,
        recipient=booking.mother.user,
        title='Appointment Rejected',
        message=f'Your appointment on {booking.appointment_date} was rejected. Reason: {reason}',
        notif_type=Notification.NotifType.APPOINTMENT,
    )
    messages.warning(request, 'Appointment rejected.')
    return redirect('doctor:bookings')


@doctor_required
@require_http_methods(['POST'])
def booking_complete(request, pk):
    doctor = request.user.doctor_profile
    booking = get_object_or_404(Booking, pk=pk, doctor=doctor)
    if booking.status != Booking.Status.CONFIRMED:
        messages.error(request, 'Only confirmed appointments can be marked as completed.')
        return redirect('doctor:booking_detail', pk=pk)
    booking.status = Booking.Status.COMPLETED
    booking.save(update_fields=['status'])
    messages.success(request, 'Booking marked as completed.')
    return redirect('doctor:booking_detail', pk=pk)


@doctor_required
@require_http_methods(['POST'])
def booking_review(request, pk):
    doctor = request.user.doctor_profile
    booking = get_object_or_404(Booking, pk=pk, doctor=doctor)
    if booking.status != Booking.Status.COMPLETED:
        messages.error(request, 'Consultation review can only be submitted for completed appointments.')
        return redirect('doctor:booking_detail', pk=pk)
    doctor_notes = request.POST.get('doctor_notes', '').strip()
    if not doctor_notes:
        messages.warning(request, 'Consultation review cannot be empty.')
        return redirect('doctor:booking_detail', pk=pk)
    booking.doctor_notes = doctor_notes
    booking.save(update_fields=['doctor_notes'])
    messages.success(request, 'Consultation review saved successfully.')
    return redirect('doctor:booking_detail', pk=pk)


class AvailabilityForm(dj_forms.Form):
    days = dj_forms.MultipleChoiceField(
        choices=[(str(i), day) for i, day in enumerate(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'])],
        widget=dj_forms.CheckboxSelectMultiple,
        required=False,
    )


@doctor_required
def availability(request):
    doctor = request.user.doctor_profile
    if request.method == 'POST':
        DoctorAvailability.objects.filter(doctor=doctor).delete()
        for i in range(7):
            if request.POST.get(f'available_{i}'):
                DoctorAvailability.objects.create(
                    doctor=doctor,
                    day_of_week=i,
                    start_time=request.POST.get(f'start_{i}', '09:00'),
                    end_time=request.POST.get(f'end_{i}', '17:00'),
                    max_bookings=int(request.POST.get(f'max_{i}', 10) or 10),
                    is_available=True,
                )
        messages.success(request, 'Availability updated.')
        return redirect('doctor:availability')
    avail = DoctorAvailability.objects.filter(doctor=doctor)
    avail_by_day = {a.day_of_week: a for a in avail}
    day_names = ['Monday', 'Tuesday', 'Wednesday',
                 'Thursday', 'Friday', 'Saturday', 'Sunday']
    day_slots = []
    for i, name in enumerate(day_names):
        slot = avail_by_day.get(i)
        day_slots.append({
            'day_index': i,
            'day_name': name,
            'is_available': slot.is_available if slot else False,
            'start_time': slot.start_time.strftime('%H:%M') if slot else '09:00',
            'end_time': slot.end_time.strftime('%H:%M') if slot else '17:00',
            'max_bookings': slot.max_bookings if slot else 10,
        })
    return render(request, 'doctor/availability.html', {
        'day_slots': day_slots,
    })


@doctor_required
def mothers(request):
    doctor = request.user.doctor_profile
    q = request.GET.get('q', '')
    mothers_qs = MotherProfile.objects.filter(bookings__doctor=doctor).select_related('user').distinct()
    if q:
        mothers_qs = mothers_qs.filter(
            user__first_name__icontains=q,
        ) | mothers_qs.filter(
            user__last_name__icontains=q,
        )
    return render(request, 'doctor/mothers.html', {
        'mothers': mothers_qs,
        'q': q,
    })


@doctor_required
def mother_detail(request, pk):
    doctor = request.user.doctor_profile
    mother = get_object_or_404(
        MotherProfile.objects.filter(bookings__doctor=doctor).distinct(),
        pk=pk
    )
    babies = mother.babies.all()
    past_bookings = Booking.objects.filter(mother=mother, doctor=doctor).order_by('-appointment_date')
    return render(request, 'doctor/mother_detail.html', {
        'mother': mother,
        'babies': babies,
        'past_bookings': past_bookings,
    })


@doctor_required
def food(request):
    foods = Food.objects.filter(is_active=True)
    return render(request, 'doctor/food.html', {'foods': foods})


@doctor_required
def food_add(request):
    class QuickFoodForm(dj_forms.ModelForm):
        class Meta:
            model = Food
            fields = ['name', 'description', 'nutrients', 'benefits', 'target_group']

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            for field in self.fields.values():
                field.widget.attrs['class'] = 'form-control'

    if request.method == 'POST':
        form = QuickFoodForm(request.POST)
        if form.is_valid():
            item = form.save(commit=False)
            item.added_by = request.user
            item.save()
            messages.success(request, 'Food item added.')
            return redirect('doctor:food')
    else:
        form = QuickFoodForm()
    return render(request, 'doctor/food_add.html', {'form': form})


@doctor_required
def vaccinations(request):
    doctor = request.user.doctor_profile
    vaccinations_qs = VaccinationRecord.objects.filter(
        baby__mother__bookings__doctor=doctor,
    ).select_related('baby', 'schedule', 'baby__mother__user').distinct().order_by('due_date')
    return render(request, 'doctor/vaccinations.html', {
        'vaccinations': vaccinations_qs,
    })


@doctor_required
def vaccination_give(request, pk):
    if request.method != 'POST':
        return redirect('doctor:vaccinations')
    doctor = request.user.doctor_profile
    record = get_object_or_404(VaccinationRecord, pk=pk, baby__mother__bookings__doctor=doctor)
    record.status = VaccinationRecord.Status.GIVEN
    record.given_date = timezone.now().date()
    record.given_by = request.user
    record.save(update_fields=['status', 'given_date', 'given_by'])
    messages.success(request, 'Vaccination marked as given.')
    return redirect('doctor:vaccinations')


@role_required('doctor')
def verification_status(request):
    profile = getattr(request.user, 'doctor_profile', None)
    if profile and profile.is_approved:
        return redirect('doctor:dashboard')
    return render(request, 'doctor/verification_status.html', {
        'profile': profile,
    })

