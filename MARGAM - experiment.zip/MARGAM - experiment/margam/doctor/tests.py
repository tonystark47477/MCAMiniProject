from datetime import date
from django.test import TestCase, Client
from django.urls import reverse
from django.core.files.uploadedfile import SimpleUploadedFile
from accounts.models import CustomUser
from doctor.models import DoctorProfile, DoctorAvailability
from mother.models import MotherProfile, BabyProfile, Booking, VaccinationRecord
from core.models import VaccinationScheduleTemplate, Notification


class DoctorWorkflowTests(TestCase):
    def setUp(self):
        self.client = Client()

        # Govt
        self.govt_user = CustomUser.objects.create_user(
            username='testgovt', password='password123', role=CustomUser.Role.GOVERNMENT
        )

        # Doctor 1
        self.doc1_user = CustomUser.objects.create_user(
            username='doctor1', password='password123', role=CustomUser.Role.DOCTOR, first_name='Doctor', last_name='One'
        )
        self.doc1_profile = DoctorProfile.objects.create(
            user=self.doc1_user, specialization='pediatrics', hospital='City Hospital'
        )

        # Doctor 2
        self.doc2_user = CustomUser.objects.create_user(
            username='doctor2', password='password123', role=CustomUser.Role.DOCTOR, first_name='Doctor', last_name='Two'
        )
        self.doc2_profile = DoctorProfile.objects.create(
            user=self.doc2_user, specialization='general', hospital='Town Clinic'
        )

        # Mother 1
        self.mother1_user = CustomUser.objects.create_user(
            username='mother1', password='password123', role=CustomUser.Role.MOTHER, first_name='Alice'
        )
        self.mother1_profile = MotherProfile.objects.create(user=self.mother1_user)

        # Mother 2 (no bookings with Doctor 1)
        self.mother2_user = CustomUser.objects.create_user(
            username='mother2', password='password123', role=CustomUser.Role.MOTHER, first_name='Bobbie'
        )
        self.mother2_profile = MotherProfile.objects.create(user=self.mother2_user)

        # Booking Mother 1 -> Doctor 1
        self.booking = Booking.objects.create(
            mother=self.mother1_profile,
            doctor=self.doc1_profile,
            appointment_date=date.today(),
            reason='Routine pediatric check',
            status=Booking.Status.PENDING
        )

        # Vaccination template & record
        self.template = VaccinationScheduleTemplate.objects.create(
            vaccine_name='OPV 1', age_in_weeks=0, dose_number=1
        )
        self.baby = BabyProfile.objects.create(
            mother=self.mother1_profile, name='Baby Alice', date_of_birth=date.today(), gender='F'
        )

    def test_doctor_dashboard(self):
        self.client.login(username='doctor1', password='password123')
        response = self.client.get(reverse('doctor:dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.context['pending_bookings']), 1)

    def test_doctor_availability_setting(self):
        self.client.login(username='doctor1', password='password123')
        resp = self.client.post(reverse('doctor:availability'), {
            'available_0': 'on',
            'start_0': '09:00',
            'end_0': '17:00',
            'max_0': '10',
            'available_2': 'on',
            'start_2': '10:00',
            'end_2': '16:00',
            'max_2': '5',
        })
        self.assertRedirects(resp, reverse('doctor:availability'))
        avail_count = DoctorAvailability.objects.filter(doctor=self.doc1_profile).count()
        self.assertEqual(avail_count, 2)

    def test_booking_confirm_and_reject(self):
        self.client.login(username='doctor1', password='password123')
        
        # Confirm booking
        resp_conf = self.client.get(reverse('doctor:booking_confirm', kwargs={'pk': self.booking.pk}))
        self.assertEqual(resp_conf.status_code, 405)
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.status, Booking.Status.PENDING)
        resp_conf = self.client.post(reverse('doctor:booking_confirm', kwargs={'pk': self.booking.pk}))
        self.assertEqual(resp_conf.status_code, 302)
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.status, Booking.Status.CONFIRMED)

        # Verify notification created for mother
        notif = Notification.objects.filter(recipient=self.mother1_user, notif_type=Notification.NotifType.APPOINTMENT).first()
        self.assertIsNotNone(notif)
        self.assertIn('Confirmed', notif.title)

        # Reject booking
        resp_rej_get = self.client.get(reverse('doctor:booking_reject', kwargs={'pk': self.booking.pk}))
        self.assertEqual(resp_rej_get.status_code, 405)
        resp_rej = self.client.post(reverse('doctor:booking_reject', kwargs={'pk': self.booking.pk}), {
            'rejection_reason': 'Doctor emergency leave'
        })
        self.assertRedirects(resp_rej, reverse('doctor:bookings'))
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.status, Booking.Status.REJECTED)
        self.assertEqual(self.booking.rejection_reason, 'Doctor emergency leave')

    def test_booking_complete(self):
        self.client.login(username='doctor1', password='password123')
        resp_get = self.client.get(reverse('doctor:booking_complete', kwargs={'pk': self.booking.pk}))
        self.assertEqual(resp_get.status_code, 405)
        # Booking must be confirmed before completion
        self.booking.status = Booking.Status.CONFIRMED
        self.booking.save()
        resp = self.client.post(reverse('doctor:booking_complete', kwargs={'pk': self.booking.pk}))
        self.assertRedirects(resp, reverse('doctor:booking_detail', kwargs={'pk': self.booking.pk}))
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.status, Booking.Status.COMPLETED)
        self.assertEqual(self.booking.doctor_notes, '')
        # Review is submitted after completion
        resp_rev = self.client.post(reverse('doctor:booking_review', kwargs={'pk': self.booking.pk}), {
            'doctor_notes': 'Child is healthy and growing well.'
        })
        self.assertRedirects(resp_rev, reverse('doctor:booking_detail', kwargs={'pk': self.booking.pk}))
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.doctor_notes, 'Child is healthy and growing well.')

    def test_appointment_lifecycle_review_workflow(self):
        self.client.login(username='doctor1', password='password123')

        # 1. Pending appointment cannot be reviewed
        self.assertEqual(self.booking.status, Booking.Status.PENDING)
        resp_rev_pending = self.client.post(reverse('doctor:booking_review', kwargs={'pk': self.booking.pk}), {
            'doctor_notes': 'Pending review attempt'
        })
        self.assertRedirects(resp_rev_pending, reverse('doctor:booking_detail', kwargs={'pk': self.booking.pk}))
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.doctor_notes, '')

        # Pending appointment cannot be marked completed directly
        resp_comp_pending = self.client.post(reverse('doctor:booking_complete', kwargs={'pk': self.booking.pk}))
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.status, Booking.Status.PENDING)

        # 2. Doctor accepts / confirms appointment
        resp_conf = self.client.post(reverse('doctor:booking_confirm', kwargs={'pk': self.booking.pk}))
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.status, Booking.Status.CONFIRMED)

        # Confirmed appointment cannot be reviewed before completion
        resp_rev_conf = self.client.post(reverse('doctor:booking_review', kwargs={'pk': self.booking.pk}), {
            'doctor_notes': 'Confirmed review attempt'
        })
        self.assertRedirects(resp_rev_conf, reverse('doctor:booking_detail', kwargs={'pk': self.booking.pk}))
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.doctor_notes, '')

        # 3. Accepted appointment can be marked completed (separate action)
        resp_comp = self.client.post(reverse('doctor:booking_complete', kwargs={'pk': self.booking.pk}))
        self.assertRedirects(resp_comp, reverse('doctor:booking_detail', kwargs={'pk': self.booking.pk}))
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.status, Booking.Status.COMPLETED)

        # 4. Completed appointment can remain without a review
        self.assertEqual(self.booking.doctor_notes, '')

        # 5. Completed appointment can be reviewed later
        resp_rev = self.client.post(reverse('doctor:booking_review', kwargs={'pk': self.booking.pk}), {
            'doctor_notes': 'Child is healthy and active.'
        })
        self.assertRedirects(resp_rev, reverse('doctor:booking_detail', kwargs={'pk': self.booking.pk}))
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.doctor_notes, 'Child is healthy and active.')

        # 6. Existing review can be updated on completed appointment
        resp_update = self.client.post(reverse('doctor:booking_review', kwargs={'pk': self.booking.pk}), {
            'doctor_notes': 'Child is healthy, active, and gaining weight normally.'
        })
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.doctor_notes, 'Child is healthy, active, and gaining weight normally.')

    def test_rejected_appointment_cannot_be_reviewed(self):
        self.client.login(username='doctor1', password='password123')
        self.booking.status = Booking.Status.REJECTED
        self.booking.save()
        resp = self.client.post(reverse('doctor:booking_review', kwargs={'pk': self.booking.pk}), {
            'doctor_notes': 'Rejected review attempt'
        })
        self.assertRedirects(resp, reverse('doctor:booking_detail', kwargs={'pk': self.booking.pk}))
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.doctor_notes, '')

    def test_doctor_cannot_review_or_complete_another_doctor_appointment(self):
        # Doctor 2 attempts to review Doctor 1's completed appointment
        self.booking.status = Booking.Status.COMPLETED
        self.booking.save()
        self.client.login(username='doctor2', password='password123')
        resp = self.client.post(reverse('doctor:booking_review', kwargs={'pk': self.booking.pk}), {
            'doctor_notes': 'Unauthorized review attempt'
        })
        self.assertEqual(resp.status_code, 404)
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.doctor_notes, '')

        # Doctor 2 also cannot complete Doctor 1's appointment
        self.booking.status = Booking.Status.CONFIRMED
        self.booking.save()
        resp_comp = self.client.post(reverse('doctor:booking_complete', kwargs={'pk': self.booking.pk}))
        self.assertEqual(resp_comp.status_code, 404)

    def test_doctor_patient_detail(self):
        self.client.login(username='doctor1', password='password123')
        resp = self.client.get(reverse('doctor:mother_detail', kwargs={'pk': self.mother1_profile.pk}))
        self.assertEqual(resp.status_code, 200)

    def test_doctor_give_vaccination(self):
        self.client.login(username='doctor1', password='password123')
        vax = VaccinationRecord.objects.get(baby=self.baby)
        resp = self.client.post(reverse('doctor:vaccination_give', kwargs={'pk': vax.pk}))
        self.assertRedirects(resp, reverse('doctor:vaccinations'))
        vax.refresh_from_db()
        self.assertEqual(vax.status, VaccinationRecord.Status.GIVEN)
        self.assertEqual(vax.given_by, self.doc1_user)

    def test_doctor_access_isolation(self):
        # Doctor 1 tries to access Mother 2 (who has NO booking with Doctor 1)
        self.client.login(username='doctor1', password='password123')
        resp = self.client.get(reverse('doctor:mother_detail', kwargs={'pk': self.mother2_profile.pk}))
        self.assertEqual(resp.status_code, 404)

    def test_doctor_registration_sets_pending(self):
        proof = SimpleUploadedFile('test_degree.pdf', b'%PDF-1.4 test content', content_type='application/pdf')
        resp = self.client.post(reverse('accounts:register_doctor'), {
            'username': 'newdoc',
            'first_name': 'New',
            'last_name': 'Doctor',
            'email': 'newdoc@example.com',
            'phone': '9876500000',
            'password1': 'StrongDocPass@123',
            'password2': 'StrongDocPass@123',
            'specialization': 'pediatrics',
            'qualification': 'MBBS, MD',
            'hospital': 'District Hospital',
            'experience_years': 4,
            'medical_registration_number': 'MCI-12345',
            'verification_document': proof,
        })
        self.assertRedirects(resp, reverse('accounts:login'))
        new_doc = CustomUser.objects.get(username='newdoc')
        profile = new_doc.doctor_profile
        self.assertEqual(profile.verification_status, DoctorProfile.VerificationStatus.PENDING)
        self.assertFalse(profile.is_active)
        self.assertEqual(profile.medical_registration_number, 'MCI-12345')
        self.assertTrue(bool(profile.verification_document))

    def test_doctor_file_validation_rejects_invalid_extension(self):
        bad_file = SimpleUploadedFile('malicious.exe', b'bad content', content_type='application/octet-stream')
        resp = self.client.post(reverse('accounts:register_doctor'), {
            'username': 'baddoc',
            'first_name': 'Bad',
            'last_name': 'Doctor',
            'email': 'baddoc@example.com',
            'phone': '9876500001',
            'password1': 'StrongDocPass@123',
            'password2': 'StrongDocPass@123',
            'specialization': 'general',
            'verification_document': bad_file,
        })
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, 'Only PDF, JPG, and PNG documents are accepted for verification proof.')

    def test_pending_doctor_cannot_access_dashboard_or_direct_urls(self):
        # Create a pending doctor
        pending_user = CustomUser.objects.create_user(
            username='pendingdoc', password='password123', role=CustomUser.Role.DOCTOR
        )
        DoctorProfile.objects.create(
            user=pending_user,
            verification_status=DoctorProfile.VerificationStatus.PENDING,
            is_active=False
        )

        # Login redirects to verification status page
        login_resp = self.client.post(reverse('accounts:login'), {
            'username': 'pendingdoc', 'password': 'password123'
        })
        self.assertRedirects(login_resp, reverse('doctor:verification_status'))

        # Direct access to dashboard is blocked by @doctor_required
        dash_resp = self.client.get(reverse('doctor:dashboard'))
        self.assertRedirects(dash_resp, reverse('doctor:verification_status'))

        # Direct access to bookings is blocked
        book_resp = self.client.get(reverse('doctor:bookings'))
        self.assertRedirects(book_resp, reverse('doctor:verification_status'))

        # Verification status page renders cleanly
        status_resp = self.client.get(reverse('doctor:verification_status'))
        self.assertEqual(status_resp.status_code, 200)
        self.assertContains(status_resp, 'Pending Review')

    def test_government_approval_workflow(self):
        pending_user = CustomUser.objects.create_user(
            username='approvereq', password='password123', role=CustomUser.Role.DOCTOR
        )
        profile = DoctorProfile.objects.create(
            user=pending_user,
            verification_status=DoctorProfile.VerificationStatus.PENDING,
            is_active=False
        )

        # Government logs in and views doctors list
        self.client.login(username='testgovt', password='password123')
        list_resp = self.client.get(reverse('government:doctors'))
        self.assertEqual(list_resp.status_code, 200)
        self.assertContains(list_resp, 'approvereq')

        # Government approves the doctor
        appr_resp = self.client.post(reverse('government:doctor_approve', kwargs={'pk': profile.pk}))
        self.assertRedirects(appr_resp, reverse('government:doctors'))

        profile.refresh_from_db()
        self.assertEqual(profile.verification_status, DoctorProfile.VerificationStatus.APPROVED)
        self.assertTrue(profile.is_active)

        # Notification sent
        notif = Notification.objects.filter(recipient=pending_user).first()
        self.assertIsNotNone(notif)
        self.assertIn('Approved', notif.title)

        # Doctor now has normal access
        self.client.logout()
        self.client.login(username='approvereq', password='password123')
        dash_resp = self.client.get(reverse('doctor:dashboard'))
        self.assertEqual(dash_resp.status_code, 200)

    def test_government_rejection_workflow(self):
        pending_user = CustomUser.objects.create_user(
            username='rejectreq', password='password123', role=CustomUser.Role.DOCTOR
        )
        profile = DoctorProfile.objects.create(
            user=pending_user,
            verification_status=DoctorProfile.VerificationStatus.PENDING,
            is_active=False
        )

        # Government rejects the doctor
        self.client.login(username='testgovt', password='password123')
        rej_resp = self.client.post(reverse('government:doctor_reject', kwargs={'pk': profile.pk}), {
            'rejection_reason': 'Invalid registration document'
        })
        self.assertRedirects(rej_resp, reverse('government:doctors'))

        profile.refresh_from_db()
        self.assertEqual(profile.verification_status, DoctorProfile.VerificationStatus.REJECTED)
        self.assertFalse(profile.is_active)
        self.assertEqual(profile.rejection_reason, 'Invalid registration document')

        # Rejected doctor login routes to verification status with rejection notice
        self.client.logout()
        self.client.login(username='rejectreq', password='password123')
        dash_resp = self.client.get(reverse('doctor:dashboard'))
        self.assertRedirects(dash_resp, reverse('doctor:verification_status'))
        status_resp = self.client.get(reverse('doctor:verification_status'))
        self.assertContains(status_resp, 'Registration Not Approved')
        self.assertContains(status_resp, 'Invalid registration document')

