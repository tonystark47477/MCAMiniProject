from django.db import models
from django.conf import settings
from core.models import TimeStampedModel


class DoctorProfile(TimeStampedModel):
    class Specialization(models.TextChoices):
        GENERAL    = 'general',    'General Physician'
        PEDIATRICS = 'pediatrics', 'Pediatrics'
        GYNECOLOGY = 'gynecology', 'Gynecology & Obstetrics'
        NUTRITION  = 'nutrition',  'Nutrition'
        OTHER      = 'other',      'Other'

    class VerificationStatus(models.TextChoices):
        PENDING  = 'pending',  'Pending Verification'
        APPROVED = 'approved', 'Approved'
        REJECTED = 'rejected', 'Rejected'

    user             = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='doctor_profile'
    )
    specialization   = models.CharField(max_length=20, choices=Specialization.choices, default=Specialization.GENERAL)
    qualification    = models.CharField(max_length=200, blank=True)
    hospital         = models.CharField(max_length=200, blank=True)
    experience_years = models.PositiveSmallIntegerField(default=0)
    bio              = models.TextField(blank=True)
    is_active        = models.BooleanField(default=True)
    
    # Document-based verification fields
    medical_registration_number = models.CharField(
        max_length=100, blank=True, help_text='Medical Council / Registration Number'
    )
    verification_document = models.FileField(
        upload_to='doctor_proofs/', blank=True, null=True,
        help_text='Supporting qualification/registration proof document.'
    )
    verification_status = models.CharField(
        max_length=20,
        choices=VerificationStatus.choices,
        default=VerificationStatus.APPROVED,
        db_index=True
    )
    rejection_reason = models.TextField(blank=True)

    @property
    def is_approved(self):
        return self.verification_status == self.VerificationStatus.APPROVED

    @property
    def is_pending(self):
        return self.verification_status == self.VerificationStatus.PENDING

    @property
    def is_rejected(self):
        return self.verification_status == self.VerificationStatus.REJECTED


    class Meta:
        verbose_name = 'Doctor Profile'

    def __str__(self):
        return f'Dr. {self.user.get_full_name()} ({self.get_specialization_display()})'

    def available_days(self):
        return list(
            self.availability.filter(is_available=True)
            .values_list('day_of_week', flat=True)
        )


class DoctorAvailability(TimeStampedModel):
    class Day(models.IntegerChoices):
        MONDAY    = 0, 'Monday'
        TUESDAY   = 1, 'Tuesday'
        WEDNESDAY = 2, 'Wednesday'
        THURSDAY  = 3, 'Thursday'
        FRIDAY    = 4, 'Friday'
        SATURDAY  = 5, 'Saturday'
        SUNDAY    = 6, 'Sunday'

    doctor       = models.ForeignKey(DoctorProfile, on_delete=models.CASCADE, related_name='availability')
    day_of_week  = models.IntegerField(choices=Day.choices)
    start_time   = models.TimeField()
    end_time     = models.TimeField()
    max_bookings = models.PositiveSmallIntegerField(default=10)
    is_available = models.BooleanField(default=True)

    class Meta:
        ordering        = ['day_of_week']
        unique_together = ['doctor', 'day_of_week']

    def __str__(self):
        return f'{self.doctor} — {self.get_day_of_week_display()}'