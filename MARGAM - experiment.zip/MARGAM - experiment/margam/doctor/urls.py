from django.urls import path

from . import views

app_name = 'doctor'

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('bookings/', views.bookings, name='bookings'),
    path('bookings/<int:pk>/', views.booking_detail, name='booking_detail'),
    path('bookings/<int:pk>/confirm/', views.booking_confirm, name='booking_confirm'),
    path('bookings/<int:pk>/reject/', views.booking_reject, name='booking_reject'),
    path('bookings/<int:pk>/complete/', views.booking_complete, name='booking_complete'),
    path('bookings/<int:pk>/review/', views.booking_review, name='booking_review'),
    path('availability/', views.availability, name='availability'),
    path('patients/', views.mothers, name='mothers'),
    path('patients/<int:pk>/', views.mother_detail, name='mother_detail'),
    path('food/', views.food, name='food'),
    path('food/add/', views.food_add, name='food_add'),
    path('vaccinations/', views.vaccinations, name='vaccinations'),
    path('vaccinations/<int:pk>/give/', views.vaccination_give, name='vaccination_give'),
    path('verification-status/', views.verification_status, name='verification_status'),
]