from django.contrib import admin
from .models import Project, ResourceLink

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('title', 'status', 'start_date', 'end_date', 'added_by')
    list_filter = ('status',)
    search_fields = ('title',)

@admin.register(ResourceLink)
class ResourceLinkAdmin(admin.ModelAdmin):
    list_display = ('title', 'url', 'category', 'added_by')
    search_fields = ('title', 'category')
