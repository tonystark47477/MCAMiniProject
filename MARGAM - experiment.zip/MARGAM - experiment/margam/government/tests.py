from datetime import date
import json
from django.test import TestCase, Client
from django.urls import reverse
from accounts.models import CustomUser
from core.models import Panchayat, VaccinationScheduleTemplate, HealthTip, Disease, Food, Notification
from asha.models import AshaWorkerProfile
from doctor.models import DoctorProfile
from mother.models import MotherProfile
from government.models import Project, ResourceLink


class GovernmentWorkflowTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.panchayat = Panchayat.objects.create(name='Govt Panchayat', district='District G')

        # Govt Official User
        self.govt_user = CustomUser.objects.create_user(
            username='govt_admin', password='password123', role=CustomUser.Role.GOVERNMENT
        )

        # Asha Worker
        self.asha_user = CustomUser.objects.create_user(
            username='asha_g', password='password123', role=CustomUser.Role.ASHA_WORKER
        )
        self.asha_profile = AshaWorkerProfile.objects.create(
            user=self.asha_user, panchayat=self.panchayat, worker_id='ASH999'
        )

        # Doctor
        self.doc_user = CustomUser.objects.create_user(
            username='doctor_g', password='password123', role=CustomUser.Role.DOCTOR
        )
        self.doc_profile = DoctorProfile.objects.create(user=self.doc_user)

        # Unassigned Mother
        self.mother_user = CustomUser.objects.create_user(
            username='mother_unassigned', password='password123', role=CustomUser.Role.MOTHER
        )
        self.mother_profile = MotherProfile.objects.create(user=self.mother_user)

    def test_government_dashboard_and_charts(self):
        self.client.login(username='govt_admin', password='password123')
        response = self.client.get(reverse('government:dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertIn('panchayat_labels_json', response.context)
        # Verify JSON valid
        labels = json.loads(response.context['panchayat_labels_json'])
        self.assertIn('Govt Panchayat', labels)

    def test_doctor_add_and_toggle(self):
        self.client.login(username='govt_admin', password='password123')
        # Add Doctor
        resp_add = self.client.post(reverse('government:doctor_add'), {
            'username': 'new_doc',
            'first_name': 'Dr New',
            'last_name': 'Doc',
            'phone': '9876543299',
            'password1': 'pass123456',
            'password2': 'pass123456',
            'specialization': 'general',
            'qualification': 'MBBS',
            'hospital': 'Govt Hospital',
            'experience_years': 5
        })
        self.assertEqual(resp_add.status_code, 302)
        new_doc_profile = DoctorProfile.objects.get(user__username='new_doc')
        self.assertTrue(new_doc_profile.is_active)

        # Toggle Active
        resp_toggle = self.client.post(reverse('government:doctor_toggle', kwargs={'pk': new_doc_profile.pk}))
        self.assertEqual(resp_toggle.status_code, 302)
        new_doc_profile.refresh_from_db()
        self.assertFalse(new_doc_profile.is_active)

    def test_asha_add_and_toggle(self):
        self.client.login(username='govt_admin', password='password123')
        resp_add = self.client.post(reverse('government:asha_add'), {
            'username': 'new_asha',
            'first_name': 'Asha',
            'last_name': 'Worker',
            'phone': '9876543288',
            'password1': 'pass123456',
            'password2': 'pass123456',
            'panchayat': self.panchayat.pk,
            'worker_id': 'ASH100'
        })
        self.assertEqual(resp_add.status_code, 302)
        new_asha_profile = AshaWorkerProfile.objects.get(user__username='new_asha')
        self.assertTrue(new_asha_profile.is_active)

        resp_toggle = self.client.post(reverse('government:asha_toggle', kwargs={'pk': new_asha_profile.pk}))
        self.assertEqual(resp_toggle.status_code, 302)
        new_asha_profile.refresh_from_db()
        self.assertFalse(new_asha_profile.is_active)

    def test_assign_asha_to_mother(self):
        self.client.login(username='govt_admin', password='password123')
        resp = self.client.post(
            reverse('government:assign_asha', kwargs={'mother_pk': self.mother_profile.pk}),
            {'asha_worker': self.asha_profile.pk}
        )
        self.assertEqual(resp.status_code, 302)
        self.mother_profile.refresh_from_db()
        self.assertEqual(self.mother_profile.asha_worker, self.asha_profile)

    def test_vaccination_schedule_template_crud(self):
        self.client.login(username='govt_admin', password='password123')
        # Create
        resp_add = self.client.post(reverse('government:vaccination_add'), {
            'vaccine_name': 'Pentavalent 1',
            'age_in_weeks': 6,
            'dose_number': 1,
            'description': 'DPT-HepB-Hib',
            'is_mandatory': True
        })
        self.assertEqual(resp_add.status_code, 302)
        tmpl = VaccinationScheduleTemplate.objects.get(vaccine_name='Pentavalent 1')
        self.assertEqual(tmpl.age_in_weeks, 6)

        # Edit
        resp_edit = self.client.post(reverse('government:vaccination_edit', kwargs={'pk': tmpl.pk}), {
            'vaccine_name': 'Pentavalent 1 Updated',
            'age_in_weeks': 6,
            'dose_number': 1,
            'description': 'Updated DPT-HepB-Hib',
            'is_mandatory': True
        })
        self.assertEqual(resp_edit.status_code, 302)
        tmpl.refresh_from_db()
        self.assertEqual(tmpl.vaccine_name, 'Pentavalent 1 Updated')

    def test_government_broadcast_notification(self):
        self.client.login(username='govt_admin', password='password123')
        resp = self.client.post(reverse('government:send_notification'), {
            'recipient_group': 'all_asha',
            'title': 'Government Advisory',
            'message': 'Important update for all ASHA workers.',
            'notif_type': Notification.NotifType.GOVERNMENT
        })
        self.assertEqual(resp.status_code, 302)
        # Verify notification created for ASHA worker
        notif = Notification.objects.filter(recipient=self.asha_user, title='Government Advisory').first()
        self.assertIsNotNone(notif)

    def test_government_reports_view(self):
        self.client.login(username='govt_admin', password='password123')
        resp = self.client.get(reverse('government:reports'))
        self.assertEqual(resp.status_code, 200)
