from django import forms
from django.contrib.auth.forms import UserCreationForm
from accounts.models import CustomUser
from core.models import (Panchayat, VaccinationScheduleTemplate,
    Disease, HealthTip, Food, Notification)
from asha.models import AshaWorkerProfile
from doctor.models import DoctorProfile
from government.models import Project, ResourceLink


class BootstrapMixin:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            widget = field.widget
            if isinstance(widget, forms.CheckboxInput):
                widget.attrs['class'] = 'form-check-input'
            elif isinstance(widget, (forms.Select, forms.SelectMultiple)):
                widget.attrs['class'] = 'form-select'
            else:
                widget.attrs['class'] = 'form-control'
            if not isinstance(widget, (forms.CheckboxInput,)):
                widget.attrs.setdefault('placeholder', field.label or name.replace('_', ' ').title())


class AddDoctorForm(BootstrapMixin, UserCreationForm):
    SPECIALIZATION_CHOICES = [
        ('general',    'General Physician'),
        ('pediatrics', 'Pediatrics'),
        ('gynecology', 'Gynecology & Obstetrics'),
        ('nutrition',  'Nutrition'),
        ('other',      'Other'),
    ]
    specialization   = forms.ChoiceField(choices=SPECIALIZATION_CHOICES)
    qualification    = forms.CharField(max_length=200, required=False)
    hospital         = forms.CharField(max_length=200, required=False)
    experience_years = forms.IntegerField(min_value=0, initial=0)
    bio              = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3}), required=False)

    class Meta:
        model = CustomUser
        fields = ('first_name', 'last_name', 'username', 'email', 'phone',
                  'password1', 'password2',
                  'specialization', 'qualification', 'hospital',
                  'experience_years', 'bio')

    def save(self, commit=True):
        from doctor.models import DoctorProfile
        user = super().save(commit=False)
        user.role = CustomUser.Role.DOCTOR
        if commit:
            user.save()
            DoctorProfile.objects.create(
                user=user,
                specialization=self.cleaned_data['specialization'],
                qualification=self.cleaned_data.get('qualification', ''),
                hospital=self.cleaned_data.get('hospital', ''),
                experience_years=self.cleaned_data.get('experience_years', 0),
                bio=self.cleaned_data.get('bio', '')
            )
        return user


class AddAshaWorkerForm(BootstrapMixin, UserCreationForm):
    panchayat = forms.ModelChoiceField(
        queryset=Panchayat.objects.all(),
        empty_label='Select Panchayat'
    )
    worker_id = forms.CharField(max_length=50, required=False, label='Worker ID')
    address   = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3}), required=False)

    class Meta:
        model = CustomUser
        fields = ('first_name', 'last_name', 'username', 'email', 'phone',
                  'password1', 'password2', 'panchayat', 'worker_id', 'address')

    def save(self, commit=True):
        from asha.models import AshaWorkerProfile
        user = super().save(commit=False)
        user.role = CustomUser.Role.ASHA_WORKER
        if commit:
            user.save()
            AshaWorkerProfile.objects.create(
                user=user,
                panchayat=self.cleaned_data['panchayat'],
                worker_id=self.cleaned_data.get('worker_id', ''),
                address=self.cleaned_data.get('address', '')
            )
        return user


class VaccinationScheduleForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = VaccinationScheduleTemplate
        fields = ('vaccine_name', 'age_in_weeks', 'dose_number',
                  'description', 'is_mandatory')


class ProjectForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = Project
        fields = ('title', 'description', 'start_date', 'end_date', 'status')
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date'}),
            'end_date': forms.DateInput(attrs={'type': 'date'}),
        }


class DiseaseForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = Disease
        fields = ('name', 'description', 'symptoms', 'prevention')


class FoodForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = Food
        fields = ('name', 'description', 'nutrients', 'benefits', 'target_group')


class ResourceLinkForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = ResourceLink
        fields = ('title', 'url', 'category')


class HealthTipForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = HealthTip
        fields = ('title', 'content', 'category')


class SendNotificationForm(BootstrapMixin, forms.Form):
    title = forms.CharField(max_length=200)
    message = forms.CharField(widget=forms.Textarea(attrs={'rows': 4}))
    notif_type = forms.ChoiceField(choices=Notification.NotifType.choices)
    recipient_group = forms.ChoiceField(choices=[
        ('all_asha',    'All Asha Workers'),
        ('all_doctors', 'All Doctors'),
        ('all_mothers', 'All Mothers'),
        ('all',         'Everyone'),
    ])
