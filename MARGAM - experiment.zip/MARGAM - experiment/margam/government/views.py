from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.utils import timezone
from django.db.models import Count
from core.decorators import government_required
from core.models import (Panchayat, Disease, HealthTip, Food,
    VaccinationScheduleTemplate, Notification)
from accounts.models import CustomUser
from asha.models import AshaWorkerProfile
from doctor.models import DoctorProfile
from mother.models import (MotherProfile, BabyProfile,
    VaccinationRecord, Booking, AssistanceRequest)
from government.models import Project, ResourceLink
from .forms import (AddDoctorForm, AddAshaWorkerForm,
    VaccinationScheduleForm, ProjectForm, DiseaseForm,
    FoodForm, ResourceLinkForm, HealthTipForm,
    SendNotificationForm)
import json


# ─────────────────────────────────────────
# Dashboard
# ─────────────────────────────────────────

@government_required
def dashboard(request):
    from datetime import timedelta
    today = timezone.now().date()

    total_mothers           = MotherProfile.objects.filter(is_active=True).count()
    total_babies            = BabyProfile.objects.count()
    vaccinations_this_month = VaccinationRecord.objects.filter(
        status='given',
        given_date__month=today.month,
        given_date__year=today.year
    ).count()
    pending_bookings = Booking.objects.filter(status='pending').count()
    active_asha      = AshaWorkerProfile.objects.filter(is_active=True).count()
    active_doctors   = DoctorProfile.objects.filter(is_active=True).count()
    recent_bookings  = Booking.objects.select_related(
        'mother__user', 'doctor__user'
    ).order_by('-created_at')[:5]

    # Chart 1 – panchayat vaccinations
    panchayats       = Panchayat.objects.all()
    panchayat_labels = [p.name for p in panchayats]
    panchayat_data   = []
    for p in panchayats:
        count = VaccinationRecord.objects.filter(
            status='given',
            baby__mother__asha_worker__panchayat=p
        ).count()
        panchayat_data.append(count)

    # Chart 2 – bookings last 30 days (by appointment_date)
    last_30       = [today - timedelta(days=i) for i in range(29, -1, -1)]
    booking_labels = [d.strftime('%d %b') for d in last_30]
    booking_data   = []
    for d in last_30:
        count = Booking.objects.filter(appointment_date=d).count()
        booking_data.append(count)

    has_vaccination_data = bool(panchayat_labels)
    has_booking_data     = any(count > 0 for count in booking_data)

    # Panel 1: Consultation Activity Statistics
    all_bookings = Booking.objects.all()
    total_consultations = all_bookings.count()
    confirmed_consultations = all_bookings.filter(status='confirmed').count()
    pending_consultations = all_bookings.filter(status='pending').count()
    declined_consultations = all_bookings.filter(status__in=['rejected', 'cancelled']).count()

    confirmed_pct = round((confirmed_consultations / total_consultations) * 100) if total_consultations else 0
    pending_pct   = round((pending_consultations / total_consultations) * 100) if total_consultations else 0
    declined_pct  = round((declined_consultations / total_consultations) * 100) if total_consultations else 0

    consultation_stats = {
        'total':         total_consultations,
        'confirmed':     confirmed_consultations,
        'pending':       pending_consultations,
        'declined':      declined_consultations,
        'confirmed_pct': confirmed_pct,
        'pending_pct':   pending_pct,
        'declined_pct':  declined_pct,
    }

    # Panel 2: ASHA Outreach Activity
    worker_activity = list(AshaWorkerProfile.objects.filter(is_active=True).select_related(
        'user', 'panchayat'
    ).annotate(mothers_count=Count('mothers')).order_by('-mothers_count', 'user__first_name'))

    max_mothers = max([w.mothers_count for w in worker_activity], default=1) or 1
    for w in worker_activity:
        w.outreach_pct = round((w.mothers_count / max_mothers) * 100) if max_mothers and w.mothers_count > 0 else 0

    return render(request, 'government/dashboard.html', {
        'total_mothers':           total_mothers,
        'total_babies':            total_babies,
        'vaccinations_this_month': vaccinations_this_month,
        'pending_bookings':        pending_bookings,
        'active_asha_workers':     active_asha,
        'active_doctors':          active_doctors,
        'recent_bookings':         recent_bookings,
        'panchayat_labels_json':          json.dumps(panchayat_labels),
        'panchayat_vaccination_data_json': json.dumps(panchayat_data),
        'last_30_days_labels_json':        json.dumps(booking_labels),
        'last_30_days_booking_data_json':  json.dumps(booking_data),
        'has_vaccination_data':            has_vaccination_data,
        'has_booking_data':                has_booking_data,
        'consultation_stats':              consultation_stats,
        'worker_activity':                 worker_activity,
    })


@government_required
def trigger_alerts(request):
    if request.method != 'POST':
        return redirect('government:dashboard')
    from django.core.management import call_command

    call_command('send_vaccination_alerts')
    messages.success(request, 'Vaccination alerts sent successfully.')
    return redirect('government:dashboard')


# ─────────────────────────────────────────
# Doctors
# ─────────────────────────────────────────

@government_required
def doctors(request):
    from django.db.models import Q
    qs = DoctorProfile.objects.select_related('user').order_by('-created_at')
    q = request.GET.get('q', '').strip()
    status_filter = request.GET.get('status', '').strip()
    if q:
        qs = qs.filter(
            Q(user__first_name__icontains=q) |
            Q(user__last_name__icontains=q) |
            Q(user__username__icontains=q) |
            Q(medical_registration_number__icontains=q)
        )
    if status_filter in ['pending', 'approved', 'rejected']:
        qs = qs.filter(verification_status=status_filter)
    pending_count = DoctorProfile.objects.filter(verification_status='pending').count()
    return render(request, 'government/doctors.html', {
        'doctors': qs,
        'q': q,
        'status_filter': status_filter,
        'pending_count': pending_count,
    })


@government_required
def doctor_add(request):
    if request.method == 'POST':
        form = AddDoctorForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request,
                f"Doctor {user.get_full_name() or user.username} registered successfully.")
            return redirect('government:doctors')
    else:
        form = AddDoctorForm()
    return render(request, 'government/doctor_add.html', {'form': form})


@government_required
def doctor_toggle(request, pk):
    if request.method != 'POST':
        return redirect('government:doctors')
    profile = get_object_or_404(DoctorProfile, pk=pk)
    profile.is_active = not profile.is_active
    profile.save()
    status = "activated" if profile.is_active else "deactivated"
    messages.success(request,
        f"Dr. {profile.user.get_full_name() or profile.user.username} {status}.")
    return redirect('government:doctors')


@government_required
def doctor_approve(request, pk):
    if request.method != 'POST':
        return redirect('government:doctors')
    profile = get_object_or_404(DoctorProfile, pk=pk)
    profile.verification_status = DoctorProfile.VerificationStatus.APPROVED
    profile.is_active = True
    profile.save(update_fields=['verification_status', 'is_active'])
    Notification.objects.create(
        sender=request.user,
        recipient=profile.user,
        title='Doctor Profile Approved',
        message='Your doctor credentials have been verified and approved by the Government health authority. You now have full access to the Doctor portal.',
        notif_type=Notification.NotifType.GOVERNMENT,
    )
    messages.success(request,
        f"Dr. {profile.user.get_full_name() or profile.user.username} has been verified and approved.")
    return redirect('government:doctors')


@government_required
def doctor_reject(request, pk):
    if request.method != 'POST':
        return redirect('government:doctors')
    profile = get_object_or_404(DoctorProfile, pk=pk)
    reason = request.POST.get('rejection_reason', '').strip()
    profile.verification_status = DoctorProfile.VerificationStatus.REJECTED
    profile.is_active = False
    if reason:
        profile.rejection_reason = reason
        profile.save(update_fields=['verification_status', 'is_active', 'rejection_reason'])
    else:
        profile.save(update_fields=['verification_status', 'is_active'])
    Notification.objects.create(
        sender=request.user,
        recipient=profile.user,
        title='Doctor Profile Verification Update',
        message=f'Your doctor registration could not be verified by the Government health authority. {reason}',
        notif_type=Notification.NotifType.GOVERNMENT,
    )
    messages.warning(request,
        f"Dr. {profile.user.get_full_name() or profile.user.username}'s registration was rejected.")
    return redirect('government:doctors')


# ─────────────────────────────────────────
# Asha Workers
# ─────────────────────────────────────────

@government_required
def asha_workers(request):
    qs = AshaWorkerProfile.objects.select_related('user', 'panchayat').order_by('-created_at')
    p_id = request.GET.get('panchayat', '')
    status_filter = request.GET.get('status', '').strip()
    if p_id:
        qs = qs.filter(panchayat_id=p_id)
    if status_filter in ['pending', 'approved', 'rejected']:
        qs = qs.filter(verification_status=status_filter)
    pending_count = AshaWorkerProfile.objects.filter(verification_status='pending').count()
    panchayats = Panchayat.objects.all()
    return render(request, 'government/asha_workers.html', {
        'asha_workers':       qs,
        'panchayats':         panchayats,
        'selected_panchayat': p_id,
        'status_filter':      status_filter,
        'pending_count':      pending_count,
    })


@government_required
def asha_add(request):
    if request.method == 'POST':
        form = AddAshaWorkerForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request,
                f"Asha Worker {user.get_full_name() or user.username} registered successfully.")
            return redirect('government:asha_workers')
    else:
        form = AddAshaWorkerForm()
    return render(request, 'government/asha_add.html', {'form': form})


@government_required
def asha_toggle(request, pk):
    if request.method != 'POST':
        return redirect('government:asha_workers')
    profile = get_object_or_404(AshaWorkerProfile, pk=pk)
    profile.is_active = not profile.is_active
    profile.save()
    status = "activated" if profile.is_active else "deactivated"
    messages.success(request,
        f"{profile.user.get_full_name() or profile.user.username} {status}.")
    return redirect('government:asha_workers')


@government_required
def asha_approve(request, pk):
    if request.method != 'POST':
        return redirect('government:asha_workers')
    profile = get_object_or_404(AshaWorkerProfile, pk=pk)
    profile.verification_status = AshaWorkerProfile.VerificationStatus.APPROVED
    profile.is_active = True
    profile.save(update_fields=['verification_status', 'is_active'])
    Notification.objects.create(
        sender=request.user,
        recipient=profile.user,
        title='ASHA Worker Profile Approved',
        message='Your ASHA worker credentials have been verified and approved by the Government health authority. You now have full access to the ASHA portal.',
        notif_type=Notification.NotifType.GOVERNMENT,
    )
    messages.success(request,
        f"ASHA Worker {profile.user.get_full_name() or profile.user.username} has been verified and approved.")
    return redirect('government:asha_workers')


@government_required
def asha_reject(request, pk):
    if request.method != 'POST':
        return redirect('government:asha_workers')
    profile = get_object_or_404(AshaWorkerProfile, pk=pk)
    reason = request.POST.get('rejection_reason', '').strip()
    profile.verification_status = AshaWorkerProfile.VerificationStatus.REJECTED
    profile.is_active = False
    if reason:
        profile.rejection_reason = reason
        profile.save(update_fields=['verification_status', 'is_active', 'rejection_reason'])
    else:
        profile.save(update_fields=['verification_status', 'is_active'])
    Notification.objects.create(
        sender=request.user,
        recipient=profile.user,
        title='ASHA Worker Profile Verification Update',
        message=f'Your ASHA worker registration could not be verified by the Government health authority. {reason}',
        notif_type=Notification.NotifType.GOVERNMENT,
    )
    messages.warning(request,
        f"ASHA Worker {profile.user.get_full_name() or profile.user.username}'s registration was rejected.")
    return redirect('government:asha_workers')


# ─────────────────────────────────────────
# Vaccinations
# ─────────────────────────────────────────

@government_required
def vaccinations(request):
    schedule = VaccinationScheduleTemplate.objects.all().order_by('age_in_weeks', 'dose_number')
    return render(request, 'government/vaccinations.html', {'schedule': schedule})


@government_required
def vaccination_add(request):
    if request.method == 'POST':
        form = VaccinationScheduleForm(request.POST)
        if form.is_valid():
            s = form.save(commit=False)
            s.added_by = request.user
            s.save()
            messages.success(request, f"Dose '{s.vaccine_name}' added to schedule.")
            return redirect('government:vaccinations')
    else:
        form = VaccinationScheduleForm()
    return render(request, 'government/vaccination_add.html', {'form': form})


@government_required
def vaccination_edit(request, pk):
    s = get_object_or_404(VaccinationScheduleTemplate, pk=pk)
    if request.method == 'POST':
        form = VaccinationScheduleForm(request.POST, instance=s)
        if form.is_valid():
            form.save()
            messages.success(request, "Vaccination schedule updated.")
            return redirect('government:vaccinations')
    else:
        form = VaccinationScheduleForm(instance=s)
    return render(request, 'government/vaccination_add.html', {'form': form, 'edit': True})


# ─────────────────────────────────────────
# Projects
# ─────────────────────────────────────────

@government_required
def projects(request):
    qs = Project.objects.select_related('added_by').order_by('-start_date')
    status_filter = request.GET.get('status', '')
    if status_filter:
        qs = qs.filter(status=status_filter)
    return render(request, 'government/projects.html', {
        'projects':       qs,
        'selected_status': status_filter,
    })


@government_required
def project_add(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            proj = form.save(commit=False)
            proj.added_by = request.user
            proj.save()
            messages.success(request, f"Project '{proj.title}' created.")
            return redirect('government:projects')
    else:
        form = ProjectForm()
    return render(request, 'government/project_add.html', {'form': form})


@government_required
def project_edit(request, pk):
    proj = get_object_or_404(Project, pk=pk)
    if request.method == 'POST':
        form = ProjectForm(request.POST, instance=proj)
        if form.is_valid():
            form.save()
            messages.success(request, f"Project '{proj.title}' updated.")
            return redirect('government:projects')
    else:
        form = ProjectForm(instance=proj)
    return render(request, 'government/project_add.html', {'form': form, 'edit': True})


# ─────────────────────────────────────────
# Diseases
# ─────────────────────────────────────────

@government_required
def diseases(request):
    qs = Disease.objects.filter(is_active=True).select_related('added_by')
    return render(request, 'government/diseases.html', {'diseases': qs})


@government_required
def disease_add(request):
    if request.method == 'POST':
        form = DiseaseForm(request.POST)
        if form.is_valid():
            d = form.save(commit=False)
            d.added_by = request.user
            d.save()
            messages.success(request, f"Disease advisory '{d.name}' published.")
            return redirect('government:diseases')
    else:
        form = DiseaseForm()
    return render(request, 'government/disease_add.html', {'form': form})


@government_required
def disease_edit(request, pk):
    d = get_object_or_404(Disease, pk=pk)
    if request.method == 'POST':
        form = DiseaseForm(request.POST, instance=d)
        if form.is_valid():
            form.save()
            messages.success(request, f"Disease '{d.name}' updated.")
            return redirect('government:diseases')
    else:
        form = DiseaseForm(instance=d)
    return render(request, 'government/disease_add.html', {'form': form, 'edit': True})


# ─────────────────────────────────────────
# Food / Nutrition
# ─────────────────────────────────────────

@government_required
def food(request):
    foods = Food.objects.filter(is_active=True).select_related('added_by')
    target_groups = Food.TargetGroup.choices
    foods_grouped = {}
    for tg_val, tg_label in target_groups:
        foods_grouped[tg_label] = [f for f in foods if f.target_group == tg_val]
    return render(request, 'government/food.html', {'foods_grouped': foods_grouped})


@government_required
def food_add(request):
    if request.method == 'POST':
        form = FoodForm(request.POST)
        if form.is_valid():
            f = form.save(commit=False)
            f.added_by = request.user
            f.save()
            messages.success(request, f"Food item '{f.name}' added.")
            return redirect('government:food')
    else:
        form = FoodForm()
    return render(request, 'government/food_add.html', {'form': form})


@government_required
def food_edit(request, pk):
    f = get_object_or_404(Food, pk=pk)
    if request.method == 'POST':
        form = FoodForm(request.POST, instance=f)
        if form.is_valid():
            form.save()
            messages.success(request, f"Food item '{f.name}' updated.")
            return redirect('government:food')
    else:
        form = FoodForm(instance=f)
    return render(request, 'government/food_add.html', {'form': form, 'edit': True})


# ─────────────────────────────────────────
# Resource Links
# ─────────────────────────────────────────

@government_required
def links(request):
    qs = ResourceLink.objects.select_related('added_by')
    return render(request, 'government/links.html', {'links': qs})


@government_required
def link_add(request):
    if request.method == 'POST':
        form = ResourceLinkForm(request.POST)
        if form.is_valid():
            lnk = form.save(commit=False)
            lnk.added_by = request.user
            lnk.save()
            messages.success(request, f"Link '{lnk.title}' added.")
            return redirect('government:links')
    else:
        form = ResourceLinkForm()
    return render(request, 'government/link_add.html', {'form': form})


# ─────────────────────────────────────────
# Health Tips
# ─────────────────────────────────────────

@government_required
def health_tips(request):
    tips = HealthTip.objects.filter(is_active=True).select_related('added_by')
    return render(request, 'government/health_tips.html', {'tips': tips})


@government_required
def tip_add(request):
    if request.method == 'POST':
        form = HealthTipForm(request.POST)
        if form.is_valid():
            tip = form.save(commit=False)
            tip.added_by = request.user
            tip.save()
            messages.success(request, f"Health tip '{tip.title}' published.")
            return redirect('government:health_tips')
    else:
        form = HealthTipForm()
    return render(request, 'government/tip_add.html', {'form': form})


@government_required
def tip_edit(request, pk):
    tip = get_object_or_404(HealthTip, pk=pk)
    if request.method == 'POST':
        form = HealthTipForm(request.POST, instance=tip)
        if form.is_valid():
            form.save()
            messages.success(request, f"Health tip '{tip.title}' updated.")
            return redirect('government:health_tips')
    else:
        form = HealthTipForm(instance=tip)
    return render(request, 'government/tip_add.html', {'form': form, 'edit': True})


# ─────────────────────────────────────────
# Send Notification
# ─────────────────────────────────────────

@government_required
def send_notification(request):
    if request.method == 'POST':
        form = SendNotificationForm(request.POST)
        if form.is_valid():
            group = form.cleaned_data['recipient_group']
            if group == 'all_asha':
                recipients = CustomUser.objects.filter(role=CustomUser.Role.ASHA_WORKER)
            elif group == 'all_doctors':
                recipients = CustomUser.objects.filter(role=CustomUser.Role.DOCTOR)
            elif group == 'all_mothers':
                recipients = CustomUser.objects.filter(role=CustomUser.Role.MOTHER)
            else:
                recipients = CustomUser.objects.exclude(role=CustomUser.Role.GOVERNMENT)

            notifs = [
                Notification(
                    sender=request.user,
                    recipient=u,
                    title=form.cleaned_data['title'],
                    message=form.cleaned_data['message'],
                    notif_type=form.cleaned_data['notif_type'],
                )
                for u in recipients
            ]
            Notification.objects.bulk_create(notifs)
            messages.success(request,
                f"Notification sent to {len(notifs)} recipients.")
            return redirect('government:dashboard')
    else:
        form = SendNotificationForm()
    return render(request, 'government/send_notification.html', {'form': form})


# ─────────────────────────────────────────
# Reports
# ─────────────────────────────────────────

@government_required
def reports(request):
    today = timezone.now().date()

    panchayats = Panchayat.objects.all()
    panchayat_labels = [p.name for p in panchayats]
    panchayat_data   = []
    vaccination_by_panchayat = []
    for p in panchayats:
        given   = VaccinationRecord.objects.filter(
            status='given', baby__mother__asha_worker__panchayat=p).count()
        pending = VaccinationRecord.objects.filter(
            status='pending', baby__mother__asha_worker__panchayat=p).count()
        total   = given + pending
        coverage = round(given / total * 100, 1) if total else 0
        vaccination_by_panchayat.append({
            'panchayat': p,
            'given': given,
            'pending': pending,
            'coverage': coverage,
        })
        panchayat_data.append(given)

    all_bookings = Booking.objects.all()
    booking_stats = {
        'total':     all_bookings.count(),
        'confirmed': all_bookings.filter(status='confirmed').count(),
        'rejected':  all_bookings.filter(status='rejected').count(),
        'pending':   all_bookings.filter(status='pending').count(),
    }

    worker_activity = AshaWorkerProfile.objects.select_related(
        'user', 'panchayat'
    ).annotate(mothers_count=Count('mothers')).order_by('-mothers_count')

    disease_list = Disease.objects.filter(is_active=True)

    from datetime import timedelta
    last_30        = [today - timedelta(days=i) for i in range(29, -1, -1)]
    booking_labels = [d.strftime('%d %b') for d in last_30]
    booking_data   = [Booking.objects.filter(appointment_date=d).count() for d in last_30]

    return render(request, 'government/reports.html', {
        'vaccination_by_panchayat':       vaccination_by_panchayat,
        'booking_stats':                  booking_stats,
        'worker_activity':                worker_activity,
        'disease_list':                   disease_list,
        'panchayat_labels_json':          json.dumps(panchayat_labels),
        'panchayat_vaccination_data_json': json.dumps(panchayat_data),
        'last_30_days_labels_json':        json.dumps(booking_labels),
        'last_30_days_booking_data_json':  json.dumps(booking_data),
    })


@government_required
def mothers(request):
    mothers_qs = MotherProfile.objects.select_related(
        'user', 'asha_worker__user', 'asha_worker__panchayat'
    ).order_by('-created_at')
    unassigned = mothers_qs.filter(asha_worker__isnull=True)
    assigned = mothers_qs.filter(asha_worker__isnull=False)

    assistance_qs = AssistanceRequest.objects.select_related(
        'mother__user', 'mother__asha_worker__user', 'mother__asha_worker__panchayat'
    ).order_by('-created_at')
    pending_requests = assistance_qs.filter(status=AssistanceRequest.Status.PENDING)
    resolved_requests = assistance_qs.filter(status=AssistanceRequest.Status.RESOLVED)[:10]

    return render(request, 'government/mothers.html', {
        'unassigned': unassigned,
        'assigned': assigned,
        'pending_requests': pending_requests,
        'resolved_requests': resolved_requests,
        'pending_count': pending_requests.count(),
    })


@government_required
def assign_asha(request, mother_pk):
    mother = get_object_or_404(MotherProfile, pk=mother_pk)
    asha_workers = AshaWorkerProfile.objects.filter(
        verification_status=AshaWorkerProfile.VerificationStatus.APPROVED,
        is_active=True
    ).select_related('user', 'panchayat')
    if request.method == 'POST':
        asha_pk = request.POST.get('asha_worker')
        if asha_pk:
            asha = get_object_or_404(
                AshaWorkerProfile,
                pk=asha_pk,
                verification_status=AshaWorkerProfile.VerificationStatus.APPROVED,
                is_active=True
            )
            mother.asha_worker = asha
            mother.save(update_fields=['asha_worker'])

            # Automatically resolve any pending assistance requests for this mother
            pending_reqs = AssistanceRequest.objects.filter(
                mother=mother, status=AssistanceRequest.Status.PENDING
            )
            for pr in pending_reqs:
                pr.status = AssistanceRequest.Status.RESOLVED
                pr.resolution_notes = f'ASHA Worker {asha.user.get_full_name()} ({asha.panchayat.name}) assigned by health administration.'
                pr.save(update_fields=['status', 'resolution_notes'])

            Notification.objects.create(
                sender=request.user,
                recipient=mother.user,
                title='ASHA Worker Assigned',
                message=f'ASHA Worker {asha.user.get_full_name()} ({asha.panchayat.name} Panchayat) has been assigned to support your care.',
                notif_type=Notification.NotifType.GOVERNMENT,
            )

            messages.success(request,
                f'Asha Worker {asha.user.get_full_name()} assigned to '
                f'{mother.user.get_full_name()} successfully.')
        return redirect('government:mothers')
    return render(request, 'government/assign_asha.html', {
        'mother': mother,
        'asha_workers': asha_workers,
    })


@government_required
def assistance_resolve(request, pk):
    if request.method != 'POST':
        return redirect('government:mothers')
    req = get_object_or_404(AssistanceRequest, pk=pk)
    notes = request.POST.get('resolution_notes', '').strip()
    req.status = AssistanceRequest.Status.RESOLVED
    req.resolution_notes = notes
    req.save(update_fields=['status', 'resolution_notes'])

    Notification.objects.create(
        sender=request.user,
        recipient=req.mother.user,
        title='Assistance Request Resolved',
        message=f'Your assistance request has been resolved by the Government health authority. {notes}'.strip(),
        notif_type=Notification.NotifType.GOVERNMENT,
    )
    messages.success(request,
        f"Assistance request for {req.mother.user.get_full_name() or req.mother.user.username} marked as resolved.")
    return redirect('government:mothers')
