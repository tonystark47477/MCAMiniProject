from django.db import models
from django.conf import settings
from core.models import TimeStampedModel


class Project(TimeStampedModel):
    class Status(models.TextChoices):
        PLANNED   = 'planned',   'Planned'
        ONGOING   = 'ongoing',   'Ongoing'
        COMPLETED = 'completed', 'Completed'
        PAUSED    = 'paused',    'Paused'

    title       = models.CharField(max_length=200)
    description = models.TextField()
    start_date  = models.DateField()
    end_date    = models.DateField(null=True, blank=True)
    status      = models.CharField(max_length=20, choices=Status.choices, default=Status.PLANNED, db_index=True)
    added_by    = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, related_name='projects_added'
    )

    class Meta:
        ordering = ['-start_date']

    def __str__(self):
        return f'{self.title} ({self.get_status_display()})'


class ResourceLink(TimeStampedModel):
    title    = models.CharField(max_length=200)
    url      = models.URLField()
    category = models.CharField(max_length=100, blank=True)
    added_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, related_name='links_added'
    )

    class Meta:
        ordering = ['category', 'title']

    def __str__(self):
        return self.title