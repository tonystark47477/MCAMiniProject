from datetime import date, timedelta
from django.test import TestCase, Client
from django.urls import reverse
from django.utils import timezone
from accounts.models import CustomUser
from mother.models import (MotherProfile, BabyProfile, BabyGrowthRecord,
                           Booking, VaccinationRecord, AssistanceRequest)
from asha.models import AshaWorkerProfile
from doctor.models import DoctorProfile, DoctorAvailability
from core.models import Panchayat, VaccinationScheduleTemplate, Message, Notification


class MotherWorkflowTests(TestCase):
    def setUp(self):
        self.panchayat = Panchayat.objects.create(name='Panchayat 1', district='District 1')
        
        # Create template for vaccination
        self.template = VaccinationScheduleTemplate.objects.create(
            vaccine_name='Polio 1',
            age_in_weeks=0,
            dose_number=1
        )
        
        # ASHA
        self.asha_user = CustomUser.objects.create_user(
            username='asha1', password='pass', role=CustomUser.Role.ASHA_WORKER
        )
        self.asha_profile = AshaWorkerProfile.objects.create(
            user=self.asha_user, panchayat=self.panchayat, worker_id='ASHA_SETUP_001'
        )

        # Mother 1
        self.mother1_user = CustomUser.objects.create_user(
            username='mother1', password='pass', role=CustomUser.Role.MOTHER
        )
        self.mother1_profile = MotherProfile.objects.create(
            user=self.mother1_user,
            asha_worker=self.asha_profile,
            pregnancy_status='pregnant',
            expected_due_date=date.today() + timedelta(days=140)
        )

        # Mother 2 (for data isolation testing)
        self.mother2_user = CustomUser.objects.create_user(
            username='mother2', password='pass', role=CustomUser.Role.MOTHER
        )
        self.mother2_profile = MotherProfile.objects.create(user=self.mother2_user)

        # Doctor
        self.doc_user = CustomUser.objects.create_user(
            username='doc1', password='pass', role=CustomUser.Role.DOCTOR
        )
        self.doc_profile = DoctorProfile.objects.create(user=self.doc_user, specialization='general')
        DoctorAvailability.objects.create(
            doctor=self.doc_profile,
            day_of_week=date.today().weekday(),
            start_time='09:00',
            end_time='17:00',
            max_bookings=5,
            is_available=True
        )

    def test_mother_dashboard(self):
        self.client.login(username='mother1', password='pass')
        response = self.client.get(reverse('mother:dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertIn('pregnancy_info', response.context)
        self.assertIsNotNone(response.context['pregnancy_info'])

    def test_baby_registration_and_signal(self):
        self.client.login(username='mother1', password='pass')
        response = self.client.post(reverse('mother:baby_add'), {
            'name': 'Baby John',
            'date_of_birth': str(date.today()),
            'gender': 'M',
            'birth_weight': '3.2',
            'blood_group': 'O+',
            'notes': 'Healthy'
        })
        self.assertEqual(response.status_code, 302)
        baby = BabyProfile.objects.get(name='Baby John', mother=self.mother1_profile)
        self.assertIsNotNone(baby)
        # Verify vaccination signal generated record
        vax_count = VaccinationRecord.objects.filter(baby=baby).count()
        self.assertEqual(vax_count, 1)

    def test_baby_detail_and_growth_add(self):
        self.client.login(username='mother1', password='pass')
        baby = BabyProfile.objects.create(
            mother=self.mother1_profile,
            name='Baby Jane',
            date_of_birth=date.today(),
            gender='F'
        )
        # Add Growth
        resp_growth = self.client.post(reverse('mother:growth_add', kwargs={'baby_pk': baby.pk}), {
            'record_date': str(date.today()),
            'weight_kg': '4.5',
            'height_cm': '55.0',
            'head_circumference_cm': '38.0',
            'notes': 'Good growth'
        })
        self.assertRedirects(resp_growth, reverse('mother:baby_detail', kwargs={'pk': baby.pk}))
        self.assertEqual(BabyGrowthRecord.objects.filter(baby=baby).count(), 1)

        # GET baby detail
        resp_detail = self.client.get(reverse('mother:baby_detail', kwargs={'pk': baby.pk}))
        self.assertEqual(resp_detail.status_code, 200)

    def test_doctor_booking_and_cancel(self):
        self.client.login(username='mother1', password='pass')
        today = date.today()
        # Book Doctor
        resp_book = self.client.post(reverse('mother:book_confirm'), {
            'doctor_pk': self.doc_profile.pk,
            'appointment_date': str(today),
            'reason': 'Regular checkup'
        })
        self.assertRedirects(resp_book, reverse('mother:bookings'))
        booking = Booking.objects.get(mother=self.mother1_profile, doctor=self.doc_profile)
        self.assertEqual(booking.status, Booking.Status.PENDING)

        # Cancel Booking
        resp_cancel = self.client.post(reverse('mother:booking_cancel', kwargs={'pk': booking.pk}))
        self.assertRedirects(resp_cancel, reverse('mother:bookings'))
        booking.refresh_from_db()
        self.assertEqual(booking.status, Booking.Status.CANCELLED)

    def test_mother_asha_chat(self):
        self.client.login(username='mother1', password='pass')
        # Mother sends message
        self.client.post(reverse('mother:chat'), {'content': 'Hello ASHA sister'})
        msg = Message.objects.filter(sender=self.mother1_user, recipient=self.asha_user).first()
        self.assertIsNotNone(msg)
        self.assertEqual(msg.content, 'Hello ASHA sister')

        # API check
        api_resp = self.client.get(reverse('mother:chat_messages_api'))
        self.assertEqual(api_resp.status_code, 200)

    def test_mother_data_isolation(self):
        # Mother 2 baby
        baby2 = BabyProfile.objects.create(
            mother=self.mother2_profile,
            name='Baby Secret',
            date_of_birth=date.today(),
            gender='M'
        )
        # Mother 1 logs in and tries to access Mother 2's baby detail
        self.client.login(username='mother1', password='pass')
        resp = self.client.get(reverse('mother:baby_detail', kwargs={'pk': baby2.pk}))
        self.assertEqual(resp.status_code, 404)

    def test_mother_can_submit_assistance_request(self):
        govt_user = CustomUser.objects.create_user(
            username='govt_officer_test', password='password123', role=CustomUser.Role.GOVERNMENT
        )
        self.client.login(username='mother1', password='pass')

        # GET assistance request page
        get_resp = self.client.get(reverse('mother:assistance_request'))
        self.assertEqual(get_resp.status_code, 200)

        # POST valid assistance request
        post_resp = self.client.post(reverse('mother:assistance_request'), {
            'category': 'asha_unreachable',
            'message': 'My ASHA worker has not answered calls for a week and vaccine is due.'
        })
        self.assertRedirects(post_resp, reverse('mother:dashboard'))

        # Verify created as pending
        req = AssistanceRequest.objects.get(mother=self.mother1_profile)
        self.assertEqual(req.status, AssistanceRequest.Status.PENDING)
        self.assertEqual(req.category, 'asha_unreachable')

        # Verify government received notification
        notif = Notification.objects.filter(recipient=govt_user).first()
        self.assertIsNotNone(notif)
        self.assertIn('Assistance Request', notif.title)

    def test_duplicate_pending_assistance_request_prevented(self):
        self.client.login(username='mother1', password='pass')
        AssistanceRequest.objects.create(
            mother=self.mother1_profile,
            category='asha_unreachable',
            message='Initial request under review',
            status=AssistanceRequest.Status.PENDING
        )

        # Attempt to submit second request while one is pending
        post_resp = self.client.post(reverse('mother:assistance_request'), {
            'category': 'reassign_request',
            'message': 'Second duplicate request'
        })
        self.assertRedirects(post_resp, reverse('mother:dashboard'))
        # Ensure still only 1 request exists
        self.assertEqual(AssistanceRequest.objects.filter(mother=self.mother1_profile).count(), 1)

    def test_mother_cannot_resolve_assistance_request(self):
        req = AssistanceRequest.objects.create(
            mother=self.mother1_profile,
            category='asha_unreachable',
            message='Need help',
            status=AssistanceRequest.Status.PENDING
        )
        self.client.login(username='mother1', password='pass')
        resp = self.client.post(reverse('government:assistance_resolve', kwargs={'pk': req.pk}), {
            'resolution_notes': 'Hacked resolution'
        })
        # @government_required blocks non-government users and redirects to mother dashboard
        self.assertRedirects(resp, reverse('mother:dashboard'))
        req.refresh_from_db()
        self.assertEqual(req.status, AssistanceRequest.Status.PENDING)

    def test_government_can_view_and_resolve_assistance_request(self):
        govt_user = CustomUser.objects.create_user(
            username='govt_worker_rev', password='password123', role=CustomUser.Role.GOVERNMENT
        )
        req = AssistanceRequest.objects.create(
            mother=self.mother1_profile,
            category='reassign_request',
            message='Need new ASHA worker assigned to my area.',
            status=AssistanceRequest.Status.PENDING
        )

        # Government views Mothers page with pending request
        self.client.login(username='govt_worker_rev', password='password123')
        get_resp = self.client.get(reverse('government:mothers'))
        self.assertEqual(get_resp.status_code, 200)
        self.assertContains(get_resp, 'Need new ASHA worker assigned')

        # Government resolves the request
        resolve_resp = self.client.post(reverse('government:assistance_resolve', kwargs={'pk': req.pk}), {
            'resolution_notes': 'Contacted PHC and coordinated visit.'
        })
        self.assertRedirects(resolve_resp, reverse('government:mothers'))

        req.refresh_from_db()
        self.assertEqual(req.status, AssistanceRequest.Status.RESOLVED)
        self.assertEqual(req.resolution_notes, 'Contacted PHC and coordinated visit.')

        # Mother receives resolution notification
        notif = Notification.objects.filter(recipient=self.mother1_user).first()
        self.assertIsNotNone(notif)
        self.assertIn('Resolved', notif.title)
        self.assertIn('Contacted PHC and coordinated visit.', notif.message)

    def test_government_can_reassign_asha_to_resolve_assistance(self):
        asha2_user = CustomUser.objects.create_user(
            username='asha2', password='password123', role=CustomUser.Role.ASHA_WORKER
        )
        asha2_profile = AshaWorkerProfile.objects.create(
            user=asha2_user,
            panchayat=self.panchayat,
            worker_id='ASHA_REASSIGN_002',
            verification_status=AshaWorkerProfile.VerificationStatus.APPROVED,
            is_active=True
        )
        unapproved_user = CustomUser.objects.create_user(
            username='asha_unappr', password='password123', role=CustomUser.Role.ASHA_WORKER
        )
        unapproved_profile = AshaWorkerProfile.objects.create(
            user=unapproved_user,
            panchayat=self.panchayat,
            worker_id='ASHA_UNAPPR_003',
            verification_status=AshaWorkerProfile.VerificationStatus.PENDING,
            is_active=False
        )

        req = AssistanceRequest.objects.create(
            mother=self.mother1_profile,
            category='reassign_request',
            message='Please reassign me to another worker.',
            status=AssistanceRequest.Status.PENDING
        )

        govt_user = CustomUser.objects.create_user(
            username='govt_reassigner', password='password123', role=CustomUser.Role.GOVERNMENT
        )
        self.client.login(username='govt_reassigner', password='password123')

        # Check candidate list: only approved active workers
        assign_page = self.client.get(reverse('government:assign_asha', kwargs={'mother_pk': self.mother1_profile.pk}))
        candidates = assign_page.context['asha_workers']
        self.assertIn(asha2_profile, candidates)
        self.assertNotIn(unapproved_profile, candidates)

        # Reassign to asha2
        post_assign = self.client.post(
            reverse('government:assign_asha', kwargs={'mother_pk': self.mother1_profile.pk}),
            {'asha_worker': asha2_profile.pk}
        )
        self.assertRedirects(post_assign, reverse('government:mothers'))

        self.mother1_profile.refresh_from_db()
        self.assertEqual(self.mother1_profile.asha_worker, asha2_profile)

        # Pending assistance request is resolved
        req.refresh_from_db()
        self.assertEqual(req.status, AssistanceRequest.Status.RESOLVED)
        self.assertIn('assigned by health administration', req.resolution_notes)
