from django.contrib import admin
# pyrefly: ignore [missing-import]
from .models import MotherProfile, BabyProfile, BabyGrowthRecord, VaccinationRecord, Booking, AssistanceRequest

@admin.register(MotherProfile)
class MotherProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'pregnancy_status', 'asha_worker', 'is_active')
    list_filter = ('pregnancy_status', 'is_active')
    search_fields = ('user__first_name', 'user__last_name')

@admin.register(BabyProfile)
class BabyProfileAdmin(admin.ModelAdmin):
    list_display = ('name', 'mother', 'date_of_birth', 'gender')
    search_fields = ('name', 'mother__user__first_name')

@admin.register(BabyGrowthRecord)
class BabyGrowthRecordAdmin(admin.ModelAdmin):
    list_display = ('baby', 'record_date', 'weight_kg', 'height_cm', 'recorded_by')
    ordering = ('-record_date',)

@admin.register(VaccinationRecord)
class VaccinationRecordAdmin(admin.ModelAdmin):
    list_display = ('baby', 'schedule', 'due_date', 'status', 'given_date', 'alert_sent')
    list_filter = ('status', 'alert_sent')
    ordering = ('due_date',)

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('mother', 'doctor', 'appointment_date', 'status', 'created_at')
    list_filter = ('status', 'appointment_date')
    search_fields = ('mother__user__first_name', 'doctor__user__last_name')
    date_hierarchy = 'appointment_date'
    ordering = ('-appointment_date',)

@admin.register(AssistanceRequest)
class AssistanceRequestAdmin(admin.ModelAdmin):
    list_display = ('mother', 'category', 'status', 'created_at')
    list_filter = ('status', 'category')
    search_fields = ('mother__user__first_name', 'mother__user__last_name', 'message')

