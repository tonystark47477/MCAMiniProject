from datetime import date

from django import forms as dj_forms
from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from core.decorators import mother_required
from core.models import Disease, Food, HealthTip, Message, Notification
from doctor.models import DoctorAvailability, DoctorProfile
from mother.models import (AssistanceRequest, BabyGrowthRecord, BabyProfile,
                           Booking, MotherProfile, VaccinationRecord)


@mother_required
def dashboard(request):
    mother = request.user.mother_profile
    babies = mother.babies.all()
    today = timezone.now().date()
    
    # Calculate pregnancy progress if pregnant and has expected due date
    pregnancy_info = None
    if mother.pregnancy_status == MotherProfile.PregnancyStatus.PREGNANT and mother.expected_due_date:
        due_date = mother.expected_due_date
        days_remaining = (due_date - today).days
        # Standard gestation period is 280 days
        gestational_days = 280 - days_remaining
        if gestational_days < 0:
            gestational_days = 0
        elif gestational_days > 280:
            gestational_days = 280
            
        weeks = gestational_days // 7
        days = gestational_days % 7
        progress_pct = int((gestational_days / 280.0) * 100)
        
        if gestational_days < 91:
            trimester = 1
            trimester_name = "1st Trimester"
            trimester_desc = "Foundation Phase"
        elif gestational_days < 189:
            trimester = 2
            trimester_name = "2nd Trimester"
            trimester_desc = "Growth & Movement"
        else:
            trimester = 3
            trimester_name = "3rd Trimester"
            trimester_desc = "Preparation & Delivery"
            
        pregnancy_info = {
            'weeks': weeks,
            'days': days,
            'days_remaining': max(0, days_remaining),
            'progress_pct': progress_pct,
            'trimester': trimester,
            'trimester_name': trimester_name,
            'trimester_desc': trimester_desc,
        }
        
    # Get babies data with latest growth metrics and vaccination progress
    babies_data = []
    for baby in babies:
        latest_growth = baby.growth_records.order_by('-record_date').first()
        total_vax = baby.vaccinations.count()
        given_vax = baby.vaccinations.filter(status=VaccinationRecord.Status.GIVEN).count()
        vax_progress = int((given_vax / total_vax * 100)) if total_vax > 0 else 0
        
        babies_data.append({
            'baby': baby,
            'latest_growth': latest_growth,
            'total_vax': total_vax,
            'given_vax': given_vax,
            'vax_progress': vax_progress,
        })
        
    # Get upcoming vaccinations (up to 3)
    upcoming_vaccinations = VaccinationRecord.objects.filter(
        baby__mother=mother,
        status=VaccinationRecord.Status.PENDING,
        due_date__gte=today,
    ).select_related('baby', 'schedule').order_by('due_date')[:3]
    
    # Get upcoming bookings (future bookings that are pending or confirmed)
    upcoming_bookings = Booking.objects.filter(
        mother=mother,
        appointment_date__gte=today,
        status__in=[Booking.Status.PENDING, Booking.Status.CONFIRMED]
    ).select_related('doctor__user').order_by('appointment_date')
    
    # Next vaccine alert (first upcoming pending vaccine)
    next_vaccine = upcoming_vaccinations.first() if upcoming_vaccinations.exists() else None
    
    # Pending booking (for backward compatibility / quick actions alert)
    pending_booking = Booking.objects.filter(mother=mother, status=Booking.Status.PENDING).first()
    
    # Total pending vaccinations count
    pending_vaccines_count = VaccinationRecord.objects.filter(
        baby__mother=mother,
        status=VaccinationRecord.Status.PENDING
    ).count()
    
    # Unread alerts count
    unread_alerts = request.user.received_notifications.filter(is_read=False).count()
    pending_assistance = AssistanceRequest.objects.filter(
        mother=mother, status=AssistanceRequest.Status.PENDING
    ).first()
    
    return render(request, 'mother/dashboard.html', {
        'mother': mother,
        'babies': babies,
        'babies_data': babies_data,
        'pregnancy_info': pregnancy_info,
        'next_vaccine': next_vaccine,
        'upcoming_vaccinations': upcoming_vaccinations,
        'upcoming_bookings': upcoming_bookings,
        'pending_booking': pending_booking,
        'pending_vaccines_count': pending_vaccines_count,
        'pending_assistance': pending_assistance,
        'unread_alerts': unread_alerts,
        'today': today,
    })


@mother_required
def book_doctor(request):
    doctors = DoctorProfile.objects.filter(is_active=True).select_related('user').prefetch_related('availability')
    selected_doctor = None
    available_day_names = []
    doctor_id = request.GET.get('doctor')
    if doctor_id:
        selected_doctor = doctors.filter(pk=doctor_id).first()
        if selected_doctor:
            day_map = ['Monday', 'Tuesday', 'Wednesday',
                       'Thursday', 'Friday', 'Saturday', 'Sunday']
            available_day_names = [
                day_map[a.day_of_week]
                for a in selected_doctor.availability.filter(is_available=True)
            ]
    today = timezone.now().date()
    return render(request, 'mother/book_doctor.html', {
        'doctors': doctors,
        'selected_doctor': selected_doctor,
        'available_day_names': available_day_names,
        'today': today,
    })


@mother_required
def book_confirm(request):
    if request.method == 'POST':
        doctor_pk = request.POST.get('doctor_pk')
        appointment_date = request.POST.get('appointment_date')
        reason = request.POST.get('reason', '')
        mother = request.user.mother_profile
        doctor = get_object_or_404(DoctorProfile, pk=doctor_pk)
        appt_date = date.fromisoformat(appointment_date)
        existing = Booking.objects.filter(
            doctor=doctor,
            appointment_date=appt_date,
            status__in=[Booking.Status.PENDING, Booking.Status.CONFIRMED],
        ).count()
        avail = DoctorAvailability.objects.filter(
            doctor=doctor,
            day_of_week=appt_date.weekday(),
            is_available=True,
        ).first()
        if not avail:
            messages.error(request, 'Doctor is not available on that day.')
            return redirect('mother:book_doctor')
        if existing >= (avail.max_bookings if avail else 10):
            messages.error(request, 'Doctor is fully booked on that day.')
            return redirect('mother:book_doctor')
        Booking.objects.create(
            mother=mother,
            doctor=doctor,
            appointment_date=appt_date,
            reason=reason,
            status=Booking.Status.PENDING,
        )
        messages.success(request, 'Appointment booked! Waiting for doctor confirmation.')
        return redirect('mother:bookings')
    return redirect('mother:book_doctor')


@mother_required
def bookings(request):
    mother = request.user.mother_profile
    bookings_qs = Booking.objects.filter(mother=mother).select_related('doctor__user').order_by('-appointment_date')
    return render(request, 'mother/bookings.html', {
        'bookings': bookings_qs,
    })


@mother_required
def booking_detail(request, pk):
    mother = request.user.mother_profile
    booking = get_object_or_404(Booking, pk=pk, mother=mother)
    return render(request, 'mother/booking_detail.html', {
        'booking': booking,
    })


@mother_required
def booking_cancel(request, pk):
    if request.method != 'POST':
        return redirect('mother:bookings')
    mother = request.user.mother_profile
    booking = get_object_or_404(Booking, pk=pk, mother=mother, status=Booking.Status.PENDING)
    booking.status = Booking.Status.CANCELLED
    booking.save(update_fields=['status'])
    messages.success(request, 'Booking cancelled.')
    return redirect('mother:bookings')


@mother_required
def baby_health(request):
    mother = request.user.mother_profile
    babies = mother.babies.all()
    return render(request, 'mother/baby_health.html', {
        'babies': babies,
    })


@mother_required
def baby_add(request):
    class BabyForm(dj_forms.ModelForm):
        class Meta:
            model = BabyProfile
            fields = ['name', 'date_of_birth', 'gender', 'birth_weight', 'blood_group', 'notes']
            widgets = {
                'date_of_birth': dj_forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            }

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            for name, field in self.fields.items():
                if name != 'date_of_birth':
                    field.widget.attrs['class'] = 'form-control'

    if request.method == 'POST':
        form = BabyForm(request.POST)
        if form.is_valid():
            baby = form.save(commit=False)
            baby.mother = request.user.mother_profile
            baby.save()
            messages.success(request, f'{baby.name} added! Vaccination schedule generated.')
            return redirect('mother:baby_detail', pk=baby.pk)
    else:
        form = BabyForm()
    return render(request, 'mother/baby_add.html', {'form': form})


@mother_required
def baby_detail(request, pk):
    mother = request.user.mother_profile
    baby = get_object_or_404(BabyProfile, pk=pk, mother=mother)
    growth_records = baby.growth_records.order_by('record_date')
    vaccinations_qs = baby.vaccinations.select_related('schedule').order_by('due_date')
    import json
    dates = [str(r.record_date) for r in growth_records]
    weights = [float(r.weight_kg) if r.weight_kg else None for r in growth_records]
    heights = [float(r.height_cm) if r.height_cm else None for r in growth_records]
    return render(request, 'mother/baby_detail.html', {
        'baby': baby,
        'growth_records': growth_records,
        'vaccinations': vaccinations_qs,
        'dates_json': json.dumps(dates),
        'weights_json': json.dumps(weights),
        'heights_json': json.dumps(heights),
    })


@mother_required
def growth_add(request, baby_pk):
    mother = request.user.mother_profile
    baby = get_object_or_404(BabyProfile, pk=baby_pk, mother=mother)

    class GrowthForm(dj_forms.ModelForm):
        class Meta:
            model = BabyGrowthRecord
            fields = ['record_date', 'weight_kg', 'height_cm', 'head_circumference_cm', 'notes']
            widgets = {
                'record_date': dj_forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            }

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            for name, field in self.fields.items():
                if name != 'record_date':
                    field.widget.attrs['class'] = 'form-control'

    if request.method == 'POST':
        form = GrowthForm(request.POST)
        if form.is_valid():
            record = form.save(commit=False)
            record.baby = baby
            record.recorded_by = request.user
            record.save()
            messages.success(request, 'Growth record saved.')
            return redirect('mother:baby_detail', pk=baby.pk)
    else:
        form = GrowthForm()
    return render(request, 'mother/growth_add.html', {
        'form': form,
        'baby': baby,
    })


@mother_required
def vaccinations(request):
    mother = request.user.mother_profile
    today = timezone.now().date()
    vaccinations_qs = VaccinationRecord.objects.filter(baby__mother=mother).select_related('baby', 'schedule').order_by('due_date')
    return render(request, 'mother/vaccinations.html', {
        'vaccinations': vaccinations_qs,
        'today': today,
    })


@mother_required
def health_tips(request):
    tips = HealthTip.objects.filter(is_active=True)
    category = request.GET.get('category', '')
    if category:
        tips = tips.filter(category=category)
    categories = [(c.value, c.label) for c in HealthTip.Category]
    return render(request, 'mother/health_tips.html', {
        'tips': tips,
        'categories': categories,
        'active_category': category,
    })


@mother_required
def food(request):
    mother = request.user.mother_profile
    foods = Food.objects.filter(is_active=True)
    status = mother.pregnancy_status
    if status in ['pregnant', 'postnatal', 'lactating']:
        foods = foods.filter(target_group__in=[status, 'general'])
    return render(request, 'mother/food.html', {'foods': foods})


@mother_required
def diseases(request):
    diseases_qs = Disease.objects.filter(is_active=True)
    return render(request, 'mother/diseases.html', {
        'diseases': diseases_qs,
    })


@mother_required
def chat(request):
    mother = request.user.mother_profile
    asha_worker = mother.asha_worker
    messages_qs = None
    if asha_worker:
        if request.method == 'POST':
            content = request.POST.get('content', '').strip()
            if content:
                Message.objects.create(
                    sender=request.user,
                    recipient=asha_worker.user,
                    content=content,
                )
            return redirect('mother:chat')
        messages_qs = Message.objects.filter(
            sender__in=[request.user, asha_worker.user],
            recipient__in=[request.user, asha_worker.user],
        ).order_by('created_at')
        Message.objects.filter(
            sender=asha_worker.user,
            recipient=request.user,
            is_read=False,
        ).update(is_read=True)
    pending_assistance = AssistanceRequest.objects.filter(
        mother=mother, status=AssistanceRequest.Status.PENDING
    ).first()
    return render(request, 'mother/chat.html', {
        'asha_worker': asha_worker,
        'messages': messages_qs,
        'messages_qs': messages_qs,
        'pending_assistance': pending_assistance,
    })


@mother_required
def chat_send(request):
    return redirect('mother:chat')


@mother_required
def chat_messages_api(request):
    from django.http import JsonResponse
    mother = request.user.mother_profile
    asha = mother.asha_worker
    if not asha:
        return JsonResponse({'messages': []})
    after_id = int(request.GET.get('after', 0))
    msgs = Message.objects.filter(
        sender__in=[request.user, asha.user],
        recipient__in=[request.user, asha.user],
        id__gt=after_id,
    ).order_by('created_at')
    data = [{
        'id': m.id,
        'content': m.content,
        'is_mine': m.sender == request.user,
        'time': m.created_at.strftime('%H:%M'),
    } for m in msgs]
    return JsonResponse({'messages': data})


@mother_required
def alerts(request):
    notifications = request.user.received_notifications.order_by('-created_at')
    notifications.filter(is_read=False).update(is_read=True)
    return render(request, 'mother/alerts.html', {'notifications': notifications})


@mother_required
def alert_read(request, pk):
    if request.method != 'POST':
        return redirect('mother:alerts')
    notif = get_object_or_404(Notification, pk=pk, recipient=request.user)
    notif.mark_read()
    return redirect('mother:alerts')


@mother_required
def assistance_request(request):
    mother = request.user.mother_profile
    pending_req = AssistanceRequest.objects.filter(
        mother=mother, status=AssistanceRequest.Status.PENDING
    ).first()
    recent_requests = AssistanceRequest.objects.filter(mother=mother).order_by('-created_at')[:5]

    if request.method == 'POST':
        if pending_req:
            messages.warning(request, 'You already have an assistance request under review.')
            return redirect('mother:dashboard')

        category = request.POST.get('category', AssistanceRequest.Category.ASHA_UNREACHABLE)
        message_text = request.POST.get('message', '').strip()

        if not message_text:
            messages.error(request, 'Please describe what assistance you need.')
            return render(request, 'mother/assistance_request.html', {
                'mother': mother,
                'pending_req': pending_req,
                'categories': AssistanceRequest.Category.choices,
                'recent_requests': recent_requests,
            })

        req = AssistanceRequest.objects.create(
            mother=mother,
            category=category,
            message=message_text,
            status=AssistanceRequest.Status.PENDING,
        )

        from accounts.models import CustomUser
        govt_users = CustomUser.objects.filter(role=CustomUser.Role.GOVERNMENT)
        notifs = [
            Notification(
                sender=request.user,
                recipient=gu,
                title=f'Assistance Request: {mother.user.get_full_name() or mother.user.username}',
                message=f'Mother {mother.user.get_full_name() or mother.user.username} submitted an assistance request ({req.get_category_display()}): {message_text[:120]}',
                notif_type=Notification.NotifType.GOVERNMENT,
            )
            for gu in govt_users
        ]
        if notifs:
            Notification.objects.bulk_create(notifs)

        messages.success(request, 'Your assistance request has been submitted to the health administration.')
        return redirect('mother:dashboard')

    return render(request, 'mother/assistance_request.html', {
        'mother': mother,
        'pending_req': pending_req,
        'categories': AssistanceRequest.Category.choices,
        'recent_requests': recent_requests,
    })
