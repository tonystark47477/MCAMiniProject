from django.urls import path

from . import views

app_name = 'mother'

urlpatterns = [
    path('',              views.dashboard,       name='dashboard'),
    path('book/', views.book_doctor, name='book_doctor'),
    path('book/confirm/', views.book_confirm, name='book_confirm'),
    path('bookings/', views.bookings, name='bookings'),
    path('bookings/<int:pk>/', views.booking_detail, name='booking_detail'),
    path('bookings/<int:pk>/cancel/', views.booking_cancel, name='booking_cancel'),
    path('baby/', views.baby_health, name='baby_health'),
    path('baby/add/', views.baby_add, name='baby_add'),
    path('baby/<int:pk>/', views.baby_detail, name='baby_detail'),
    path('baby/<int:baby_pk>/growth/', views.growth_add, name='growth_add'),
    path('vaccinations/', views.vaccinations, name='vaccinations'),
    path('tips/', views.health_tips, name='health_tips'),
    path('food/', views.food, name='food'),
    path('diseases/', views.diseases, name='diseases'),
    path('chat/', views.chat, name='chat'),
    path('chat/send/', views.chat_send, name='chat_send'),
    path('chat/messages/', views.chat_messages_api, name='chat_messages_api'),
    path('alerts/', views.alerts, name='alerts'),
    path('alerts/<int:pk>/read/', views.alert_read, name='alert_read'),
    path('assistance/request/', views.assistance_request, name='assistance_request'),
]