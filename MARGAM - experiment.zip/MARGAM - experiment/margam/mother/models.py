from django.db import models
from django.conf import settings
from django.utils import timezone
from core.models import TimeStampedModel, VaccinationScheduleTemplate


class MotherProfile(TimeStampedModel):
    class PregnancyStatus(models.TextChoices):
        PREGNANT  = 'pregnant',  'Pregnant'
        POSTNATAL = 'postnatal', 'Postnatal'
        LACTATING = 'lactating', 'Lactating'
        OTHER     = 'other',     'Other'

    user              = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='mother_profile'
    )
    asha_worker       = models.ForeignKey(
        'asha.AshaWorkerProfile', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='mothers'
    )
    date_of_birth     = models.DateField(null=True, blank=True)
    address           = models.TextField(blank=True)
    guardian_name     = models.CharField(max_length=100, blank=True)
    guardian_phone    = models.CharField(max_length=15, blank=True)
    pregnancy_status  = models.CharField(max_length=20, choices=PregnancyStatus.choices, default=PregnancyStatus.OTHER)
    expected_due_date = models.DateField(null=True, blank=True)
    blood_group       = models.CharField(max_length=5, blank=True)
    notes             = models.TextField(blank=True)
    is_active         = models.BooleanField(default=True)

    class Meta:
        verbose_name = 'Mother Profile'

    def __str__(self):
        return self.user.get_full_name() or self.user.username


class BabyProfile(TimeStampedModel):
    class Gender(models.TextChoices):
        MALE   = 'M', 'Male'
        FEMALE = 'F', 'Female'

    mother        = models.ForeignKey(MotherProfile, on_delete=models.CASCADE, related_name='babies')
    name          = models.CharField(max_length=100)
    date_of_birth = models.DateField()
    gender        = models.CharField(max_length=1, choices=Gender.choices)
    birth_weight  = models.DecimalField(max_digits=4, decimal_places=2, null=True, blank=True)
    blood_group   = models.CharField(max_length=5, blank=True)
    notes         = models.TextField(blank=True)

    class Meta:
        ordering            = ['date_of_birth']
        verbose_name_plural = 'Baby Profiles'

    def __str__(self):
        return f'{self.name} (child of {self.mother})'

    @property
    def age_in_weeks(self):
        return (timezone.now().date() - self.date_of_birth).days // 7

    @property
    def age_display(self):
        days = (timezone.now().date() - self.date_of_birth).days
        if days < 30:
            return f'{days} days old'
        elif days < 365:
            return f'{days // 30} months old'
        return f'{days // 365} yr {(days % 365) // 30} mo old'


class BabyGrowthRecord(TimeStampedModel):
    """One row per measurement visit — used for growth chart."""
    baby                  = models.ForeignKey(BabyProfile, on_delete=models.CASCADE, related_name='growth_records')
    recorded_by           = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    record_date           = models.DateField(default=timezone.now)
    weight_kg             = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    height_cm             = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True)
    head_circumference_cm = models.DecimalField(max_digits=4, decimal_places=1, null=True, blank=True)
    notes                 = models.TextField(blank=True)

    class Meta:
        ordering        = ['record_date']
        unique_together = ['baby', 'record_date']

    def __str__(self):
        return f'{self.baby.name} – {self.record_date}'


class VaccinationRecord(TimeStampedModel):
    class Status(models.TextChoices):
        PENDING  = 'pending',  'Pending'
        GIVEN    = 'given',    'Given'
        MISSED   = 'missed',   'Missed'
        DEFERRED = 'deferred', 'Deferred'

    baby         = models.ForeignKey(BabyProfile, on_delete=models.CASCADE, related_name='vaccinations')
    schedule     = models.ForeignKey(VaccinationScheduleTemplate, on_delete=models.SET_NULL, null=True)
    due_date     = models.DateField(db_index=True)
    given_date   = models.DateField(null=True, blank=True)
    given_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='vaccinations_administered'
    )
    status       = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING, db_index=True)
    batch_number = models.CharField(max_length=50, blank=True)
    notes        = models.TextField(blank=True)
    alert_sent   = models.BooleanField(default=False)

    class Meta:
        ordering = ['due_date']

    def is_overdue(self):
        return self.status == 'pending' and self.due_date < timezone.now().date()

    def __str__(self):
        return f'{self.baby.name} — {self.schedule} ({self.get_status_display()})'


class Booking(TimeStampedModel):
    class Status(models.TextChoices):
        PENDING   = 'pending',   'Pending'
        CONFIRMED = 'confirmed', 'Confirmed'
        REJECTED  = 'rejected',  'Rejected'
        COMPLETED = 'completed', 'Completed'
        CANCELLED = 'cancelled', 'Cancelled'

    mother           = models.ForeignKey(MotherProfile, on_delete=models.CASCADE, related_name='bookings')
    doctor           = models.ForeignKey('doctor.DoctorProfile', on_delete=models.CASCADE, related_name='bookings')
    appointment_date = models.DateField(db_index=True)
    reason           = models.TextField(blank=True)
    status           = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING, db_index=True)
    doctor_notes     = models.TextField(blank=True)
    rejection_reason = models.TextField(blank=True)

    class Meta:
        ordering = ['-appointment_date']

    def __str__(self):
        return f'{self.mother} → {self.doctor} on {self.appointment_date} [{self.status}]'


class AssistanceRequest(TimeStampedModel):
    class Category(models.TextChoices):
        ASHA_UNREACHABLE = 'asha_unreachable', 'ASHA Worker Unreachable'
        REASSIGN_REQUEST = 'reassign_request', 'Request ASHA Reassignment'
        URGENT_GUIDANCE  = 'urgent_guidance',  'Urgent Care Guidance'
        OTHER            = 'other',            'Other Assistance'

    class Status(models.TextChoices):
        PENDING  = 'pending',  'Pending Review'
        RESOLVED = 'resolved', 'Resolved'

    mother           = models.ForeignKey(MotherProfile, on_delete=models.CASCADE, related_name='assistance_requests')
    category         = models.CharField(max_length=30, choices=Category.choices, default=Category.ASHA_UNREACHABLE)
    message          = models.TextField()
    status           = models.CharField(max_length=15, choices=Status.choices, default=Status.PENDING, db_index=True)
    resolution_notes = models.TextField(blank=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Assistance Request'

    def __str__(self):
        return f'Assistance for {self.mother} [{self.get_status_display()}]'