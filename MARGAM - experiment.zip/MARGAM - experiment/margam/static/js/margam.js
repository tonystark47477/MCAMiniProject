// Margam Core Client Interactions
document.addEventListener('DOMContentLoaded', function () {
  const sidebar = document.getElementById('sidebar');
  const toggleBtn = document.getElementById('sidebarToggle');
  const backdrop = document.getElementById('sidebarBackdrop');

  function openSidebar() {
    if (sidebar) sidebar.classList.add('open');
    if (backdrop) backdrop.classList.add('active');
    document.body.style.overflow = window.innerWidth <= 992 ? 'hidden' : '';
  }

  function closeSidebar() {
    if (sidebar) sidebar.classList.remove('open');
    if (backdrop) backdrop.classList.remove('active');
    document.body.style.overflow = '';
  }

  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (sidebar.classList.contains('open')) {
        closeSidebar();
      } else {
        openSidebar();
      }
    });

    if (backdrop) {
      backdrop.addEventListener('click', closeSidebar);
    }

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && sidebar.classList.contains('open')) {
        closeSidebar();
      }
    });

    window.addEventListener('resize', function () {
      if (window.innerWidth > 992 && sidebar.classList.contains('open')) {
        closeSidebar();
      }
    });
  }

  // Auto-dismiss alert banners after 5 seconds
  document.querySelectorAll('.alert-dismissible').forEach(function (alert) {
    setTimeout(function () {
      const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
      if (bsAlert) bsAlert.close();
    }, 5000);
  });

  // Dark/Light Theme Switcher
  const themeToggle = document.getElementById('themeToggle');
  if (themeToggle) {
    const icon = themeToggle.querySelector('i');
    const getStoredTheme = () => {
      try {
        return localStorage.getItem('margamTheme') || 'light';
      } catch (e) {
        return 'light';
      }
    };

    const currentTheme = document.documentElement.getAttribute('data-bs-theme') || getStoredTheme();
    if (icon) {
      icon.className = currentTheme === 'dark' ? 'bi bi-sun' : 'bi bi-moon-stars';
    }

    themeToggle.addEventListener('click', function () {
      const activeTheme = document.documentElement.getAttribute('data-bs-theme') || 'light';
      const targetTheme = activeTheme === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-bs-theme', targetTheme);

      try {
        localStorage.setItem('margamTheme', targetTheme);
      } catch (e) {
        // storage disabled or private mode
      }

      if (icon) {
        icon.className = targetTheme === 'dark' ? 'bi bi-sun' : 'bi bi-moon-stars';
      }
    });
  }
});
