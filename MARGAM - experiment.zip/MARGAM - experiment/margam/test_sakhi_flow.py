import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'margam.settings')
django.setup()

from sakhi.bot import get_response
from django.contrib.auth import get_user_model
from core.models import Notification
from mother.models import MotherProfile, Booking
from asha.models import AshaWorkerProfile
from doctor.models import DoctorProfile

User = get_user_model()

if __name__ == '__main__':
    print("--- 1. Testing Sakhi Bot Offline Retrieval & Flexible Wording ---")
    queries = [
        "What should I eat during pregnancy?",
        "Which foods are healthy while pregnant?",
        "What food is good for me?",
        "Pregnancy food suggestions?",
        "Is back pain normal during pregnancy?",
        "Which vaccine is next?",
        "Can I take medicine during pregnancy?",
        "What government schemes are available for mothers?"
    ]

    for q in queries:
        resp = get_response(q)
        print(f"Q: '{q}'\n  -> Cat: {resp['category']} | Conf: {resp['confidence']}% | Emerg: {resp['is_emergency']}")
        print(f"  -> Answer snippet: {resp['answer'][:80]}...\n")

    print("\n--- 2. Testing Multi-Turn Context Blending ---")
    prev_context = {'last_category_raw': 'nutrition'}
    followup_q = "What about bananas?"
    resp_followup = get_response(followup_q, context=prev_context)
    print(f"Q: '{followup_q}' with context 'nutrition'\n  -> Cat: {resp_followup['category']} | Conf: {resp_followup['confidence']}%")
    print(f"  -> Answer: {resp_followup['answer'][:120]}...\n")

    print("\n--- 3. Testing Emergency Detection ---")
    emerg_queries = [
        "I have heavy bleeding and severe abdominal pain",
        "My baby is not moving at all today",
        "I have high fever and blurred vision"
    ]
    for eq in emerg_queries:
        resp = get_response(eq)
        print(f"Emergency Q: '{eq}'\n  -> Is Emergency: {resp['is_emergency']} | Cat: {resp['category']}")
        assert resp['is_emergency'] is True, f"Failed to detect emergency for {eq}"

    print("\n--- 4. Testing Emergency Notification Integration ---")
    # Check if mother exists
    mother_user = User.objects.filter(role='mother').first()
    if mother_user and hasattr(mother_user, 'mother_profile'):
        profile = mother_user.mother_profile
        asha = profile.asha_worker
        print(f"Mother: {mother_user.username} | ASHA: {asha}")

        initial_notif_count = Notification.objects.filter(recipient=asha.user).count() if asha else 0

        # Simulate emergency notification creation logic
        if asha and asha.user:
            notif = Notification.objects.create(
                sender=mother_user,
                recipient=asha.user,
                title=f"EMERGENCY ALERT: {mother_user.get_full_name() or mother_user.username}",
                message="EMERGENCY ALERT\n\nIssue: Heavy bleeding and severe cramps\nPriority: HIGH",
                notif_type=Notification.NotifType.GENERAL
            )
            new_count = Notification.objects.filter(recipient=asha.user).count()
            print(f"Notification created! ASHA unread count: {new_count} (was {initial_notif_count})")
            print(f"Notif details: Title='{notif.title}', Recipient='{notif.recipient.username}'")

    print("\nALL SAKHI ENGINE & NOTIFICATION TESTS PASSED SUCCESSFULLY!")

